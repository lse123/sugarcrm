<?php
$app_list_strings['moduleList']['tm_testmodule'] = 'Test Module';
?>