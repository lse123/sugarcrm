<?PHP
$app_list_strings['moduleList']['Products']='Products';
?>