<?php
$app_list_strings['moduleList']['ts_testmodule'] = 'Hello World';
?>