<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$app_list_strings['moduleList']['Iframeapp'] = 'inBOX25';
?>
