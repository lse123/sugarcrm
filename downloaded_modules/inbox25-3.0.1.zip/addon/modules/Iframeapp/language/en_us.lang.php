<?php

$mod_strings = array (
	'LBL_MODULE_NAME'=>'inBOX25',
    	'LBL_MODULE_ID'  => 'Iframeapp',
    	
    	'LBL_URL'  => 'Reset your Access URL:',
    	'LBL_URL_UPDATE'  => 'Update your Access URL:',
    	'LBL_HEIGHT_ADJUST'  => 'Adjust Height:',
);


?>
