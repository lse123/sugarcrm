<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is 
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s):	Knowledge Power IT, Max W. Blackmer, Jr. <max@knowledgepowerit.com>
 * 					______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: This is an implementation of logic_hooks.php to perform 
 * 				Custom Logic function calls within the SugarBean that is
 * 				upgrade safe way to extend a modules functionality
 *
 *				This will demonstrate adding a notification to be sent to 
 *				the person whos opportunity is being reassigned to another
 *				person. Currently only the person being assigned recieves a 
 *				notification. This only defines $hook_array and nothing 
 *				else should be placed here other than references To the hooks
 * 				for business logic.
 ********************************************************************************/
$hook_array = Array();
// position, file, function
$hook_array['before_save'] = Array();
$hook_array['before_save'][] = Array(1, 'notify', 'custom/include/Opportunity/OpportunityNotifyOldAssigned.php','OpportunityNotifyOldAssigned', 'OpportunityNotifyOldAssigned');
?>
