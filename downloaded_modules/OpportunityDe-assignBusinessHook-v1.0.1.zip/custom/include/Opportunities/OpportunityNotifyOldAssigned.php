<?php
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s):	Knowledge Power IT, Max W. Blackmer, Jr. <max@knowledgepowerit.com>
 * 					______________________________________.
 ********************************************************************************/
/*********************************************************************************
 * Description: This is an implementation of logic_hooks.php to perform 
 * 				Custom Logic function calls within the SugarBean that is
 * 				upgrade safe way to extend a modules functionality.
 *
 *				This will demonstrate adding a notification to be sent to 
 *				the person whos opportunity is being reassigned to another
 *				person. Currently only the person being assigned recieves a 
 *				notification. This only defines $hook_array and notthing 
 *				else should be placed here other than refrences.
 ********************************************************************************/
require_once('data/SugarBean.php');
require_once('modules/Opportunities/Opportunity.php');
require_once('modules/Emails/Email.php');
require_once('include/utils.php');

class OpportunityNotifyOldAssigned {
	function OpportunityNotifyOldAssigned(&$bean, $event, $arguments)
	{
		global $sugar_config;
		// only run notify old before save and if Assigned user changed
		// added new check to make sure there was an old user 
		if ($event == 'before_save' and $bean->fetched_row['assigned_user_id']!= '' and $bean->fetched_row['assigned_user_id'] != $bean->assigned_user_id )
		{
			// Next determine if notifications are active 
			require_once("modules/Administration/Administration.php");
			$admin = new Administration();
			$admin->retrieveSettings();
			$sendNotifications = false;
			if ($admin->settings['notify_on']) {
				$GLOBALS['log']->info("Notifications: user assignment has changed, checking if user receives notifications");
				$sendNotifications = true;
			} else {
				$GLOBALS['log']->info("Notifications: not sending e-mail, notify_on is set to OFF");
				$sendNotifications = false; // Play it safe and set it even that the default is false
			}
			// do we send the notifications?
			if($sendNotifications == true) 
			{
				// Yes we send the notifications fetch the notify list
				$notify_list = get_old_notification_recipients($bean);
				// send notifictsion for each user this will allow for multiple
				// users if there is a change to  
				foreach ($notify_list as $notify_user) {
					$bean->send_assignment_notifications($notify_user, $admin);
				}
			}
			
		}
		
	}

	function get_old_notification_recipients($bean)
	{
		/* This function fetches the original assigned user into 
		 * and returns an array. This could be adapted to support
		 * Multiple users being assigned to an opportunity by 
		 * creating a loop to cycle through other custom fields.
		 * 
		 * Other adaptions would also be needed in function
		 * OpportunityNotifyOldAssigned check:
		 * $bean->fetched_row['assigned_user_id'] != $bean->assigned_user_id
		 * to accomidate multiple users assigned using custom fields.
		 */
		
		$notify_user = new User();
		$notify_user->retrieve($bean->fetched_row['assigned_user_id']);
		$old_assigned_user_name = $notify_user->first_name.' '.$notify_user->last_name;
		$GLOBALS['log']->info("Notifications: recipient is $old_assigned_user_name");
		$user_list = array($notify_user);
		return $user_list;
	}
}

?>
