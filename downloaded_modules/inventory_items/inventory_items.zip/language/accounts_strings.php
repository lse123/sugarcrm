<?PHP

	### NEW WITH MODULE INSTALLATION ###

	$mod_strings['LBL_INVENTORY_ITEMS_SUBPANEL_TITLE'] = 'Inventory Items';

	$mod_strings['LBL_SQUARE_FEET'] = 'Square Feet';

?>
