<?PHP

//NEW WITH WIDGET MODULE INSTALLATION
//this is the custom string added to the contacts module from
//the installation fo the widgets module
$mod_strings['LBL_WIDGETS_SUBPANEL_TITLE'] = 'Widgets';

?>