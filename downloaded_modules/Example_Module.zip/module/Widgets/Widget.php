<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Put Description Here
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

//the SugarBean.php file is required for all modules,
//it is the superclass that all sugar modules extend
require_once('data/SugarBean.php');

//your module class extends the SugarBean superclass,
//typically conventions has the class name/instance in the singular form,
//the module folder is the plural of the object
class Widget extends SugarBean
{
	//field_name_map stores the retrieved fields from the db
	var $field_name_map = array();

	//begin db column fields

	//this block of fields are core sugar columns for all objects
	var $id;
	var $date_entered;
	var $date_modified;
	var $modified_user_id;
	var $assigned_user_id;
	var $deleted;

	//here is where you would put your specific column fields
	var $name;
	var $widget_textfield_1;
	var $widget_checkbox_1;
	var $widget_textarea_1;
	var $widget_datefield_1;
	var $widget_dropdown_1;

	//related db columns go here,
	//these are used for columns that are not stored in the db,
	//typically you see modified_user_name, assigned_user_name, etc,
	//
	//during detail and edit views these fields are retrieved
	//from the function fill_in_additional_list_fields()
	var $created_by;
	var $created_by_name;
	var $modified_by_name;
	var $assigned_user_name;

	//end column fields

	//additional class properties

	var $module_dir = 'Widgets';

	//table name typically is in plural form in all lowercase
	var $table_name = "widgets";

	var $object_name = "Widget";

	//This is used to retrieve related fields from form posts
	var $additional_column_fields = Array(
			'assigned_user_name',
			'modified_user_name',
		);

	//relationship fields are used when saving related items,
	//when save() occurs if one of the relationship_fields keys are found
	//in the post, the value which is a corresponding vardef.php entry, is
	//looked up to handle the relationship
	//a good example is account_id in the contacts module
	var $relationship_fields = Array(
//			'posted column' => 'vardef entry',
			'contact_id' => 'widgets',
			'task_id' => 'tasks',
			'note_id' => 'notes',
			'meeting_id' => 'meetings',
			'call_id' => 'calls',
			'email_id' => 'emails'
		);

	function Widget()
	{
		parent::SugarBean();

		//call to setup custom fields for this module,
		//name is typically the plural
		$this->setupCustomFields('Widgets');

		foreach ($this->field_defs as $field)
		{
			$this->field_name_map[$field['name']] = $field;
		}
	}

	//this is legacy code, still referenced during saves,
	//make sure your module has this for now
	var $new_schema = true;

	//this function is called to get the value for to be displayed in the last viewed
	function get_summary_text()
	{
		return "$this->name";
	}

	//this function has been deprecated..., it is no longer called,
	//new list view queries are now generated dynamically using definitions
	//from the listviewdefs.php metadata file
/*
	function create_list_query($order_by, $where, $show_deleted = 0)
	{
		$custom_join = $this->custom_fields->getJOIN();
		
		$query = "SELECT ";
        
		$query .= " widgets.*,
					users.user_name AS assigned_user_name, ";

		if($custom_join)
			$query .= $custom_join['select'];

		$query .= " FROM widgets ";

		$query .= " LEFT JOIN users
					ON widgets.assigned_user_id=users.id ";

		if($custom_join)
       		$query .= $custom_join['join'];

		$where_auto = '1=1';

		if($show_deleted == 0)
			$where_auto = " $this->table_name.deleted=0 ";
		else if($show_deleted == 1)
			$where_auto = " $this->table_name.deleted=1 ";	

		if($where != "")
			$query .= "WHERE $where AND ".$where_auto;
		else
			$query .= "where ".$where_auto;

		if(substr_count($order_by, '.') > 0)
			$query .= " ORDER BY $order_by";
		else if($order_by != "")
			$query .= " ORDER BY $order_by";
		else
			$query .= " ORDER BY widgets.name";
		
		return $query;
	}
*/

	//this function is called when the export link is selected from the list view,
	//it is similar to the not longer use 
	function create_export_query($order_by, $where)
	{
		$custom_join = $this->custom_fields->getJOIN();

		$query = "SELECT widgets.*, users.user_name assigned_user_name ";

		if($custom_join)
			$query .=  $custom_join['select'];

		$query .= " FROM widgets ";

		$query .= "	LEFT JOIN users ON widgets.assigned_user_id=users.id";

		if($custom_join)
			$query .=  $custom_join['join'];

		$query .= " ";

		$where_auto = " widgets.deleted=0 ";

		if($where != "")
			$query .= " WHERE $where AND ".$where_auto;
		else
			$query .= " WHERE ".$where_auto;

		if($order_by != "")
			$query .= " ORDER BY $order_by";
		else
        	$query .= " ORDER BY widgets.name";

		return $query;
	}

	//this function is deprecated as well, it is no longer called 
	//with the new list views
/*
	function fill_in_additional_list_fields()
	{
		// Fill in the assigned_user_name
		//$this->assigned_user_name = get_assigned_user_name($this->assigned_user_id);
	}
*/

	//this function is called during detail and edit views to fill in additional fields
	function fill_in_additional_detail_fields()
	{
		//Fill in the assigned_user_name
		//get_assigned_user_name is a utility function
		$this->assigned_user_name = get_assigned_user_name($this->assigned_user_id);
		$this->created_by_name = get_assigned_user_name($this->created_by);
		$this->modified_by_name = get_assigned_user_name($this->modified_user_id);
	}

	//this function is called during listviews and when Widget records are included
	//in another modules subpanel
	//(example: the contacts modules get_list_view_data() function is called
	//			during the rendering of the contacts subpanel under and account record)
	function get_list_view_data()
	{
		global $current_language;
		$the_array = parent::get_list_view_data();
		$app_list_strings = return_app_list_strings_language($current_language);
		$mod_strings = return_module_language($current_language, 'Widgets');
	    
        // The new listview code only fetches columns that we're displaying and not all
        // the columns so we need these checks.,
        // the_array[] variable stores the columns to be displayed in the listview,
        // array keys are the set in all caps
	   $the_array['NAME'] = (($this->name == "") ? "<em>blank</em>" : $this->name);
	   $the_array['WIDGET_TEXTFIELD_1'] = $this->widget_textfield_1;

	   return  $the_array;
	}

	/**
		builds a generic search based on the query string using or
		do not include any $this-> because this is called on without having the class instantiated
	*/
	function build_generic_where_clause ($the_query_string)
	{
		$where_clauses = Array();

		$the_query_string = PearDatabase::quote(from_html($the_query_string));
		array_push($where_clauses, " widgets.name LIKE '$the_query_string%' ");

		$the_where = "";
		foreach($where_clauses as $clause)
		{
			if($the_where != "") $the_where .= " or ";
			$the_where .= $clause;
		}

		return $the_where;
	}

	//this function is used to implement ACL's (Roles) for your widgets module
	function bean_implements($interface)
	{
		switch($interface)
		{
			case 'ACL':return true;
		}
		return false;
	}

	//this is an overload of the save function for the SugarBean class,
	function save($check_notify = FALSE)
	{
		return parent::save($check_notify);
	}
}

?>