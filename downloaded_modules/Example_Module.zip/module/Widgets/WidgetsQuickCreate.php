<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/


//this class/file renders the quick create form that can be used in subpanels

require_once('include/EditView/QuickCreate.php');
require_once('modules/Widgets/Widget.php');
require_once('include/javascript/javascript.php');

class WidgetsQuickCreate extends QuickCreate {
    
    var $javascript;

    function process()
    {
		global $current_user;
		global $timedate;
		global $app_list_strings;
		global $current_language;

        $mod_strings = return_module_language($current_language, 'Widgets');
        
		parent::process();
  
		$this->ss->assign("NAME", "");
		$this->ss->assign("WIDGET_TEXTFIELD_1", "");
		$this->ss->assign("WIDGET_DROPDOWN_1_OPTIONS", get_select_options_with_id($app_list_strings['widget_dropdown_1_dom'], ''));

		//override for ajax call
        if($this->viaAJAX)
		{
			$this->ss->assign('saveOnclick', "onclick='if(check_form(\"widgetsQuickCreate\")) return SUGAR.subpanelUtils.inlineSave(this.form.id, \"widgets\"); else return false;'");
			$this->ss->assign('cancelOnclick', "onclick='return SUGAR.subpanelUtils.cancelCreate(\"subpanel_widgets\")';");
		}

        $this->ss->assign('viaAJAX', $this->viaAJAX);

        $this->javascript = new javascript();
        $this->javascript->setFormName('widgetsQuickCreate');

        $focus = new Widget();
        $this->javascript->setSugarBean($focus);
        $this->javascript->addAllFields('');

        $this->ss->assign('additionalScripts', $this->javascript->getScript(false));
	}
}

?>