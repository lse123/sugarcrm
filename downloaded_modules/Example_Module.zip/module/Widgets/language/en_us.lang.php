<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************

 * Description:  Defines the English language pack for the base application.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

//the en_us.lang.php file is the default english language file used,
//any string you wish to place in this module please place here for reference
//from the $mod_strings var which can always be accessed via global $mod_strings
$mod_strings = array (
	'LBL_MODULE_NAME' => 'Widgets',
	'LBL_MODULE_TITLE' => 'Widgets: Home',
	'LBL_MODULE_ID' => 'Widgets',
	'LBL_SEARCH_FORM_TITLE' => 'Widget Search',
	'LBL_LIST_FORM_TITLE' => 'Widget List',
	'LBL_NEW_FORM_TITLE' => 'New Widget',
	'LBL_DATE_ENTERED' => 'Date Entered:',
	'LBL_DATE_MODIFIED' => 'Date Modified:',
	'LBL_NAME' => 'Name:',
	'LBL_WIDGET' => 'Widget',
	'LBL_WIDGET_TEXTFIELD_1' => 'Text Field 1:',
	'LBL_WIDGET_TEXTAREA_1' => 'Textarea 1:',
	'LBL_WIDGET_DATEFIELD_1' => 'Date Field 1:',
	'LBL_WIDGET_CHECKBOX_1' => 'Checkbox 1:',
	'LBL_WIDGET_DROPDOWN_1' => 'Dropdown 1:',
	'LBL_ASSIGNED_TO_NAME' => 'Assigned User:',

	//the '_LIST_' variations of strings are used on listviews and subpanels,
	//typically you remove the ':' from the end of the string,
	//you can also shorten up the label if the standard label is very long
	//	(ie: Detail/Edit Views: 'Number', ListViews: 'No.')
	'LBL_LIST_NAME' => 'Name',
	'LBL_LIST_WIDGET_TEXTFIELD_1' => 'Text Field 1',
	'LBL_LIST_WIDGET_TEXTAREA_1' => 'Textarea 1',
	'LBL_LIST_WIDGET_DATEFIELD_1' => 'Date Field 1',
	'LBL_LIST_WIDGET_CHECKBOX_1' => 'Checkbox 1',
	'LBL_LIST_WIDGET_DROPDOWN_1' => 'Dropdown 1',
	'LBL_LIST_ASSIGNED_TO_NAME' => 'Assigned User',
	
	'LNK_NEW_WIDGET' => 'New Widget',
	'LNK_WIDGET_LIST' => 'Widgets',
	'ERR_DELETE_RECORD' => 'A record number must be specified to delete the widget.',
	'LBL_LIST_MY_WIDGETS' => 'My Assigned Widgets',
	
	'LBL_CREATED_BY' => 'Created by:',
	'LBL_DATE_CREATED' => 'Create Date:',
	'LBL_MODIFIED_BY' => 'Last Modified by:',
	'LBL_DATE_LAST_MODIFIED' => 'Modify Date:',

	'LBL_DEFAULT_SUBPANEL_TITLE' => 'Widgets',
	'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
	'LBL_HISTORY_SUBPANEL_TITLE' => 'History',
	'LBL_CONTACTS_SUBPANEL_TITLE' => 'Contacts',
);

?>