<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/**
 * Layout definition for Widgets
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */
 
//the layout_defs metadata array defines the subpanels that should get rendered and
//displayed in the detailviews of a widget record,
//for this example we implement the basic activity/history subpanels
$layout_defs['Widgets'] = array(
	'subpanel_setup' => array(

	//activities is the subpanel name
	'activities' => array(
		//the order property is which order the subpanel will show up in,
		//increments of 10 are used so 3rd party modules can be installed and placed
		//without having to re-order all existing subpanels
		'order' => 10,
		'sort_order' => 'desc',
		'sort_by' => 'date_start',
		//title key string reference is looked up in the widget module strings
		'title_key' => 'LBL_ACTIVITIES_SUBPANEL_TITLE',
		'type' => 'collection',
		'subpanel_name' => 'activities',   //this values is not associated with a physical file for type collection
		'module'=>'Activities',
		//the buttons to show at the top of the subpanel,
		//the values are references to sugar field/button widgets located
		//in the include/generic/SugarWidgets directory
		'top_buttons' => array(
			array('widget_class' => 'SubPanelTopCreateTaskButton'),
			array('widget_class' => 'SubPanelTopScheduleMeetingButton'),
			array('widget_class' => 'SubPanelTopScheduleCallButton'),
			array('widget_class' => 'SubPanelTopComposeEmailButton'),
		),
		//type collection subpanels are special for activities/history,
		//the collection list is the list of modules being grouped for the panel
		'collection_list' => array(
			'meetings' => array(
				//the target module called for this subpanel
				'module' => 'Meetings',
				//the subpanel_name is a reference to a file located in the target
				//modules subpanel folder (ie:modules/Meetings/subpanels/ForActivities.php)
				'subpanel_name' => 'ForActivities',
				//the get_subpanel_data value is a reference to the vardef for widgets
				'get_subpanel_data' => 'meetings',
			),
			'tasks' => array(
				'module' => 'Tasks',
				'subpanel_name' => 'ForActivities',
				'get_subpanel_data' => 'tasks',
			),
			'calls' => array(
				'module' => 'Calls',
				'subpanel_name' => 'ForActivities',
				'get_subpanel_data' => 'calls',
			),	
		)			
	),
	'history' => array(
		'order' => 20,
		'sort_order' => 'desc',
		'sort_by' => 'date_modified',
		'title_key' => 'LBL_HISTORY_SUBPANEL_TITLE',
		'type' => 'collection',
		'subpanel_name' => 'history',   //this values is not associated with a physical file.
		'module'=>'History',
		'top_buttons' => array(
			array('widget_class' => 'SubPanelTopCreateNoteButton'),
			array('widget_class' => 'SubPanelTopArchiveEmailButton'),
            array('widget_class' => 'SubPanelTopSummaryButton'),
		),
		'collection_list' => array(	
			'meetings' => array(
				'module' => 'Meetings',
				'subpanel_name' => 'ForHistory',
				'get_subpanel_data' => 'meetings',
			),
			'tasks' => array(
				'module' => 'Tasks',
				'subpanel_name' => 'ForHistory',
				'get_subpanel_data' => 'tasks',
			),
			'calls' => array(
				'module' => 'Calls',
				'subpanel_name' => 'ForHistory',
				'get_subpanel_data' => 'calls',
			),	
			'notes' => array(
				'module' => 'Notes',
				'subpanel_name' => 'ForHistory',
				'get_subpanel_data' => 'notes',
			),	
			'emails' => array(
				'module' => 'Emails',
				'subpanel_name' => 'ForHistory',
				'get_subpanel_data' => 'emails',
			),	
		)			
	),
	'contacts' => array(
		'order' => 30,
		'module' => 'Contacts',
		'sort_order' => 'asc',
		'sort_by' => 'name',
		'subpanel_name' => 'default',
		'get_subpanel_data' => 'contacts',
		'add_subpanel_data' => 'contact_id',
		'title_key' => 'LBL_CONTACTS_SUBPANEL_TITLE',
	),
	)
);
?>
