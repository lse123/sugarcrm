<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
/*********************************************************************************
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 ********************************************************************************/
/*********************************************************************************

 * Description:  TODO: To be written.
 * Portions created by SugarCRM are Copyright (C) SugarCRM, Inc.
 * All Rights Reserved.
 * Contributor(s): ______________________________________..
 ********************************************************************************/

require_once('XTemplate/xtpl.php');
require_once('modules/Widgets/Widget.php');

global $app_strings;
global $mod_strings;
global $theme;

//global instance of the user object for the user currently 
//logged in accessing the system
global $current_user;

//global $timedate object used to get date format for calendar popup
global $timedate;

$focus = new Widget();

if(isset($_REQUEST['record']))
    $focus->retrieve($_REQUEST['record']);

echo "\n<p>\n";
echo get_module_title($mod_strings['LBL_MODULE_ID'], $mod_strings['LBL_MODULE_NAME'].": ".$focus->name, true);
echo "\n</p>\n";

$theme_path="themes/".$theme."/";
$image_path=$theme_path."images/";
require_once($theme_path.'layout_utils.php');

$GLOBALS['log']->info("Widget detail view");

//instantiate an XTemplate object with the given editview template to render the page
$xtpl = new XTemplate ('modules/Widgets/EditView.html');

//--------------------------------------
//------Begin rendering page here-------
//--------------------------------------

//pass the module and application strings as arrays to populate appropriate stings
$xtpl->assign("MOD", $mod_strings);
$xtpl->assign("APP", $app_strings);

//the return values are used if the user selects 'Cancel' on the editview
if(isset($_REQUEST['return_module'])) $xtpl->assign("RETURN_MODULE", $_REQUEST['return_module']);
if(isset($_REQUEST['return_action'])) $xtpl->assign("RETURN_ACTION", $_REQUEST['return_action']);
if (isset($_REQUEST['return_id'])) $xtpl->assign("RETURN_ID", $_REQUEST['return_id']);

// handle Create $module then Cancel
if (empty($_REQUEST['return_id'])) {
	$xtpl->assign("RETURN_ACTION", 'index');
}

//use json to define a popup selection field
$json = getJSONobj();
$popup_request_data = array(
	'call_back_function' => 'set_return',
	'form_name' => 'EditView',
	'field_to_name_array' => array(
		'id' => 'assigned_user_id',
		'user_name' => 'assigned_user_name',
	),
);
$xtpl->assign('encoded_users_popup_request_data', $json->encode($popup_request_data));

//instantiate a QuickSearch object to enable it for assigned user input
require_once('include/QuickSearchDefaults.php');
$qsd = new QuickSearchDefaults();

$sqs_objects = array(
	'assigned_user_name' => $qsd->getQSUser(),
);

//call object to generate javascript to handle quick search
$quicksearch_js = $qsd->getQSScripts();
$quicksearch_js .= '<script type="text/javascript" language="javascript">sqs_objects = ' . $json->encode($sqs_objects) . '</script>';

$xtpl->assign("THEME", $theme);
$xtpl->assign("IMAGE_PATH", $image_path);$xtpl->assign("PRINT_URL", "index.php?".$GLOBALS['request_string']);
$xtpl->assign("JAVASCRIPT", get_set_focus_js().get_validate_record_js(). $quicksearch_js);

$xtpl->assign("ID", $focus->id);

if (isset($focus->name)) $xtpl->assign("NAME", $focus->name);
else $xtpl->assign("NAME", "");

$xtpl->assign("DATE_ENTERED", $focus->date_entered);
$xtpl->assign("DATE_MODIFIED", $focus->date_modified);
$xtpl->assign("CREATED_BY", $focus->created_by_name);
$xtpl->assign("MODIFIED_BY", $focus->modified_by_name);

//set the dropdown values in the template,
//call to utility function get_select_options_with_id() takes the dropdown list from the
//application strings array and the selected value of the dropdown, the function returns
//all of the <option value="X"> entries to be populated in the template
if(!empty($focus->widget_dropdown_1))
	$xtpl->assign("WIDGET_DROPDOWN_1_OPTIONS", get_select_options_with_id($app_list_strings['widget_dropdown_1_dom'],$focus->widget_dropdown_1));
else
	$xtpl->assign("WIDGET_DROPDOWN_1_OPTIONS", get_select_options_with_id($app_list_strings['widget_dropdown_1_dom'], ""));

//set the checkbox value (values are 1,0),
//if value is 1 write checked to template
if(!empty($focus->widget_checkbox_1) && $focus->widget_checkbox_1 == 1)
	$xtpl->assign("WIDGET_CHECKBOX_1", " checked");
else
	$xtpl->assign("WIDGET_CHECKBOX_1", "");

//remaining example fields are set in a straight forward manner
$xtpl->assign("WIDGET_DATEFIELD_1", $focus->widget_datefield_1);
$xtpl->assign("WIDGET_TEXTAREA_1", $focus->widget_textarea_1);
$xtpl->assign("WIDGET_TEXTFIELD_1", $focus->widget_textfield_1);

//if no assigned user set, assume $current_user is default assigned_user
if (empty($focus->assigned_user_id) && empty($focus->id))  $focus->assigned_user_id = $current_user->id;
if (empty($focus->assigned_name) && empty($focus->id))  $focus->assigned_user_name = $current_user->user_name;

$xtpl->assign("ASSIGNED_USER_NAME", $focus->assigned_user_name);
$xtpl->assign("ASSIGNED_USER_ID", $focus->assigned_user_id );

// Unimplemented until jscalendar language files are fixed
// $xtpl->assign("CALENDAR_LANG", ((empty($cal_codes[$current_language])) ? $cal_codes[$default_language] : $cal_codes[$current_language]));
$xtpl->assign("CALENDAR_LANG", "en");
$xtpl->assign("USER_DATEFORMAT", '('. $timedate->get_user_date_format().')');
$xtpl->assign("CALENDAR_DATEFORMAT", $timedate->get_cal_date_format());


//Add Custom Fields
require_once('modules/DynamicFields/templates/Files/EditView.php');

//parse out the 'main' section in the template and output to browser
$xtpl->parse("main");
$xtpl->out("main");

//set javascript form validation,
//addAllFields with interate through the vardefs.php file
//to check required fields and field types
require_once('include/javascript/javascript.php');
$javascript = new javascript();
$javascript->setFormName('EditView');
$javascript->setSugarBean($focus);
$javascript->addAllFields('');

//add special validation type for popup assigned user field
$javascript->addToValidateBinaryDependency('assigned_user_name', 'alpha', $app_strings['ERR_SQS_NO_MATCH_FIELD'] . $app_strings['LBL_ASSIGNED_TO'], 'false', '', 'assigned_user_id');

//echo the javascript validation to the browser
echo $javascript->getScript();

//render the saved searches for the shortcut menu
require_once('modules/SavedSearch/SavedSearch.php');
$savedSearch = new SavedSearch();
$json = getJSONobj();
$savedSearchSelects = $json->encode(array($GLOBALS['app_strings']['LBL_SAVED_SEARCH_SHORTCUT'] . '<br>' . $savedSearch->getSelect('Widgets')));
$str = "<script>
YAHOO.util.Event.addListener(window, 'load', SUGAR.util.fillShortcuts, $savedSearchSelects);
</script>";
echo $str;

?>