<?php

//NEW WITH WIDGET MODULE INSTALLATION
$dictionary['Contact']['fields']['widgets'] = array (
	'name' => 'widgets',
	'type' => 'link',
	'relationship' => 'contacts_widgets',
	'source' =>'non-db',
);

?>