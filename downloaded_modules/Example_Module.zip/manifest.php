<?PHP

//manifest file for information regarding the new widgets module
$manifest = array(
	'acceptable_sugar_versions' => array(),
	'name' => 'Widget Module',
	'description' => 'Example module to manage widgets',
	'author' => 'ndamico',
	'published_date' => '2007-03-06',
	'version' => '.7',
	// type of code (valid choices are: full, langpack, module, patch, theme )
	'type' => 'module',
	// icon for displaying in UI (path to graphic contained within zip package)
	'icon' => '',
);

$installdefs = array(
	'id'=> 'widgets',
	'copy' => array(
		array(
			'from' => '<basepath>/module/Widgets',
			'to' => 'modules/Widgets',
		),
	),
	'language' => array(
		array(
			'from'=> '<basepath>/application/app_strings.php',
			'to_module'=> 'application',
			'language'=>'en_us'
		),
		array(
			'from'=> '<basepath>/language/contacts_strings.php', 
			'to_module'=> 'Contacts',
			'language'=>'en_us'
		),
	),
	'layoutdefs'=> array(
		array(
			'from'=> '<basepath>/layoutdefs/contacts_layout_defs.php', 
			'to_module'=> 'Contacts',
		),
	),
	'beans' => array(
		array(
			'module' => 'Widgets',
			'class' => 'Widget',
			'path' => 'modules/Widgets/Widget.php',
			'tab' => true,
		)
	),
	'relationships'=>array(
		array(
			'module' => 'Contacts',
			'meta_data' => '<basepath>/relationships/contacts_widgetsMetaData.php',
			'module_vardefs' => '<basepath>/vardefs/contacts_vardefs.php'
		),
	),
);

?>