<?PHP

//NEW WITH WIDGET MODULE INSTALLATION
//this is the string to be displayed for the module for its tab
$app_list_strings['moduleList']['Widgets'] = 'Widgets';

//NEW WITH WIDGET MODULE INSTALLATION
//this is the dropdown list that the Widgets module will add to the application
$app_list_strings['widget_dropdown_1_dom'] = array (
	''=>'',
	'Value1' => 'Value 1',
	'Value2' => 'Value 2',
	'Value3' => 'Value 3',
);

?>