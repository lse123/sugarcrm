<?php

//NEW WITH WIDGET MODULE INSTALLATION
//this metadata file defines the many-to-many relationship between contacts and widgets,
//currently all many-to-many relationships are defined view the $dictionary object with
//the files being located in the <sugar root>/metadata folder
$dictionary['contacts_widgets'] = array (
	'table' => 'contacts_widgets',
	'fields' => array (
		array(
			'name' => 'id',
			'type' => 'varchar',
			'len'=>'36'
		),
		array(
			'name' => 'contact_id',
			'type' => 'varchar',
			'len' => '36',
		),
		array(
			'name' => 'widget_id',
			'type' => 'varchar',
			'len' => '36',
		),
		array (
			'name' => 'date_modified',
			'type' => 'datetime'
		),
		array(
			'name' => 'deleted',
			'type' => 'bool',
			'len' => '1',
			'default' => '0',
			'required' => true
		)
	),
	'indices' => array (
		array(
			'name' => 'contacts_widgetspk',
			'type' => 'primary',
			'fields' => array('id')
		),
		array(
			'name' => 'idx_con_widg_con',
			'type' => 'index',
			'fields' => array('contact_id')
		),
		array(
			'name' => 'idx_con_widg_widg',
			'type' => 'index',
			'fields' => array('widget_id')
		),
		array(
			'name' => 'idx_contact_widg',
			'type' => 'alternate_key',
			'fields' => array('contact_id','widget_id')
		)
	),
	'relationships' => array (
		'contacts_widgets' => array(
			'lhs_module' => 'Contacts',
			'lhs_table' => 'contacts',
			'lhs_key' => 'id',
			'rhs_module' => 'Widgets',
			'rhs_table' => 'widgets',
			'rhs_key' => 'id',
			'relationship_type' => 'many-to-many',
			'join_table' => 'contacts_widgets',
			'join_key_lhs' => 'contact_id',
			'join_key_rhs' => 'widget_id'
		)
	),
);

?>