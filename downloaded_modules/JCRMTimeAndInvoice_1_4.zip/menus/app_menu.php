<?php
//JustCRMs - add Time Clock in / out
if (isset($_REQUEST['module']) && $_REQUEST['module'] != 'Administration') {
	if(ACLController::checkAccess('JCRMTime', 'edit', true)) {
		include_once('modules/JCRMTime/ClockMenu.php');
	}
}

?>
