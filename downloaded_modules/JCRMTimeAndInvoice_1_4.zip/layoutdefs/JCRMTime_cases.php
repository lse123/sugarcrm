<?PHP
/*********************************************************************************
justcrms - not for use by service providers
 ********************************************************************************/
/* This displays the JCRMTime records for the selected Case
   the file is loaded into custom and then moved to ext when ext is re-built
   file - custom/extension/modules/accounts/ext/layoutdefs */
$layout_defs['Cases']['subpanel_setup']['jcrmtime'] =  array(

            'order' => 100,
            'module' => 'JCRMTime',
            'sort_order' => 'desc',
            'get_subpanel_data' => 'JCRMTime',
            'add_subpanel_data' => 'case_id',
            'subpanel_name' => 'ForCase',
            'title_key' => 'LBL_JCRMTIME_SUBPANEL_TITLE',


        );

?>