<?PHP
/* This displays the Invoices related to the selected Account
   the file is loaded into custom and then moved to ext when ext is re-built
   file - custom/extension/modules/accounts/ext/layoutdefs */
$layout_defs['Accounts']['subpanel_setup']['jcrminvoices'] =  array(
            'order' => 100,
            'module' => 'JCRMInvoices',
            'get_subpanel_data' => 'JCRMInvoices',
            'add_subpanel_data' => 'account_id',
            'subpanel_name' => 'default',
            'title_key' => 'LBL_JCRMINVOICES_SUBPANEL_TITLE',
        );

?>