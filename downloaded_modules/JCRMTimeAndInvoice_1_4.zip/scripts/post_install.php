<?php

function post_install() {
	global $current_user;
	global $log;
	global $db;
	echo "Time and Invoicing Install script running....<br>";
	include_once("modules/Administration/RebuildExtensions.php");
	include_once("modules/Administration/RebuildRelationship.php");
	echo "<br>...Time and Invoicing Install script complete.<br>";
}
?>
