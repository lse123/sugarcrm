<?PHP
/*********************************************************************************
justcrms - not for use by service providers
 ********************************************************************************/
$dictionary['Account']['fields']['JCRMInvoices'] = array (
                  'name' => 'JCRMInvoices',
                    'type' => 'link',
                    'relationship' => 'accounts_jcrminvoices',
                    'source'=>'non-db',
                  );

?>