<?PHP
/*********************************************************************************
justcrms - not for use by service providers
 ********************************************************************************/

$dictionary['Case']['fields']['JCRMTime'] = array (
                  'name' => 'JCRMTime',
                    'type' => 'link',
                    'relationship' => 'cases_jcrmtime',
                    'source'=>'non-db',
                  );

?>