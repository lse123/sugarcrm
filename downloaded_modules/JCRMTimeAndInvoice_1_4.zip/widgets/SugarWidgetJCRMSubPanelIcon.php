<?php
if (isset($sugar_config)) {
	if ($sugar_config['sugar_version'] >= '4.2.0b') {
		if (!defined('sugarEntry') || !sugarEntry) {
			die('Not A Valid Entry Point pdhere');
		}
	}else{
		if (empty($GLOBALS['sugarEntry'])) {
			die('Not A Valid Entry Point pdhere2');
		}
	}
}
/**
 * SugarWidgetSubPanelIcon
 *
 * The contents of this file are subject to the SugarCRM Public License Version
 * 1.1.3 ("License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at http://www.sugarcrm.com/SPL
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied.  See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * All copies of the Covered Code must include on each user interface screen:
 *    (i) the "Powered by SugarCRM" logo and
 *    (ii) the SugarCRM copyright notice
 * in the same form as they appear in the distribution.  See full license for
 * requirements.
 *
 * The Original Code is: SugarCRM Open Source
 * The Initial Developer of the Original Code is SugarCRM, Inc.
 * Portions created by SugarCRM are Copyright (C) 2004-2006 SugarCRM, Inc.;
 * All Rights Reserved.
 * Contributor(s): __JustCRMs modified version of SubPanelIcon with more flexible options___.
 */

// $Id: SugarWidgetSubPanelIcon.php,v 1.8.6.1 2006/01/08 04:35:44 majed Exp $

require_once('include/generic/SugarWidgets/SugarWidgetField.php');

class SugarWidgetJCRMSubPanelIcon extends SugarWidgetField
{
	function displayList(&$layout_def)
	{
		global $app_strings;
		global $image_path;

		$module = $layout_def['module'];
		$action = isset($layout_def['action']) ? $layout_def['action']: 'DetailView';
		$record = $layout_def['fields']['ID'];
		$url = isset($layout_def['url']) ? $layout_def['url'] : '';

		$target='';
		if(isset($layout_def['popup']) && $layout_def['popup']){
			$target="target='_blank'";
 		}

		$icon_img_html = get_image($image_path . $module . '', 'border="0" alt="' . $module . '"');

		$ret= '<a href="index.php?module=' . $module
			. '&action=' . $action
			. '&record=' . $record  . $url
			. '" class="listViewTdLinkS1" ' . $target .'>' . "$icon_img_html</a>";
		if(!empty($layout_def['image2']) && !empty($layout_def['image2_url_field']) && !empty($layout_def['fields'][strtoupper($layout_def['image2_url_field'])])){
			$icon_img_html = get_image($image_path . $layout_def['image2'] . '', 'border="0" alt="' . $layout_def['image2'] . '"');
			$ret.= '<a href="' . $layout_def['fields'][strtoupper($layout_def['image2_url_field'])] . '" class="listViewTdLinkS1">' . "$icon_img_html</a>";
		}
		// now handle attachments for Emails
		else if(!empty($layout_def['module']) && $layout_def['module'] == 'Emails' && !empty($layout_def['fields']['ATTACHMENT_IMAGE'])) {
			$ret.= $layout_def['fields']['ATTACHMENT_IMAGE'];
		}
		return $ret;
	}
}

?>
