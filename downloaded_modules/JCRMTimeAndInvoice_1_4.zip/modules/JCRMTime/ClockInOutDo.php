<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMTime/EnterCheck.php');
require_once('modules/JCRMTime/JCRMTime.php');
require_once('modules/Cases/Case.php');


if(isset($_SESSION['authenticated_user_id'])) {
	$JCRMTime = new JCRMTime();

	//are we doing an action?
	if(isset($_REQUEST['type']) && $_REQUEST['type'] != '' ){
		 //first do the action
		 if($_REQUEST['type']=='in' && isset($_REQUEST['case_id']) && $_REQUEST['case_id'] !='') {
		 	//clock into case
			 if(!$JCRMTime->ACLAccess('Save')){
				echo 'You do not have access to create time records.';
				die;
			 }


			//clock out current time if there is one
			$JCRMTime->stop_current();

   			//now create a new time record
			$JCRMTime->create_new($_REQUEST['case_id'], $_REQUEST['time_start']);

		 }

       //close historic item ?
		if($_REQUEST['type']=='close') {
			$JCRMTime->stop_current($_REQUEST['time_end']);
		}

       //cancel historic item ?
		if($_REQUEST['type']=='cancel') {
			$JCRMTime->cancel_current();
		}

       //just stop ?
		if($_REQUEST['type']=='out') {
			$JCRMTime->stop_current();
		}
 	}


}

//and show clock in form
include('modules/JCRMTime/ClockInOut.php');
?>
