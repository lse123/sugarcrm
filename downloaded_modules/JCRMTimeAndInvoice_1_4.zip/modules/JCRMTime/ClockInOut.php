<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMTime/EnterCheck.php');
require_once('modules/JCRMTime/JCRMTime.php');
require_once('modules/Cases/Case.php');
require_once('include/TimeDate.php');
//require_once('modules/JCRMTime/ClockConfig.php');

if(isset($_SESSION['authenticated_user_id'])) {
	$showclock=false;
	$clock_body_only=false;
	if(isset($_REQUEST['clock_body_only']) && $_REQUEST['clock_body_only']=='true') {
		$clock_body_only=true;
	}

	$curr_case_id='';
	if(isset($_REQUEST['module']) && $_REQUEST['module']=='Cases' &&
		isset($_REQUEST['record']) && $_REQUEST['record']!='') {
		$curr_case_id=$_REQUEST['record'];
	}

	if(isset($_REQUEST['curr_case_id']) && $_REQUEST['curr_case_id']!='') {
		$curr_case_id=$_REQUEST['curr_case_id'];
	}


	$JCRMTime = new JCRMTime();
	$timedate = new TimeDate();

	global $current_language;
	$clock_strings = return_module_language($current_language, 'JCRMTime');

	$out='';

	$curr_id=$JCRMTime->current_item('id');
	global $ClockMenuText;
    $ClockMenuText=$clock_strings['IN_TITLE'];
	if ($curr_id!='') $ClockMenuText=$clock_strings['OUT_TITLE'];


	if(!$clock_body_only) {
/*		$out.= '<br><table cellpadding="0" cellspacing="0" border="0" width="100%" class="leftColumnModuleHead">
		<tr><th width="5"><img src="themes/Sugar/images/moduleTab_left.gif" alt="" width="5" height="21" border="0" alt="$left_title"></th>
		<th style="background-image : url(themes/Sugar/images/moduleTab_middle.gif);" width="100%">'.$clock_strings['IN_OUT_TITLE'].'</th>
		<th width="5"><img src="themes/Sugar/images/moduleTab_right.gif" alt="" width="9" height="21" border="0" alt="New Account"></th></tr></table>
		<table width="100%" cellpadding="3" cellspacing="0" border="0"><tr><td align="left" class="leftColumnModuleS3">';
 */
 		$curr_case_id_url='';
 		if($curr_case_id!='') $curr_case_id_url.='&curr_case_id='.$curr_case_id;

		$out.="<script>

				var request_id = 0;
				var MenuText='$ClockMenuText';

				function FormatClockMenu() {
					if(document.all){
						var allElements = document.getElementsByTagName('A');
						for (var i = 0; i<allElements.length; i++) {
							if(allElements[i].innerText != undefined){
								if(allElements[i].innerText=='{$clock_strings['OUT_TITLE']}' || allElements[i].innerText=='{$clock_strings['IN_TITLE']}') {
                                	allElements[i].innerText=MenuText;
                                	if(MenuText=='{$clock_strings['OUT_TITLE']}'){
                                		allElements[i].style.fontWeight='bold';
                                	}
                                	else {
                                		allElements[i].style.fontWeight='normal';
                                	}
        						}
							}//end if
						}//end for
					} else{
						var allElements = document.body.getElementsByTagName('A');

						for (var i = 0; i<allElements.length; i++) {
							if(allElements[i].textContent != undefined){
								if(allElements[i].textContent=='{$clock_strings['OUT_TITLE']}' || allElements[i].textContent=='{$clock_strings['IN_TITLE']}') {
                                	allElements[i].textContent=MenuText;
                                	if(MenuText=='{$clock_strings['OUT_TITLE']}'){
                                		allElements[i].style.fontWeight='bold';
                                	}
                                	else {
                                		allElements[i].style.fontWeight='normal';
                                	}
        						}
							}//end if
						}//end for
					}
				}
FormatClockMenu();

				function clock_fetch(url){

					if ( url.indexOf('http://') != 0  && url.indexOf('https://') != 0)
					{
						url = ''+url;
					}

					var clock_div = document.getElementById('clockinoutdiv');

					//alert(url);
					//alert(clock_div.innerHTML);

					clock_div.innerHTML='';

					var returnstuff = http_fetch_sync(url+'&sugar_body_only=true&clock_body_only=true&to_csv=true$curr_case_id_url');
					request_id++;

					//alert(returnstuff.responseText);

					clock_div.innerHTML=returnstuff.responseText;

					var clock_div_show = document.getElementById('clockinoutdivshow');
					clock_div_show.innerHTML='';
					clock_div_show.innerHTML=returnstuff.responseText;
					clock_div_show.style.display = 'inline';

					FormatClockMenu();
				}
				function check_cancel_and_submit(caller){
					var answer = confirm('{$clock_strings['IN_OUT_CANCEL_CONFIRM']}');
					if(answer){
						MenuText='{$clock_strings['IN_TITLE']}';
						var url='index.php?module=JCRMTime&action=ClockInOutDo&type=cancel';
						clock_fetch(url);
					}
					else {
						return false;
					}
				}
				function parseTime(s) {
					//remove any zeros before number
					while (s.substring(0,1) == '0') {
						s = s.substring(1, s.length);
					}
					if(s.length==0) s='0';
					return parseInt(s, 10);
				}

				function check_time_and_clock_out(caller, start){
					//var time_input=document.forms['clockinout'].elements['time_end'];
					var time_input=caller.parentNode.getElementsByTagName('INPUT')[0];

					if(time_input.value=='undefined' || time_input.value=='') {
						alert('{$clock_strings['IN_OUT_INVALID_END']}');
						return false;
					}

					if(!isTime(time_input.value)){
						alert('{$clock_strings['IN_OUT_INVALID_END']}');
						return false;
					}

           			var time_end = time_input.value.split(':');
           			time_end[0]=parseTime(time_end[0]);
           			time_end[1]=parseTime(time_end[1]);

           			var time_start = start.split(':');
           			time_start[0]=parseTime(time_start[0]);
           			time_start[1]=parseTime(time_start[1]);

//           			alert('start-'+time_start[0]+' '+time_start[1]);
//           			alert('end-'+time_end[0]+' '+time_end[1]);

           			if(time_end[0]>23 || time_end[0]==0){
						alert('{$clock_strings['IN_OUT_INVALID_HOUR']}');
						return false;
					}
           			if(time_end[1]>59){
						alert('{$clock_strings['IN_OUT_INVALID_MINUTE']}');
						return false;
					}


           			if( ((time_start[0]*60)+time_start[1]) > ((time_end[0]*60)+time_end[1])) {
           				alert('{$clock_strings['IN_OUT_INVALID_AFTER']} ' + start + '.');
           				return false;
           				}

					var url='index.php?module=JCRMTime&action=ClockInOutDo&type=close&time_end=';
					url=url+time_input.value;
					MenuText='{$clock_strings['IN_TITLE']}';
					clock_fetch(url);
				}

				function check_time_and_clock_in(caller, case_id){

					var start=caller.parentNode.getElementsByTagName('INPUT')[0];

					if(start.value=='undefined' || start.value=='') {
						alert('{$clock_strings['IN_OUT_INVALID_START']}');
						return false;
					}

					if(!isTime(start.value)){
						alert('{$clock_strings['IN_OUT_INVALID_START']}');
						return false;
					}

           			var time_start = start.value.split(':');
           			time_start[0]=parseTime(time_start[0]);
           			time_start[1]=parseTime(time_start[1]);

//          			alert('start-'+time_start[0]+' '+time_start[1]);

           			if(time_start[0]>23 || time_start[0]<0){
						alert('{$clock_strings['IN_OUT_INVALID_HOUR_START']}');
						return false;
					}
           			if(time_start[1]>59){
						alert('{$clock_strings['IN_OUT_INVALID_MINUTE_START']}');
						return false;
					}

					var url='index.php?action=ClockInOutDo&module=JCRMTime&type=in&case_id=' + case_id;
					url=url+'&time_start='+start.value;
					MenuText='{$clock_strings['OUT_TITLE']}';
					clock_fetch(url);
				}

				function stop_now() {
					url='index.php?action=ClockInOutDo&module=JCRMTime&type=out';
					MenuText='{$clock_strings['IN_TITLE']}';
					clock_fetch(url);
				}";

		$out.='</script>';

		$out.='<div id = "clockinoutdiv" style="display:none">';
	}

	$fixclock=false;
	$recent_items=false;

	//current work item
	if($curr_id!=''){
		$JCRMTime->retrieve($curr_id);
        //current item is in local date and time and dbformat so when comparing to users date and time dont convert it
        //just format it
        $in_date = $JCRMTime->format_db_date_for_user($JCRMTime->current_item('date'));

		//is this item from before today?
		if($in_date != $JCRMTime->local_date()) {
			//old time item found - need to close before clocking into anything else
			$out.="<p>".$clock_strings['IN_OUT_YOU_CLOCKED_INTO'].$JCRMTime->case_name.$clock_strings['IN_OUT_FOR'].$JCRMTime->account_name;
			$out.=$clock_strings['IN_OUT_AT'].$JCRMTime->time_start.', ';


			$out.=$in_date.$clock_strings['IN_OUT_YOU_MUST'];

			//dont end before start
			if($JCRMTime->get_minutes($JCRMTime->config['DEFAULT_END_TIME']) > $JCRMTime->get_minutes($JCRMTime->time_start) ) {
				$out.='<input type="text" size="5" name="time_end" value="'.	$JCRMTime->config['DEFAULT_END_TIME'] .'">';
				$out.='&nbsp;<input class="button" title="Clock Out" type="button" value="Clock Out" onclick="return check_time_and_clock_out(this, \''.$JCRMTime->time_start.'\'); " />';
			}
			else {
				$out.='<input type="text" size="5" name="time_end" value="'.	$JCRMTime->time_start .'">';
				$out.='&nbsp;<input class="button" title="Clock Out" type="button" value="Clock Out" onclick="return check_time_and_clock_out(this, \''.$JCRMTime->time_start.'\'); " />';
            }

			$out.=' or <a href="#" onclick="return check_cancel_and_submit();">'.$clock_strings['IN_OUT_CANCEL'].'</a>';
   			$out.='</p>';

			$fixclock=true;

		}
		else {
			//found a clock in from today - allow user to clock out or cancel
			$out.="<p>".$clock_strings['IN_OUT_CURRENTLY'].$JCRMTime->case_name.$clock_strings['IN_OUT_FOR'].$JCRMTime->account_name;
			$out.=$clock_strings['IN_OUT_SINCE'].$JCRMTime->time_start;
			$out.='&nbsp;<a href="#" onclick="return check_cancel_and_submit();">'.$clock_strings['IN_OUT_CANCEL'].'</a>';

			if($JCRMTime->get_minutes($JCRMTime->local_time())>=$JCRMTime->get_minutes($JCRMTime->time_start)) {
				$out.=',&nbsp;<a href="#" onclick="return stop_now();">'.$clock_strings['IN_OUT_STOP'].'</a>';
				$out.=$clock_strings['IN_OUT_OR'];
				$out.='<input type="text" size="5" name="time_end" value="'.	$JCRMTime->local_time() .'">';
			}
			else {
				$out.=$clock_strings['IN_OUT_OR'];
				$out.='<input type="text" size="5" name="time_end" value="'.	$JCRMTime->minutes_to_display_time($JCRMTime->get_minutes($JCRMTime->time_start)+1) .'">';
			}

			$out.='&nbsp;<input class="button" title="Clock Out" type="button" value="Clock Out" onclick="return check_time_and_clock_out(this, \''.$JCRMTime->time_start.'\'); " />';

			$out.="</p>";
		}

    }
    else {
    	$out.="<p>".$clock_strings['IN_OUT_NOT_CLOCKED_IN']."</p>";
    }


	//currently selected case

	if(!$fixclock) {

		if($curr_case_id!='' && $curr_case_id!=$JCRMTime->current_item('case_id')) {

			$case=new aCase();
		 	$case->retrieve($curr_case_id);

			if($curr_id!=''){
		 		$out.="<p>".$clock_strings['IN_OUT_STOP_SELECT_CURRENT'];
		 	}
		 	else {
		 		$out.="<p>".$clock_strings['IN_OUT_SELECT_CURRENT'];
		 	}

			$out.='<a href="#" onclick="return check_time_and_clock_in(this, \''.$case->id.'\')">'.$case->name.'</a>';
	 		$out.=$clock_strings['IN_OUT_FOR'].$case->account_name;

			$out.=$clock_strings['IN_OUT_AT'];

			$out.='<input type="text" size="5" value="'.	$JCRMTime->local_time() .'">';

	 		$out.='&nbsp;'.$clock_strings['IN_OUT_TIMESHEET1'].'<a href="index.php?one_case_id='.$case->id . '&one_case_name='.$case->name.'&module=JCRMTime&action=Timesheet&query=true"><img src="themes/Default/images/CreateJCRMTime.gif" width="16" height="16" alt="Enter time for this case"  border="0" align="absmiddle"></a>'.$clock_strings['IN_OUT_TIMESHEET2'];

			$out.='</p>';
		}

		//recent time items
		$list=$JCRMTime->recent_cases();

		if(count($list)>0){
			$recent_items=true;

			if($curr_id!=''){
		 		$out.="<p>".$clock_strings['IN_OUT_STOP_SELECT_RECENT']."<br>";
		 	}
		 	else {
		 		$out.="<p>".$clock_strings['IN_OUT_SELECT_RECENT']."<br>";
		 	}

		 	foreach($list as $line){
		 		if($line['CASE_ID'] != $JCRMTime->current_item('case_id')) {
					$out.='<a href="#" onclick="return check_time_and_clock_in(this, \''.$line['CASE_ID'].'\')">'.$line['CASE_NAME'].'</a>';
			 		$out.=$clock_strings['IN_OUT_FOR'].$line['ACCOUNT_NAME'];

			 		$out.='&nbsp;<a href="index.php?one_case_id='. $line['CASE_ID'] . '&one_case_name='.$line['CASE_NAME'].'&module=JCRMTime&action=Timesheet&query=true"><img src="themes/Default/images/CreateJCRMTime.gif" width="16" height="16" alt="Enter time for this case"  border="0" align="absmiddle"></a>';
			 		$out.="<br>";
		 		}

		 	}

			$out.=$clock_strings['IN_OUT_AT'];

			$out.='<input type="text" size="5" value="'.	$JCRMTime->local_time() .'">';

		 	$out.="</p>";
	 	}
 	}

 	if($curr_id=='' && $curr_case_id=='' && $recent_items==false) {
		$out.="".$clock_strings['IN_OUT_NEW'];
 	}

	if(!$clock_body_only) {
		$out.='</div>';
	//	$out.='</td></tr></table>';
	}

	echo $out;

}
?>
