<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMTime/EnterCheck.php');

require_once('data/SugarBean.php');
require_once('include/database/PearDatabase.php');
require_once('include/utils.php');
include_once('config.php');
require_once('log4php/LoggerManager.php');
require_once('include/TimeDate.php');

class JCRMTime extends SugarBean {
	var $id;
	var $date_entered;
	var $date_modified;
	var $assigned_user_id;
	var $modified_user_id;
	var $created_by;
	var $cache_current_item_id;
	var $cache_current_item_case_id;
	var $deleted;
	var $date;
	var $time_start;
	var $time_end;
	var $time_length;
	var $invoice_id;

	var $invoice_number;
	var $invoice_owner_id;
	var $case_id;

	var $case_name;
	var $case_owner_id;
	var $account_id;
	var $account_name;
	var $account_owner_id;

	var $assigned_user_name;
	var $modified_by_name;
	var $created_by_name;
	var $email_id;
	var $simpleobj_id;

	var $object_name = 'JCRMTime';
	var $module_dir  = 'JCRMTime';
	var $new_schema  = true;
	var $table_name  = 'jcrmtime';

	// This is used to retrieve related fields from form posts.
	var $additional_column_fields = array('account_name', 'case_name',  );

	//used for cases subpanel
	var $relationship_fields = array('case_name',  );

	//config
	var $config;

	var	$dt;

	function JCRMTime(){
		parent::SugarBean();

		if (file_exists('modules/JCRMTime/override_ClockConfig.php')) {
			require_once('modules/JCRMTime/override_ClockConfig.php');
		}
		else {
			require_once('modules/JCRMTime/ClockConfig.php');
		}

		$config = new JCRMTimeConfig();

		$this->config=$config->ClockConfig;

		$this->dt = new TimeDate();

	}

	function create_list_query($order_by, $where, $show_deleted = 0){
		//called by main listview not by subpanels

		$custom_join = $this->custom_fields->getJOIN();
		$query       = "SELECT
		                users.user_name assigned_user_name, cases.name case_name, cases.assigned_user_id case_owner_id,
		                accounts.id account_id, accounts.name account_name, accounts.assigned_user_id account_owner_id,
		                jcrminvoices.invoice_number, jcrminvoices.assigned_user_id invoice_owner_id,
		                jcrmtime.*
		               ";

		if($custom_join){ $query .=  $custom_join['select']; }

			$query .= "     FROM jcrmtime ";
			$query .= "LEFT JOIN users ON users.id=jcrmtime.assigned_user_id ";
			$query .= "LEFT OUTER JOIN cases ON cases.id=jcrmtime.case_id ";
			$query .= "LEFT OUTER JOIN accounts ON accounts.id=jcrmtime.account_id ";
			$query .= "LEFT OUTER JOIN jcrminvoices ON jcrminvoices.id=jcrmtime.invoice_id ";

			if($custom_join){ $query .=  $custom_join['join']; }

		$where_auto = '1=1';

		if($show_deleted == 0){
			$where_auto = "$this->table_name.deleted!=1";
		}else if($show_deleted == 1){
			$where_auto = "$this->table_name.deleted=1";
		}
		if($where != '')
			$query .= "WHERE ($where) AND ".$where_auto;
		else
			$query .= "WHERE ".$where_auto;

		if(!empty($order_by))
			$query .= " ORDER BY $order_by";

		return $query;
	}

	function create_export_query($order_by, $where){
		$custom_join = $this->custom_fields->getJOIN();
		$query       = "SELECT users.user_name assigned_user_name, jcrmtime.*";
		if($custom_join){ $query .=  $custom_join['select']; }
		$query .= " FROM jcrmtime ";
		$query .= "LEFT JOIN users ON jcrmtime.assigned_user_id=users.id ";

		if($custom_join){ $query .=  $custom_join['join']; }
		$where_auto  = '1=1';
		if($show_deleted == 0){
			$where_auto = "$this->table_name.deleted=0";
		}else if($show_deleted == 1){
			$where_auto = "$this->table_name.deleted=1";
		}
		if($where != '')
			$query .= "WHERE ($where) AND ".$where_auto;
		else
			$query .= "WHERE ".$where_auto;

		if(!empty($order_by))
			$query .= " ORDER BY $order_by";

		return $query;
	}

	function fill_in_additional_detail_fields(){
		//called by DetailView

		$this->assigned_user_name = get_assigned_user_name($this->assigned_user_id);


		$query  = " SELECT c.name, c.assigned_user_id case_owner_id, a.id account_id, a.name account_name, a.assigned_user_id account_owner_id, jcrminvoices.invoice_number ";
		$query .= " FROM cases c, accounts a, jcrmtime t ";
 	    $query .= " LEFT OUTER JOIN jcrminvoices ON jcrminvoices.id=t.invoice_id ";
		$query .= " WHERE c.id='".$this->case_id."' AND c.deleted=0 and a.id=c.account_id and t.case_id = c.id";

		$result =$this->db->query($query,true," Error filling in additional detail fields: ");

		// Get the id and the name.
		$row = $this->db->fetchByAssoc($result);

		if($row != null)
		{
			$this->case_name = $row['name'];
            $this->case_owner_id = $row['case_owner_id'];

			$this->account_id = $row['account_id'];
			$this->account_name = $row['account_name'];
			$this->account_owner_id = $row['account_owner_id'];

			$this->invoice_number = $row['invoice_number'];

       	}

		$this->created_by_name = get_assigned_user_name($this->created_by);
		$this->modified_by_name = get_assigned_user_name($this->modified_user_id);


  }

	function fill_in_additional_list_fields(){
		//we get our data in the listview load
		return;
	}

	function get_summary_text(){
		return $this->case_name;
	}

	function build_generic_where_clause ($the_query_string){
		$where_clauses    = array();
		$the_query_string = PearDatabase::quote(from_html($the_query_string));
		array_push($where_clauses, "jcrmtime.name LIKE '%$the_query_string%'");
		$the_where = '';
		foreach($where_clauses as $clause){
			if($the_where != '') $the_where .= " OR ";
			$the_where .= $clause;
		}
		return $the_where;
	}

	function get_list_view_data(){
		//called for each row in main listview or subpanel
		$field_list                       = $this->get_list_view_array();
		$field_list['USER_NAME']          = empty($this->user_name) ? '' : $this->user_name;
		$field_list['ASSIGNED_USER_NAME'] = $this->assigned_user_name;

		//and fix custom timeneg data type
		$field_list['TIME_LENGTH']=$this->db_to_display_time($field_list['TIME_LENGTH']);

		return $field_list;
	}

	function listviewACLHelper(){
	    //called by each row in listview but not called by sub panels
		$array_assign = parent::listviewACLHelper();
		$is_case_owner = false;
		$is_account_owner = false;
		$is_invoice_owner = false;
		global $current_user;

		if(!empty($this->case_id)){

			if(!empty($this->account_owner_id)){
				$is_account_owner = $current_user->id == $this->account_owner_id;
			}
			if(!empty($this->case_owner_id)){
				$is_case_owner = $current_user->id == $this->case_owner_id;
			}
		}

		if(!empty($this->invoice_id)){
			if(!empty($this->invoice_owner_id)){
				$is_invoice_owner = $current_user->id == $this->invoice_owner_id;
			}
		}

		if(!ACLController::moduleSupportsACL('Accounts') || ACLController::checkAccess('Accounts', 'view', $is_account_owner)){
			$array_assign['ACCOUNT'] = 'a';
		}else{
			$array_assign['ACCOUNT'] = 'span';
		}

		if(!ACLController::moduleSupportsACL('Cases') || ACLController::checkAccess('Cases', 'view', $is_case_owner)){
			$array_assign['CASE'] = 'a';
		}else{
			$array_assign['CASE'] = 'span';
		}

		if(!ACLController::moduleSupportsACL('JCRMInvoices') || ACLController::checkAccess('JCRMInvoices', 'view', $is_invoice_owner)){
			$array_assign['INVOICE'] = 'a';
		}else{
			$array_assign['INVOICE'] = 'span';
		}

		return $array_assign;
	}

	function save($check_notify = FALSE) {
		return parent::save($check_notify);
	}

	function bean_implements($interface){
	 	switch($interface){
	  		case 'ACL':return true;
	 	}
	 	return false;
	}

	function current_item($field) {
		if(isset($this->cache_current_item)) {
			if(is_array($this->cache_current_item)) {
				return $this->cache_current_item[$field];
			}
			return '';
		}

		global $current_user;

		$sql="select t.id, t.case_id, t.date from jcrmtime t where assigned_user_id='".$current_user->id."' and t.time_start is not null and t.time_end is null and t.deleted=0";

		$result = $this->db->query($sql, true, "Unable to retrieve current jcrmtime item");
		if (empty($result)) {
			$this->cache_current_item='';
			return '';
		}

		//assume only 1 item being worked on
		$row = $this->db->fetchByAssoc($result, -1, true);

		$this->cache_current_item=$row;

		return $this->cache_current_item[$field];
	}

	function recent_cases() {
		global $current_user;

		//partial mssql - add in t.date which is referenced in order
		//removed t.date as wrong list is returned (too many cases)
		$query  = " SELECT distinct c.id CASE_ID, c.name CASE_NAME, a.name ACCOUNT_NAME, c.CASE_NUMBER ";
		$query .= " FROM cases c, accounts a, jcrmtime t ";
		$query .= " WHERE ";
		$query .= " t.assigned_user_id='".$current_user->id."' and t.deleted=0 ";

		if($this->current_item('case_id')!='') {
			$query .= " AND c.id !='".$this->current_item('case_id')."'";
		}

		$query .= " AND c.id=t.case_id ";
		$query .= " AND c.deleted=0";
		$query .= " AND a.id=c.account_id ";
//		$query .= " order by t.date desc limit 10";
		$query .= " order by t.date desc";

//		$result = $this->db->query($query, true, "Unable to retrieve recent cases");
		$result = $this->db->limitQuery($query, 0, 10, true, "Unable to retrieve recent cases");
		if (empty($result)) {
			return '';
		}

		$list=array();

		while ($row = $this->db->fetchByAssoc($result, -1, true))
		{
           	$line=array();
			$line['CASE_ID'] = $row['CASE_ID'];
			$line['CASE_NAME'] = $row['CASE_NAME'].' (Case '. $row['CASE_NUMBER'] .')';
			$line['ACCOUNT_NAME'] = $row['ACCOUNT_NAME'];
			$list[]=$line;
       	}

		return $list;
	}

	function get_minutes( $time )
	{
	if ($time=="") {
		return 0;
		}
		else {
		if(substr($time, 0, 1) == '-') {
	    	list( $neg, $hour, $minute) = split( '([^0-9])', $time );
	    	return 0 - (($hour * 60) + $minute);
		}
		else {
	    	list( $hour, $minute) = split( '([^0-9])', $time );
	    	return ($hour * 60) + $minute;
	    }
	    }
	}

	function calc_minutes() {
		$diff=$this->get_minutes($this->time_end)-$this->get_minutes($this->time_start);
		return $diff;
 	}

	function db_to_display_time($dbtime) {
		//remove the minutes and don't pad hours e.g. -H:MM
		/*echo "convert $dbtime <br>";
		echo "equals minutes" . $this->get_minutes($dbtime) .'<br>';
		echo "shown as ". $this->minutes_to_display_time($this->get_minutes($dbtime)) .'<br><br>';*/

		return $this->minutes_to_display_time($this->get_minutes($dbtime));
	}

 	function minutes_to_db_time($minutes) {
		return $this->minutes_to_display_time($minutes).':00';
 	}

 	function minutes_to_display_time($minutes) {
 		$remain=abs($minutes);

        //hours
 		$ret=intval($remain/60).':';

 		//minutes
		$remain = abs($remain%(60));
		if($remain<10) $ret.='0';
 		$ret.=$remain;

 		//neg
 		if ($minutes < 0) $ret ='-'.$ret;

		return $ret;
 	}

	function time_length_minutes () {
		return $this->get_minutes($this->time_length);
	}

 	function stop_current($override_time_end='') {
		$curr_id=$this->current_item('id');
		if($curr_id!=''){
			$current = new JCRMTime();
			$current->retrieve($curr_id);
			if($override_time_end !='') {
				$current->time_end=$override_time_end;
			}
			else {
				$current->time_end=$this->local_time();
			}
			$current->time_length=$current->minutes_to_db_time($current->calc_minutes());
	       	$current->track_on_save=false;
			$current->save();
		}
 	}

 	function cancel_current($override_time_end='') {
		$curr_id=$this->current_item('id');
		if($curr_id!=''){
			$this->mark_deleted($curr_id);
			unset($this->cache_current_item);
		}
 	}

 	function create_new($case_id, $time_start=''){
		global $current_user;
  		require_once('modules/Cases/Case.php');
  		$case=new aCase();
  		$case->retrieve($case_id);


		$newtime = new JCRMTime();
		$newtime->case_id=$case->id;
		$newtime->account_id=$case->account_id;

		$newtime->assigned_user_id=$current_user->id;
       	$newtime->date = $this->local_date();

		if($time_start=='') {
			$newtime->time_start = $this->local_time();
        }
        else {
			$newtime->time_start = $time_start;
        }

       	$newtime->track_on_save=false;
		$newtime->save(false);
 	}

 	function get_clock() {
 		if(ACLController::checkAccess('JCRMTime', 'edit', true)) {
	 		ob_start();
	 		include('modules/JCRMTime/ClockInOut.php');
	 		$result=ob_get_clean();
			return $result;
		}
 	}

	function create_timesheet_list($order_by, $user_id, $start_date, $end_date, $show_deleted = 0, $case_id=''){
		//convert dates to system  - start and end are in user format
		$datenum = strtotime($this->format_user_date_for_db($start_date));
		$entry_date=gmdate('Y-m-d', $datenum-(32*86400));
		//echo "datenum is $datenum and entry date is $entry_date <br> ";
		$start_date=$this->format_user_date_for_db($start_date);
		$end_date=$this->format_user_date_for_db($end_date);

		//all time for selected user and selected period regardless of who owns the case etc
		$query       = "SELECT
                   cases.id CASE_ID, concat(cases.name, ' (Case: ', cases.case_number, ')')  CASE_NAME, cases.assigned_user_id CASE_OWNER_ID,
                   accounts.id ACCOUNT_ID, accounts.name ACCOUNT_NAME, accounts.assigned_user_id ACCOUNT_OWNER_ID,
                   sec_to_time(sum(if(dayofweek(jcrmtime.date)=2, time_to_sec(jcrmtime.time_length), 0))) MON,
                   sum(if(dayofweek(jcrmtime.date)=2 and jcrmtime.invoice_id is not null , 1, 0)) MON_INVOICE,
                   sec_to_time(sum(if(dayofweek(jcrmtime.date)=3, time_to_sec(jcrmtime.time_length), 0))) TUE,
                   sum(if(dayofweek(jcrmtime.date)=3 and jcrmtime.invoice_id is not null , 1, 0)) TUE_INVOICE,
                   sec_to_time(sum(if(dayofweek(jcrmtime.date)=4, time_to_sec(jcrmtime.time_length), 0))) WED,
                   sum(if(dayofweek(jcrmtime.date)=4 and jcrmtime.invoice_id is not null , 1, 0)) WED_INVOICE,
                   sec_to_time(sum(if(dayofweek(jcrmtime.date)=5, time_to_sec(jcrmtime.time_length), 0))) THU,
                   sum(if(dayofweek(jcrmtime.date)=5 and jcrmtime.invoice_id is not null , 1, 0)) THU_INVOICE,
                   sec_to_time(sum(if(dayofweek(jcrmtime.date)=6, time_to_sec(jcrmtime.time_length), 0))) FRI,
                   sum(if(dayofweek(jcrmtime.date)=6 and jcrmtime.invoice_id is not null , 1, 0)) FRI_INVOICE,
                   sec_to_time(sum(if(dayofweek(jcrmtime.date)=7, time_to_sec(jcrmtime.time_length), 0))) SAT,
                   sum(if(dayofweek(jcrmtime.date)=7 and jcrmtime.invoice_id is not null , 1, 0)) SAT_INVOICE,
                   sec_to_time(sum(if(dayofweek(jcrmtime.date)=1, time_to_sec(jcrmtime.time_length), 0))) SUN,
                   sum(if(dayofweek(jcrmtime.date)=1 and jcrmtime.invoice_id is not null , 1, 0)) SUN_INVOICE
                  ";

		$query .= "FROM jcrmtime ";
		$query .= "LEFT JOIN users ON users.id=jcrmtime.assigned_user_id ";
		$query .= "LEFT JOIN cases ON cases.id=jcrmtime.case_id ";
		$query .= "LEFT JOIN accounts ON accounts.id=cases.account_id ";

		$query .= "WHERE jcrmtime.assigned_user_id='$user_id' AND jcrmtime.date between '$start_date' and '$end_date' AND jcrmtime.deleted!=1";

		//are we entering time for only 1 case?
		if($case_id != '')
		$query .= " AND jcrmtime.case_id = '$case_id'";

	    $query .= ' GROUP BY  cases.id, cases.name, cases.assigned_user_id,
	                   accounts.id, accounts.name, accounts.assigned_user_id';

		//are we entering time for only 1 case?
		if($case_id != '') {
			//so now include the case if there was no time entered this week
			$query.= " UNION SELECT cases.id CASE_ID, concat(cases.name, ' (Case: ', cases.case_number, ')') CASE_NAME, cases.assigned_user_id CASE_OWNER_ID,
		                   accounts.id ACCOUNT_ID, accounts.name ACCOUNT_NAME, accounts.assigned_user_id ACCOUNT_OWNER_ID,
							0,0,0,0,0,0,0,0,0,0,0,0,0,0";

		   	$query .= " FROM cases ";
		   	$query .= " LEFT JOIN accounts ON accounts.id=cases.account_id ";
		   	$query .= " LEFT JOIN jcrmtime ON jcrmtime.case_id=cases.id and jcrmtime.date between '$start_date' AND '$end_date' AND jcrmtime.deleted!=1";
		   	$query .= " WHERE cases.id = '$case_id'";
			$query .= " AND jcrmtime.id is null ";
		}
		else {

			//include all cases assigned to user an not closed and with no time entered for period or within last month
			$query.= " UNION SELECT cases.id CASE_ID, concat(cases.name, ' (Case: ', cases.case_number, ')') CASE_NAME, cases.assigned_user_id CASE_OWNER_ID,
		                   accounts.id ACCOUNT_ID, accounts.name ACCOUNT_NAME, accounts.assigned_user_id ACCOUNT_OWNER_ID,
							0,0,0,0,0,0,0,0,0,0,0,0,0,0";

		   	$query .= " FROM cases ";
		   	$query .= " LEFT JOIN accounts ON accounts.id=cases.account_id ";
		   	$query .= " LEFT JOIN jcrmtime ON jcrmtime.case_id=cases.id and jcrmtime.date between '$entry_date' AND '$end_date' AND jcrmtime.deleted!=1";

			if (isset($this->config['CASE_STATUS_WHERE']))
		   		$query .= " WHERE {$this->config['CASE_STATUS_WHERE']} AND ";
		   	else
			   	$query .= " WHERE ";

			$query .= " cases.date_entered <='$start_date' AND cases.assigned_user_id = '$user_id' AND jcrmtime.id is null ";

			//include all cases with time entered in last month that are not closed
			// and do not have any time entered in the period
			$query .= " UNION SELECT cases.id CASE_ID, concat(cases.name, ' (Case: ', cases.case_number, ')') CASE_NAME, cases.assigned_user_id CASE_OWNER_ID,
		                   accounts.id ACCOUNT_ID, accounts.name ACCOUNT_NAME, accounts.assigned_user_id ACCOUNT_OWNER_ID,
							0,0,0,0,0,0,0,0,0,0,0,0,0,0";

		   	$query .= " FROM cases ";
		   	$query .= " LEFT JOIN accounts ON accounts.id=cases.account_id ";
		   	$query .= " LEFT OUTER JOIN jcrmtime tperiod ON tperiod.case_id=cases.id and tperiod.date between '$start_date' AND '$end_date' AND tperiod.assigned_user_id = '$user_id' AND tperiod.deleted!=1";
		   	$query .= " LEFT OUTER JOIN jcrmtime tbefore ON tbefore.case_id=cases.id and tbefore.date between '$entry_date' AND '$start_date' AND tbefore.assigned_user_id = '$user_id' AND tbefore.deleted!=1";

			if(isset($this->config['CASE_STATUS_WHERE']))
		   		$query .= " WHERE {$this->config['CASE_STATUS_WHERE']} AND";
		   	else
				$query .= " WHERE ";

			$query .= " tperiod.id is null AND tbefore.id is not null";
        }

		if(!empty($order_by))
		 $query .= " ORDER BY $order_by";

		$result = $this->db->query($query, true, "Unable to retrieve timesheet");
		if (empty($result)) {
			return '';
		}

		global $current_user;

		$list=array();

		while ($row = $this->db->fetchByAssoc($result, -1, true))
		{

	       	$line=array();
			$line['CASE_ID'] = $row['CASE_ID'];
			$line['CASE_NAME'] = $row['CASE_NAME'];
			$line['CASE_OWNER_ID'] = $row['CASE_OWNER_ID'];
			$line['ACCOUNT_NAME'] = $row['ACCOUNT_NAME'];
			$line['ACCOUNT_ID'] = $row['ACCOUNT_ID'];
			$line['ACCOUNT_NAME'] = $row['ACCOUNT_NAME'];
			$line['ACCOUNT_OWNER_ID'] = $row['ACCOUNT_OWNER_ID'];

			$line['MON'] = $row['MON']=='0' || $row['MON']=='00:00:00' ? '' : $this->db_to_display_time($row['MON']);
			if($row['MON_INVOICE']=='0'){
				//not read only
				$line['MON_TYPE'] = 'text';
				$line['MON_READ_ONLY'] = '';
			}
			else {
				//read only - has been invoiced
				$line['MON_TYPE'] = 'hidden';
				$line['MON_READ_ONLY'] = $line['MON'];
			}

			$line['TUE'] = $row['TUE']=='0' || $row['TUE']=='00:00:00' ? '' : $this->db_to_display_time($row['TUE']);
			if($row['TUE_INVOICE']=='0'){
				//not read only
				$line['TUE_TYPE'] = 'text';
				$line['TUE_READ_ONLY'] = '';
			}
			else {
				//read only - has been invoiced
				$line['TUE_TYPE'] = 'hidden';
				$line['TUE_READ_ONLY'] = $line['TUE'];
			}

			$line['WED'] = $row['WED']=='0' || $row['WED']=='00:00:00' ? '' : $this->db_to_display_time($row['WED']);
			if($row['WED_INVOICE']=='0'){
				//not read only
				$line['WED_TYPE'] = 'text';
				$line['WED_READ_ONLY'] = '';
			}
			else {
				//read only - has been invoiced
				$line['WED_TYPE'] = 'hidden';
				$line['WED_READ_ONLY'] = $line['WED'];
			}

			$line['THU'] = $row['THU']=='0' || $row['THU']=='00:00:00' ? '' : $this->db_to_display_time($row['THU']);
			if($row['THU_INVOICE']=='0'){
				//not read only
				$line['THU_TYPE'] = 'text';
				$line['THU_READ_ONLY'] = '';
			}
			else {
				//read only - has been invoiced
				$line['THU_TYPE'] = 'hidden';
				$line['THU_READ_ONLY'] = $line['THU'];
			}

			$line['FRI'] = $row['FRI']=='0' || $row['FRI']=='00:00:00' ? '' : $this->db_to_display_time($row['FRI']);
			if($row['FRI_INVOICE']=='0'){
				//not read only
				$line['FRI_TYPE'] = 'text';
				$line['FRI_READ_ONLY'] = '';
			}
			else {
				//read only - has been invoiced
				$line['FRI_TYPE'] = 'hidden';
				$line['FRI_READ_ONLY'] = $line['FRI'];
			}

			$line['SAT'] = $row['SAT']=='0' || $row['SAT']=='00:00:00' ? '' : $this->db_to_display_time($row['SAT']);
			if($row['SAT_INVOICE']=='0'){
				//not read only
				$line['SAT_TYPE'] = 'text';
				$line['SAT_READ_ONLY'] = '';
			}
			else {
				//read only - has been invoiced
				$line['SAT_TYPE'] = 'hidden';
				$line['SAT_READ_ONLY'] = $line['SAT'];
			}

			$line['SUN'] = $row['SUN']=='0' || $row['SUN']=='00:00:00' ? '' : $this->db_to_display_time($row['SUN']);
			if($row['SUN_INVOICE']=='0'){
				//not read only
				$line['SUN_TYPE'] = 'text';
				$line['SUN_READ_ONLY'] = '';
			}
			else {
				//read only - has been invoiced
				$line['SUN_TYPE'] = 'hidden';
				$line['SUN_READ_ONLY'] = $line['SUN'];
			}

			$is_account_owner = $current_user->id == $row['ACCOUNT_OWNER_ID'];
			$is_case_owner = $current_user->id == $row['CASE_OWNER_ID'];

			if(!ACLController::moduleSupportsACL('Accounts') || ACLController::checkAccess('Accounts', 'view', $is_account_owner)){
				$line['TAG_ACCOUNT'] = 'a';
			}else{
				$line['TAG_ACCOUNT'] = 'span';
			}

			if(!ACLController::moduleSupportsACL('Cases') || ACLController::checkAccess('Cases', 'view', $is_case_owner)){
				$line['TAG_CASE'] = 'a';
			}else{
				$line['TAG_CASE'] = 'span';
			}



			$list[]=$line;
      	}

		return $list;
	}

 	//return a JCRMTIme object - db_date is in db format and should be treated as is the local date, so dont convert given users timezone
	function set_timesheet_cell($db_date, $account_id, $case_id, $assigned_user_id, $time) {
		// the following should only return 1 record max will be set if there is an existing override cell, base will be the total time clocked in
		$sql="select t.date, max(if(t.time_start is null, t.id, '')) id, sec_to_time(sum(time_to_sec(if(t.time_start is not null, t.time_length, 0)))) base
		 from jcrmtime t where t.assigned_user_id='".$assigned_user_id."' and t.case_id='".$case_id."' and t.date='".$db_date."' and t.deleted=0 group by t.date";

		$result = $this->db->query($sql, true, "Unable to retrieve jcrmtime timesheet cell");
		$row = $this->db->fetchByAssoc($result, -1, true);
		//will always return 1 row  id will be set if there is an existing cell, base will be the total of clocked entries
		//always save back an adjusted cell so the total is correct
		//e.g. base is 01:15 but new value is 2:00 so cell equals 0:45

		$diff=$this->get_minutes($time)-$this->get_minutes($row['base']);
		$diff=$this->minutes_to_db_time($diff);

		if (empty($row['id']) || $row['id']=='') {
			//create a new cell
			$new=new JCRMTime();
			$new->assigned_user_id=$assigned_user_id;
	        $new->date = $this->format_db_date_for_user($db_date);
			$new->case_id=$case_id;
			$new->account_id=$account_id;
			$new->time_start='';
			$new->time_end='';
			$new->time_length=$diff;
	       	$new->track_on_save=false;
			$new->save(false);
//	  		echo "new record saved with $diff for $db_date";
			return;
		}

		//if zero delete existing cell as there are no manual enties
  		if ((empty($row['base']) || $row['base']=='00:00:00') && $time=='0:00') {

			$existing=new JCRMTime;
			$existing->retrieve($row['id']);
			if($existing->invoice_id!='') {
				return 'Error Updating Time - already invoiced<br>';
			}
			$existing->mark_deleted($row['id']);
//			echo "deleting existing cell";
			return;
		}

		//update existing row
		$existing=new JCRMTime;
		$existing->retrieve($row['id']);

		if($existing->invoice_id!='') {
			return 'Error Updating Time - already invoiced<br>';
		}

		$existing->time_length=$diff;
       	$existing->track_on_save=false;
		$existing->save(false);
//		echo "updated existing cell {$row['id']} to $diff";
		return;

	}

	function track_view($user_id, $current_module) {
		//dont track time records
	}

	function local_time() {
		 return $this->dt->to_display_time($this->dt->get_gmt_db_datetime());
	}

	function local_date() {
		 return $this->dt->to_display_date($this->dt->get_gmt_db_datetime());
	}

	function format_db_date_for_user($date) {
		return $this->dt->swap_formats($date, $this->dt->dbDayFormat,$this->dt->get_date_format());
	}
	function format_user_date_for_db($date) {
		return $this->dt->swap_formats($date, $this->dt->get_date_format(),$this->dt->dbDayFormat);
	}

	function get_union_related_list($parentbean, $order_by = "", $sort_order='', $where = "",
		$row_offset = 0, $limit=-1, $max=-1, $show_deleted = 0, $subpanel_def)
		{
			$final_query='select sec_to_time(sum(time_to_sec(jcrmtime.time_length))), jcrmtime.date, accounts.name account_name, cases.name case_name, users.first_name assigned_user_name';
			$final_query.=' from jcrmtime, accounts, cases, users';
			$final_query.=" WHERE accounts.id=jcrmtime.account_id and cases.id=jcrmtime.case_id and users.id=jcrmtime.assigned_user_id and jcrmtime.invoice_id='".$_REQUEST['record']."'";
			$final_query.='	GROUP BY 2, 3, 4, 5 ';

			$final_query_rows='select count(*) from (select sec_to_time(sum(time_to_sec(jcrmtime.time_length))), jcrmtime.date, accounts.name account_name, cases.name case_name, users.first_name assigned_user_name';
			$final_query_rows.=' from jcrmtime, accounts, cases, users';
			$final_query_rows.=" WHERE accounts.id=jcrmtime.account_id and cases.id=jcrmtime.case_id and users.id=jcrmtime.assigned_user_id and jcrmtime.invoice_id='".$_REQUEST['record']."'";
			$final_query_rows.='	GROUP BY 2, 3, 4, 5 )';

			$secondary_queries = array();

			return $parentbean->process_union_list_query($parentbean, $final_query, $row_offset, $limit, $max, '',$subpanel_def, $final_query_rows, $secondary_queries);
    }


 }
 ?>
