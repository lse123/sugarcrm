<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
//this file is replaced each time you install a new version of Time and Invoicing
//in order to preserve your changes, copy this file to a new file called /modules/JCRMTime/override_ClockConfig.php
//and make your changes to the override file. Remember to check this file for new config options in later releases

class JCRMTimeConfig {
	var $ClockConfig=array(	'DEFAULT_END_TIME'=>'17:30',
					'CASE_STATUS_WHERE' => "cases.status not like 'Closed%'",
					);
}


?>
