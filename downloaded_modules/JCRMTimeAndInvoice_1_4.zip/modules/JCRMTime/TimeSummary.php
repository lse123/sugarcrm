<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMTime/EnterCheck.php');
require_once('modules/JCRMReports/JCRMReport.php');
require_once('modules/JCRMTime/JCRMTime.php');

global $mod_strings;

$JCRMTime = new JCRMTime();

$rpt_info=array( "title"=> $mod_strings['TIME_SUMMARY_TITLE'],
			  "module" => "JCRMTime",
			  "menu_module" => "JCRMTime",  //location (module) of calling file
			  "menu_action" => "TimeSummary",//name of calling file
			  "sql_select" => "users.user_name, jcrmtime.assigned_user_id, concat(users.first_name, ' ', users.last_name) 'User'",
			  "sql_from" => "jcrmtime, users, cases",
			  "sql_where_join" => "users.id=jcrmtime.assigned_user_id and cases.id=jcrmtime.case_id and jcrmtime.deleted!=1 and cases.deleted!=1",
			  "sql_group_by" => "1, 2, 3",
			  "sql_order_by" => "3",
			  "criteria_required"=>true,
			  "columns" => array("assigned_user_id"=>array("query_only"=>true),
			  					"user_name"=>array("query_only"=>true)),//colname=array(callback=>'', query_only=>bool)
		  );

function DisplayTimeCell($row, $key, $value) {
	return '<a  href="index.php?module=JCRMTime&action=Timesheet&query=true&assigned_user_id='.$row['assigned_user_id'].'&assigned_user_name='.$row['user_name'].'&date='.$key.'" class="listViewTdLinkS1">' . $value.'</a>';
}


if(!isset($_REQUEST['option'])) {
	//show report using default criteria so user can then select option=Report
	$date_start= substr($JCRMTime->format_user_date_for_db($JCRMTime->local_date()), 0, 8).'01';
	$date_end=date('Y-m-d', strtotime("-1 day", strtotime("+1 Month", strtotime($date_start))));


	$filter = array( "rows"=> array(1=> array( 	"name"=> "date",
		 									"operator_desc"=> "BETWEEN",
		 									"value"=> "",
		 									"type" => "date",
		 									"operator" => "BETWEEN",
		 									"value_arr" => array(1=> array("value" => $date_start,
		 																   "desc" => $JCRMTime->format_db_date_for_user($date_start)
		 																   ),
		 														 2=> array("value" => $date_end,
		 														 		   "desc"=> $JCRMTime->format_db_date_for_user($date_end)
		 														 		   )
		 														 ),
		 									"value_desc"=> "(Between x and y)",
		 									"force"=>'true',
									  ),

							 ),
				"count"=> 1,
		);

	$rpt = new JCRMReport($rpt_info, $filter);

	echo $rpt->select_html();

}
else {
	//User has requested the report itself
	$rpt = new JCRMReport($rpt_info);
	//generally would only need the next line but this is a dynamic cross tab query
	//echo $rpt->report_html();

	//we need to build a cross tab query
	//first get a list of all weeks for the selected criteria

	$rpt->sql_select="YEARWEEK(jcrmtime.date, 7) 'col', str_to_date(concat(YEARWEEK(jcrmtime.date, 7), ' Monday'),'%x%v %W') 'heading'";
	$rpt->sql_group_by = "1,2";
	$rpt->sql_order_by = "1";

//echo $rpt->report_sql();

	$result = $rpt->db->query($rpt->report_sql(), true, "Unable to retrieve report");
	if (empty($result)) {
		echo 'Error building report.';
		die;
	}

	//now build a sql_from to include these weeks
	$sql='';
	while ($row = $rpt->db->fetchByAssoc($result, -1, true))	{
		if(!$sql=='') $sql.=", ";
		$heading=$JCRMTime->format_db_date_for_user($row['heading']);
		$sql.="TIME_FORMAT(SEC_TO_TIME(SUM(IF(YEARWEEK(jcrmtime.date, 7) = '".$row['col']."', TIME_TO_SEC(jcrmtime.time_length),0))), '%H:%i') AS '" . $heading. "'";
		$rpt->columns[$heading]=array("callback"=>'DisplayTimeCell');
	}

	if($sql=='') {
		//no time to report
   		echo $rpt->select_html();
		echo $mod_strings['NO_TIME'] . $rpt->arr['desc']. ".<br>";
		die;
	}

	$rpt->sql_select= "users.user_name, jcrmtime.assigned_user_id, concat(IFNULL(users.first_name, ''), ' ', IFNULL(users.last_name, '')) 'User', " . $sql;
	$rpt->sql_group_by = "1, 2, 3";
	$rpt->sql_order_by = "3";

	//now run the report
	echo $rpt->select_html();
	echo $rpt->report_html();
}

?>
