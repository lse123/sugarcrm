<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMTime/EnterCheck.php');

//we are not a subpanel for other modules
$layout_defs['JCRMTime'] = array();

?>
