<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMTime/EnterCheck.php');

global $current_user;
global $mod_strings;
$module_menu = array();

if(ACLController::checkAccess('JCRMTime', 'list', true))
 $module_menu[] = array('index.php?module=JCRMTime&action=Timesheet', $mod_strings['LNK_TIMESHEET'], 'CreateJCRMTime');
if(ACLController::checkAccess('JCRMTime', 'list', true))
 $module_menu[] = array('index.php?module=JCRMTime&action=TimeSummary', $mod_strings['LNK_TIME_SUMMARY'], 'JCRMTime');
if(ACLController::checkAccess('JCRMTime', 'list', true))
 $module_menu[] = array('index.php?module=JCRMTime&action=ListView', $mod_strings['LNK_LIST_JCRMTIME'], 'JCRMTime');
?>
