<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMTime/EnterCheck.php');
require_once('XTemplate/xtpl.php');
require_once('include/ListView/ListView.php');
require_once('log4php/LoggerManager.php');
require_once('include/modules.php');
require_once('modules/JCRMTime/JCRMTime.php');

global $current_language;
global $app_strings;
global $image_path;

global $theme;
$theme_path = 'themes/' . $theme . '/';
$image_path = $theme_path .'images/';

require_once($theme_path . 'layout_utils.php');
global $mod_strings;

echo "\n<p>\n";
echo get_module_title('', "<IMG src='themes/Default/images/JCRMTime.gif' width='16' height='16' border='0' style='margin-top: 3px;'>&nbsp;".$mod_strings['LBL_MODULE_TITLE'], true);
echo "\n</p>\n";

//version 5 error - removed 2 lines (not needed anyway?)
//include('include/QuickSearchDefaults.php');
//echo $qsScripts;

if (!isset($where)) $where = '';
require_once('modules/MySettings/StoreQuery.php');
$storeQuery = new StoreQuery();
if($_REQUEST['action'] == 'index' || $_REQUEST['action'] == 'ListView'){
	if(!isset($_REQUEST['query'])){
		$storeQuery->loadQuery($currentModule);
		$storeQuery->populateRequest();
	}else{
		$storeQuery->saveFromGet($currentModule);
	}
}
$seedJCRMTime = new JCRMTime();
$where_clauses = array();

if(isset($_REQUEST['query'])){
	// we have a query
	if (isset($_REQUEST['current_user_only'])) $current_user_only = $_REQUEST['current_user_only'];
	if(isset($_REQUEST['assigned_user_id'])) $assigned_user_id = $_REQUEST['assigned_user_id'];

	if (isset($_REQUEST['date_from'])) $date_from = $_REQUEST['date_from'];
	if (isset($_REQUEST['date_to'])) $date_to = $_REQUEST['date_to'];
	if (isset($_REQUEST['account_name'])) $account_name = $_REQUEST['account_name'];
	if (isset($_REQUEST['case_name'])) $case_name = $_REQUEST['case_name'];

	require_once('include/TimeDate.php');
	$dt = new TimeDate();

	if(isset($date_from) && $date_from != "") {
		$convdt = $dt->swap_formats($date_from, $dt->get_date_format(), $dt->dbDayFormat);
		array_push($where_clauses, "jcrmtime.date >= '$convdt 00:00:00'");
	}
	if(isset($date_to) && $date_to != "") {
		$convdt = $dt->swap_formats($date_to, $dt->get_date_format(), $dt->dbDayFormat);
		array_push($where_clauses, "jcrmtime.date <= '$convdt 23:59:59'");
	}

	if(isset($current_user_only) && $current_user_only != "") array_push($where_clauses, "jcrmtime.assigned_user_id='$current_user->id'");

	if (isset($assigned_user_id) && is_array($assigned_user_id))
	{
		$count = count($assigned_user_id);
		if ($count > 0 ) {
			if (!empty($where)) {
				$where .= " AND ";
			}
			$where .= "jcrmtime.assigned_user_id IN(";
			foreach ($assigned_user_id as $key => $val) {
				$where .= "'$val'";
				$where .= ($key == count($assigned_user_id) - 1) ? ")" : ", ";
			}

			array_push($where_clauses, $where);
		}

	}

	if(isset($account_name) && $account_name != "") array_push($where_clauses, "accounts.name like '%".PearDatabase::quote($account_name)."%'");
	if(isset($case_name) && $case_name != "") array_push($where_clauses, "cases.name like '%".PearDatabase::quote($case_name)."%'");


	$where = '';
	foreach($where_clauses as $clause){
		if($where != '')
		$where .= ' AND ';
		$where .= $clause;
	}
	$GLOBALS['log']->info("Here is the where clause for the list view: $where");
}

$seed = new JCRMTime();

if(empty($_REQUEST['search_form'])){
	$search_form = new XTemplate('modules/JCRMTime/SearchForm.html');

	$header_text = '';
	$header = get_form_header($mod_strings['LBL_SEARCH_FORM_TITLE'], $header_text, false);

	$search_form->assign('header',     $header);
	$search_form->assign('MOD',        $mod_strings);
	$search_form->assign('APP',        $app_strings);
	$search_form->assign("IMAGE_PATH", $image_path);

	$search_form->assign("CALENDAR_DATEFORMAT", $timedate->get_cal_date_format());
	if(isset($current_user_only)){
		$search_form->assign('CURRENT_USER_ONLY', 'checked="checked"');
	}

	if(isset($assigned_user_id)) $search_form->assign("ASSIGNED_USER_ID",$assigned_user_id);
	if(isset($date_from)) $search_form->assign("DATE_FROM",$date_from);
	if(isset($date_to)) $search_form->assign("DATE_TO",$date_to);

	if (!empty($assigned_user_id)) $search_form->assign("USER_FILTER", get_select_options_with_id(get_user_array(FALSE), $assigned_user_id));
	else $search_form->assign("USER_FILTER", get_select_options_with_id(get_user_array(FALSE), ''));

	if(isset($account_name)) $search_form->assign("ACCOUNT_NAME",$account_name);
	if(isset($case_name)) $search_form->assign("CASE_NAME",$case_name);

    $search_form->parse('main');
    $search_form->out('main');
}

$listview   = new ListView();
$listview->initNewXTemplate('modules/JCRMTime/ListView.html', $mod_strings);
$listview->setHeaderTitle($mod_strings['LBL_LIST_FORM_TITLE']);
$listview->mass_update=false;
$listview->setQuery($where, '', 'date', 'JCRMTIME');
$listview->setAdditionalDetails();
$listview->processListView($seed,  'main', 'JCRMTIME');

?>
