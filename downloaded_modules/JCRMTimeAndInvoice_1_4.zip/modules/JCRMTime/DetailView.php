<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMTime/EnterCheck.php');

require_once('XTemplate/xtpl.php');
require_once('data/Tracker.php');
require_once('include/time.php');
require_once('modules/JCRMTime/JCRMTime.php');
require_once('include/DetailView/DetailView.php');

global $app_strings;
global $mod_strings;
global $theme;
global $current_user;

$GLOBALS['log']->info('JCRMTime module detail view');
$focus = new JCRMTime();

$detailView = new DetailView();
$offset='0';

if (isset($_REQUEST['offset']) or isset($_REQUEST['record'])) {
	$result = $detailView->processSugarBean("JCRMTIME", $focus, $offset);
	if($result == null) {
	    sugar_die($app_strings['ERROR_NO_RECORD']);
	}
	$focus=$result;
}else {
	header("Location: index.php?module=JCRMTime&action=index");
}

echo "\n<p>\n";
echo get_module_title($mod_strings['LBL_MODULE_NAME'], $mod_strings['LBL_MODULE_NAME'] . ': ' . $focus->case_name . ' ' . $mod_strings['FOR'] . ' ' .   $focus->account_name . ", " . $focus->date, true);
echo "\n</p>\n";

$theme_path = 'themes/' . $theme . '/';
$image_path = $theme_path . 'images/';

require_once($theme_path.'layout_utils.php');

$xtpl = new XTemplate('modules/JCRMTime/DetailView.html');

$xtpl->assign('MOD', $mod_strings);
$xtpl->assign('APP', $app_strings);
if(isset($_REQUEST['return_module'])){
	$xtpl->assign("RETURN_MODULE", $_REQUEST['return_module']);
}

if(isset($_REQUEST['return_action'])){
	$xtpl->assign("RETURN_ACTION", $_REQUEST['return_action']);
}

if(isset($_REQUEST['return_id'])){
	$xtpl->assign("RETURN_ID", $_REQUEST['return_id']);
}

$xtpl->assign('PRINT_URL',              "index.php?".$GLOBALS['request_string']);
$xtpl->assign('THEME',                  $theme);
$xtpl->assign('GRIDLINE',               $gridline);
$xtpl->assign('IMAGE_PATH',             $image_path);
$xtpl->assign('id',                     $focus->id);
//$xtpl->assign('NAME',                   $focus->name);
$xtpl->assign('assigned_user_name',     $focus->assigned_user_name);
//$xtpl->assign('DESCRIPTION',            nl2br(url2html($focus->description)));
$xtpl->assign('DATE',  $focus->date);
$xtpl->assign('ACCOUNT_NAME',  $focus->account_name);
$xtpl->assign('CASE_NAME',  $focus->case_name);
$xtpl->assign('TIME_START',  $focus->time_start);
$xtpl->assign('TIME_END',  $focus->time_end);

$xtpl->assign('TIME_LENGTH',  $focus->db_to_display_time($focus->time_length));
$xtpl->assign('INVOICE_NUMBER',  $focus->invoice_number);

$xtpl->assign('ENTERED_BY',  $focus->created_by_name);
$xtpl->assign('DATE_ENTERED',  $focus->date_entered);

$xtpl->assign('DATE_MODIFIED',  $focus->date_modified);
$xtpl->assign("MODIFIED_BY", $focus->modified_by_name);

$detailView->processListNavigation($xtpl, "JCRMTIME", $offset);

$xtpl->parse('main.open_source');
$xtpl->parse('main');
$xtpl->out('main');

$sub_xtpl = $xtpl;
$old_contents = ob_get_contents();
ob_end_clean();
ob_start();
echo $old_contents;

?>
