<?php
// show clock menu - include from any menu.php

include('modules/JCRMTime/EnterCheck.php');

global $current_user;
global $mod_strings;

if(ACLController::checkAccess('JCRMTime', 'edit', true)) {
	include_once('modules/JCRMTime/ClockInOut.php');

	global $ClockMenuText;

	$module_menu[] = array('javascript:clockmenu=this.document.activeElement;showclock=true;GetClock()', $ClockMenuText, 'CreateJCRMTime');

	echo '<script type="text/javascript" src="include/javascript/overlibmws.js"></script>
		<script type="text/javascript" src="include/javascript/overlibmws_iframe.js"></script>';

	echo "<script type='text/javascript'>
	var showclock=false;
	var clockmenu;
	function GetClock(){
		if(showclock) {

			showclock=false;

			var clock_div = document.getElementById('clockinoutdiv');
			var showtext=clock_div.innerHTML;
			showtext='<div id=\"clockinoutdivshow\">'+showtext+'</div>';

			overlib(showtext, CAPTION, '<div style=\'float:left\'>Clock In / Out</div><div style=\'float: right\'>', DELAY, 10, STICKY, MOUSEOFF, 1000, WIDTH, 300, CLOSETEXT, '<img border=0  style=\'margin-left:2px; margin-right: 2px;\' src=themes/Sugar/images/close.gif></div>', CLOSETITLE, 'Click to Close', CLOSECLICK, FGCLASS, 'olFgClass', CGCLASS, 'olCgClass', BGCLASS, 'olBgClass', TEXTFONTCLASS, 'olFontClass', CAPTIONFONTCLASS, 'olCapFontClass', CLOSEFONTCLASS, 'olCloseFontClass');

		}
	}
	</script>";
}


?>
