<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMTime/EnterCheck.php');
require_once('modules/JCRMTime/JCRMTime.php');
require_once('log4php/LoggerManager.php');
require_once('include/formbase.php');

$sugarbean = new JCRMTime();
$sugarbean = populateFromPost('', $sugarbean);
$sugarbean->JCRMTime_id = $_POST[return_id];

if(!$sugarbean->ACLAccess('Save')){
	ACLController::displayNoAccess(true);
	sugar_cleanup(true);
}

$sugarbean->save();
$return_id = $sugarbean->id;
handleRedirect($return_id,'JCRMTime');

?>
