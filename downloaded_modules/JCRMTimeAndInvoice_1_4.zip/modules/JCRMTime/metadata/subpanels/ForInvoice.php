<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMTime/EnterCheck.php');

$subpanel_layout = array(
	'top_buttons' => array(
			array('widget_class'=>'SubPanelTopSelectButton', 'popup_module' => 'JCRMTime'),
	),

	'subpanel_name' => 'jcrmtimesummary',
	'where'            => "jcrmtime.invoice_id='".$_REQUEST['record']."'",
	'default_order_by' => 'account_name, case_name, date, assigned_user_name',

	'list_fields' => array(
		'account_name' => array(
					'widget_class' => 'SubPanelDetailViewLink',
 		 			'vname' => 'LBL_LIST_ACCOUNT_NAME',
					 'target_record_key' => 'account_id',
					 'target_module' => 'Accounts',
					 'module' => 'Accounts',
	 		 		'width' => '30%',
				),
		'case_name'         =>array(
		 	'vname'         => 'LBL_LIST_CASE_NAME',
			'widget_class'  => 'SubPanelDetailViewLink',
		 	'width'         => '22%',
			 'target_record_key' => 'case_id',
			 'target_module' => 'Cases',
			),
		'date'         =>array(
		 	'vname'         => 'LBL_LIST_DATE',
			'widget_class'  => 'SubPanelDetailViewLink',
		 	'width'         => '11%',
			),
		'assigned_user_name'         =>array(
		 	'vname'         => 'LBL_LIST_ASSIGNED_USER_ID',
			//'widget_class'  => 'SubPanelDetailView',
		 	'width'         => '15%',
			),
		'time_start'         =>array(
		 	'vname'         => 'LBL_LIST_TIME_START',
			//'widget_class'  => 'SubPanelDetailViewLink',
		 	'width'         => '10%',
			),
		'time_end'         =>array(
		 	'vname'         => 'LBL_LIST_TIME_END',
			//'widget_class'  => 'SubPanelDetailViewLink',
		 	'width'         => '10%',
			),
		'time_length'         =>array(
		 	'vname'         => 'LBL_LIST_TIME_LENGTH',
			//'widget_class'  => 'SubPanelDetailViewLink',
		 	'width'         => '10%',
			),
	),
);


?>
