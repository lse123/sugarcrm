<?php
   if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
   
   global $mod_strings;
   $viewdefs['JCRMTime']['SideQuickCreate'] = array(    
 'templateMeta' => array(
   'form'=>array(
       'headerTpl'=>'include/EditView/header.tpl',
         'footerTpl'=>'include/EditView/footer.tpl',
         'button_location'=>'none',
      ),   
   'maxColumns' => '1',                            
   'panelClass'=>'none',
     'labelsOnTop'=>false,
     'widths' => array(
         array('label' => '10', 'field' => '30'),
     ),
   ),
 'panels' =>array (
       'DEFAULT' => array (  ),
 )
   );
   ?>