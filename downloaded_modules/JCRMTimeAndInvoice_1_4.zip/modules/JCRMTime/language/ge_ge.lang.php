<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMTime/EnterCheck.php');

$mod_strings = array (
	'LBL_MODULE_NAME'                      => 'Arbeitszeit',
	'LBL_MODULE_TITLE'                     => 'Arbeitszeit',
	'LBL_SEARCH_FORM_TITLE'                => 'Zeiten suchen',
	'LBL_LIST_FORM_TITLE'                  => 'Zeiten auflisten',
	'LBL_HISTORY_TITLE'                    => 'Historie',

	'LBL_ID'                               => 'Id:',
	'LBL_DATE_ENTERED'                     => 'Erfassungsdatum:',
	'LBL_DATE_MODIFIED'                    => 'Bearbeitungsdatum:',
	'LBL_ASSIGNED_USER_NAME'               => 'Mitarbeiter:',
	'LBL_ASSIGNED_USER_ID'                 => 'Mitarbeiter ID:',
	'LBL_MODIFIED_USER_NAME'               => 'Zuletzt bearbeitet von:',
	'LBL_CREATED_BY'                       => 'Erstellt von:',
	'LBL_TEAM_ID'                          => 'Team:',
	'LBL_ACCOUNT_NAME'                     => 'Kunde:',
	'LBL_CASE_NAME'                        => 'Fall:',
	'LBL_DATE'                             => 'Datum:',
	'LBL_TIME_START'                       => 'Startzeit:',
	'LBL_TIME_END'                         => 'Endzeit:',
	'LBL_TIME_LENGTH'                      => 'Dauer:',
	'LBL_INVOICE_NUMBER'                   => 'Rechnungsnummer:',
	'LBL_DELETED'                          => 'Gel&ouml;scht:',

	'LBL_LIST_NAME'                        => 'Name',
	'LBL_LIST_ASSIGNED_USER_ID'            => 'Benutzer',

	'LBL_SIMPLE_SUBPANEL_TITLE'            => 'Zeiterfassung',
	'LBL_SIMPLE_TASK_SUBPANEL_TITLE'       => 'Submodul Zeiterfassung',
	'LBL_CONTACT_SUBPANEL_TITLE'           => 'Kontakte',
	'LBL_ACCOUNT_SUBPANEL_TITLE'           => 'Firmen',
	'LBL_OPPORTUNITY_SUBPANEL_TITLE'       => 'Verkaufschancen',

	'LNK_TIMESHEET'						   => 'Zeiterfassung',
	'LBL_DEFAULT_SUBPANEL_TITLE'           => 'JCRMTime',
	'LBL_ACTIVITIES_TITLE'                 => 'Aktivit&auml;ten',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'        => 'Aktivit&auml;ten',
	'LBL_HISTORY_SUBPANEL_TITLE'           => 'Historie',
	'LBL_QUICK_NEW_SIMPLE'                 => 'Neues JCRMTime',

	'LBL_SIMPLE_TASKS_SUBPANEL_TITLE'      => 'JCRMTime SubModule',
	'LBL_CONTACTS_SUBPANEL_TITLE'          => 'Kontakte',
	'LBL_ACCOUNTS_SUBPANEL_TITLE'          => 'Firmen',
	'LBL_OPPORTUNITIES_SUBPANEL_TITLE'     => 'Verkaufschancen',
	'LBL_JCRMTIME_SUBPANEL_TITLE'          => 'Zeiterfassung',
	'LBL_LIST_NAME'                        => 'Name',

	'LNK_LIST_JCRMTIME'                    => 'Liste Zeiten',
	'LBL_LIST_CASE_NAME'                   => 'Fall Bezeichnung',
	'LBL_LIST_ACCOUNT_NAME'                => 'Firma',
	'LBL_LIST_DATE'                		   => 'Datum',
	'LBL_LIST_TIME_START'             	   => 'Startzeit',
	'LBL_LIST_TIME_END'	           		   => 'Endzeit',
	'LBL_LIST_TIME_LENGTH'	           	   => 'Dauer',
	'LBL_LIST_INVOICE_NUMBER'			   => 'Rechnungsnr.',

	'LBL_LIST_CASE' 					   => 'Firma/Fall',
	'LBL_LIST_MON' 						   => 'Mo',
	'LBL_LIST_TUE' 						   => 'Di',
	'LBL_LIST_WED' 						   => 'Mi',
	'LBL_LIST_THU' 						   => 'Do',
	'LBL_LIST_FRI' 						   => 'Fr',
	'LBL_LIST_SAT' 						   => 'Sa',
	'LBL_LIST_SUN' 						   => 'So',
	'LBL_LIST_TOTAL' 					   => 'Total',
	'LBL_WEEK_DATE' 					   => 'Woche ausw&auml;hlen:',


	'LBL_JCRMTIME_SUBPANEL_TITLE'  		=>  'JCRMTime',
	'LBL_DATE' =>  'Date',
	'LBL_DATE_FROM' =>  'Datum von:',
	'LBL_DATE_TO' =>  'Datum bis:',

	'IN_TITLE'  =>  'Zeitstempel Ein',
	'OUT_TITLE'  =>  'Zeitstempel Aus',

	'IN_OUT_TITLE'  =>  'Zeiten erfassen',
	'IN_OUT_SELECT_CURRENT'  =>  'Zeiterfassung f&uuml;r diesen Fall starten: ',
	'IN_OUT_STOP_SELECT_CURRENT'  =>  'Zeiterfassung f&uuml;r diesen Fall stoppen und starten: ',
	'IN_OUT_NOT_CLOCKED_IN' => 'Zeiterfassung l&auml;uft nicht.',
	'IN_OUT_NEW' => '<p>Willkommen beim JustCRMs Zeiterfassungs - Modul f&uuml;r Sugar CRM. Um die Zeiterfassung zu starten m&uuml;ssen Sie zuerste einen Fall ausw&auml;hlen und k&ouml;nnen danach hier klicken.</p><p>Wenn sie einmal begonnen haben, Zeiten f&uuml;r einen Fall zu erfassen, k&ouml;nnen Sie fortan sehr einfach die Zeiterfassung f&uuml;r diesen Fall wieder starten.</p><p>Alternativ k&ouml;nnen Sie die Zeiten auch nachtr&auml;glich erfassen oder editieren.</p>',
	'IN_OUT_CURRENTLY' => 'Fall wird aktuell bearbeitet ',
	'IN_OUT_FOR' => ' w&auml;hrend ',
	'IN_OUT_SINCE' => ' seit ',
	'IN_OUT_SELECT_RECENT' => 'Starten: ',
	'IN_OUT_STOP_SELECT_RECENT' => 'Stoppen und starten: ',
	'IN_OUT_STOP' => 'Jetzt stoppen',
	'IN_OUT_CANCEL' => 'Abbrechen',

	'IN_OUT_OR' => ' oder stoppen um ',

	'IN_OUT_TIMESHEET1' => ' oder klicken&nbsp;',
	'IN_OUT_TIMESHEET2' => ' um Zeiten f&uuml;r diese Woche zu erfassen. ',

	'IN_OUT_YOU_CLOCKED_INTO' => 'Die Zeit l&auml;uft f&uuml;r ',
	'IN_OUT_AT' => ' um ',
	'IN_OUT_YOU_MUST' => '. Sie m&uuml;ssen die Zeiterfassung f&uuml;r diesen Fall erst stoppen, damit Sie sie f&uuml;r einen anderen Fall starten k&ouml;nnen.<br>Ausstempeln um: ',

	'TS_SELECT_WEEK' => 'Woche:',
	'TS_SELECT_USER' => 'Mitareiter:',
	'TS_ADD_CASE' => 'F&auml;lle zu Zeitabrechnung hinzuf&uuml;gen:',
	'TS_SEARCH_FORM_TITLE' => 'Zeitabrechnung ausw&auml;hlen',
	'TS_UPDATE_CASE_TITLE' => 'Zeitabrechnung f&uuml;r ausgew&auml;hlte F&auml;lle',
	'TS_TITLE' => 'Zeiten: Zeitabrechnung',
	'TS_ONE_CASE_NAME'                  => 'Ein Fall:',
	'TS_ONE_CASE_NAME_SELECT'           => 'Anzeigen des ausgew&auml;hlten Falls anstatt aller offenen F&auml;lle f&uuml;r den ausgew&auml;hlten Mitarbeiter.',

	'LNK_TIME_SUMMARY' => '&Uuml;bersicht der Zeiten',

	'JAVA_TIME_INVALID' => ' keine g&uuml;ltige Zeitangabe. Bitte geben Sie die Zeit im Format HH:MM an oder mit Dezimalen (1.5), worauf diese umgerechnet wird.',

	'SAVED' => 'Zeitabrechnung gesichert',

	'TS_UPDATE_UPDATE' => 'Aktualisieren',
	'TS_UPDATE_WEEK' => 'Woche',
	'TS_UPDATE_TITLE' => 'Zeitabrechung f&uuml;r ausgew&auml;hlten Mitarbeiter',

	'NO_ACCESS' => 'Sie haben keine Berechtigung diese Zeitabrechnung einzusehen.',
	'IN_OUT_CANCEL_CONFIRM' => 'Wollen Sie diese Zeiterfassung wirklich abbrechen?',
	'IN_OUT_INVALID_END' => 'Bitte geben Sie eine g&uuml;ltige Endzeit im Format HH:MM ein .',
	'IN_OUT_INVALID_HOUR' => 'Ung&uuml;ltige Stundenangabe, bitte geben Sie eine g&uuml;ltige Endzeit ein.',
	'IN_OUT_INVALID_MINUTE' => 'Ung&uuml;ltige Minutenangabe, bitte geben Sie eine g&uuml;ltige Endzeit ein.',
	'IN_OUT_INVALID_AFTER' => 'Die Endzeit muss sp&auml;ter als die Startzeit sein',

	'IN_OUT_INVALID_START' => 'Bitte geben Sie die Zeit im Format HH:MM an.',
	'IN_OUT_INVALID_HOUR_START' => 'Ung&uuml;ltige Stundenangabe, bitte geben Sie eine g&uuml;ltige Startzeit ein.',
	'IN_OUT_INVALID_MINUTE_START' => 'Ung&uuml;ltige Minutenangabe, bitte geben Sie eine g&uuml;ltige Startzeit ein.',

	'FOR' => 'f&uuml;r',
	'NO_TIME' => 'Keine Zeit erfasst f&uuml;r dieses Kriterium - ',

	'TIME_SUMMARY_TITLE' => 'Zeiten: Zusammenfassung',
);
?>
