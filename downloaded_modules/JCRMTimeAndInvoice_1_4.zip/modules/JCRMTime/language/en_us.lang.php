<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMTime/EnterCheck.php');

$mod_strings = array (
	'LBL_MODULE_NAME'                      => 'Time',
	'LBL_MODULE_TITLE'                     => 'Time',
	'LBL_SEARCH_FORM_TITLE'                => 'Time Search',
	'LBL_LIST_FORM_TITLE'                  => 'Time List',
	'LBL_HISTORY_TITLE'                    => 'History',

	'LBL_ID'                               => 'Id:',
	'LBL_DATE_ENTERED'                     => 'Date Entered:',
	'LBL_DATE_MODIFIED'                    => 'Date Modified:',
	'LBL_ASSIGNED_USER_NAME'                 => 'Assigned To:',
	'LBL_ASSIGNED_USER_ID'                 => 'Assigned To:',
	'LBL_MODIFIED_USER_NAME'                 => 'Modified By:',
	'LBL_CREATED_BY'                       => 'Created By:',
	'LBL_TEAM_ID'                          => 'Team:',
	'LBL_ACCOUNT_NAME'                     => 'Account:',
	'LBL_CASE_NAME'                        => 'Case:',
	'LBL_DATE'                             => 'Date:',
	'LBL_TIME_START'                       => 'Start:',
	'LBL_TIME_END'                         => 'End:',
	'LBL_TIME_LENGTH'                      => 'Duration:',
	'LBL_INVOICE_NUMBER'                   => 'Invoice Number:',
	'LBL_DELETED'                          => 'Deleted:',

	'LBL_LIST_NAME'                        => 'Name',
	'LBL_LIST_ASSIGNED_USER_ID'            => 'Assigned To',

	'LBL_SIMPLE_SUBPANEL_TITLE'            => 'Time',
	'LBL_SIMPLE_TASK_SUBPANEL_TITLE'       => 'Time subModule',
	'LBL_CONTACT_SUBPANEL_TITLE'           => 'Contacts',
	'LBL_ACCOUNT_SUBPANEL_TITLE'           => 'Accounts',
	'LBL_OPPORTUNITY_SUBPANEL_TITLE'       => 'Opportunities',

	'LNK_TIMESHEET'						=> 'Timesheets',
	'LBL_DEFAULT_SUBPANEL_TITLE'           => 'JCRMTime',
	'LBL_ACTIVITIES_TITLE'                 => 'Activities',
	'LBL_ACTIVITIES_SUBPANEL_TITLE'        => 'Activities',
	'LBL_HISTORY_SUBPANEL_TITLE'           => 'History',
	'LBL_QUICK_NEW_SIMPLE'                 => 'New JCRMTime',

	'LBL_SIMPLE_TASKS_SUBPANEL_TITLE'      => 'JCRMTime SubModule',
	'LBL_CONTACTS_SUBPANEL_TITLE'          => 'Contacts',
	'LBL_ACCOUNTS_SUBPANEL_TITLE'          => 'Accounts',
	'LBL_OPPORTUNITIES_SUBPANEL_TITLE'     => 'Opportunities',
	'LBL_JCRMTIME_SUBPANEL_TITLE'         => 'Time',
	'LBL_LIST_NAME'                        => 'Name',

	'LNK_LIST_JCRMTIME'                   => 'Time List',
	'LBL_LIST_CASE_NAME'                   => 'Case Name',
	'LBL_LIST_ACCOUNT_NAME'                => 'Account Name',
	'LBL_LIST_DATE'                		=> 'Date',
	'LBL_LIST_TIME_START'             		=> 'Start',
	'LBL_LIST_TIME_END'	           		=> 'End',
	'LBL_LIST_TIME_LENGTH'	           		=> 'Duration',
	'LBL_LIST_INVOICE_NUMBER'				=> 'Invoice No.',

	'LBL_LIST_CASE' 						=> 'Account/Case',
	'LBL_LIST_MON' 						=> 'Mon',
	'LBL_LIST_TUE' 						=> 'Tue',
	'LBL_LIST_WED' 						=> 'Wed',
	'LBL_LIST_THU' 						=> 'Thu',
	'LBL_LIST_FRI' 						=> 'Fri',
	'LBL_LIST_SAT' 						=> 'Sat',
	'LBL_LIST_SUN' 						=> 'Sun',
	'LBL_LIST_TOTAL' 						=> 'Total',
	'LBL_WEEK_DATE' 						=> 'Select Week:',


	'LBL_JCRMTIME_SUBPANEL_TITLE'  		=>  'JCRMTime',
	'LBL_DATE' =>  'Date',
	'LBL_DATE_FROM' =>  'Date From:',
	'LBL_DATE_TO' =>  'Date To:',

	'IN_TITLE'  =>  'Clock In',
	'OUT_TITLE'  =>  'Clock Out',

	'IN_OUT_TITLE'  =>  'Clock In / Out',
	'IN_OUT_SELECT_CURRENT'  =>  'Start this case: ',
	'IN_OUT_STOP_SELECT_CURRENT'  =>  'Stop and start this case: ',
	'IN_OUT_NOT_CLOCKED_IN' => 'Not currently clocked in.',
	'IN_OUT_NEW' => '<p>Welcome to the JustCRMs time module. To clock in (commence working) on a case first select a case detailview or editview and then click here.</p><p>Once you have started entering time a list of recently worked on cases will appear here so you can quickly clock into one.</p><p>Alternately you may enter time directly into your timesheet by clicking on the Time tab and selecting the timesheet shortcut. Enjoy!</p>',
	'IN_OUT_CURRENTLY' => 'Currently working on ',
	'IN_OUT_FOR' => ' for ',
	'IN_OUT_SINCE' => ' since ',
	'IN_OUT_SELECT_RECENT' => 'Start: ',
	'IN_OUT_STOP_SELECT_RECENT' => 'Stop and start: ',
	'IN_OUT_STOP' => 'stop now',
	'IN_OUT_CANCEL' => 'cancel',

	'IN_OUT_OR' => ' or stop at ',

	'IN_OUT_TIMESHEET1' => ' or click&nbsp;',
	'IN_OUT_TIMESHEET2' => ' to enter time for this week. ',

	'IN_OUT_YOU_CLOCKED_INTO' => 'You clocked into ',
	'IN_OUT_AT' => ' at ',
	'IN_OUT_YOU_MUST' => '. You must clock out from this before clocking into any more cases.<br>Clock out at: ',

	'TS_SELECT_WEEK' => 'Week:',
	'TS_SELECT_USER' => 'User:',
	'TS_ADD_CASE' => 'Add Case(s) to Timesheet:',
	'TS_SEARCH_FORM_TITLE' => 'Select Timesheet',
	'TS_UPDATE_CASE_TITLE' => 'Timesheet for Selected Case',
	'TS_TITLE' => 'Time: Timesheets',
	'TS_ONE_CASE_NAME'                  => 'One Case:',
	'TS_ONE_CASE_NAME_SELECT'           => 'Show selected Case instead of all open or recently worked on Cases for selected User.',

	'LNK_TIME_SUMMARY' => 'Time Summary',

	'JAVA_TIME_INVALID' => ' is not a valid time. Please enter time in the format HH:MM or enter a decimal and have it converted.',

	'SAVED' => 'Timesheet Saved',

	'TS_UPDATE_UPDATE' => 'Update',
	'TS_UPDATE_WEEK' => 'Week',
	'TS_UPDATE_TITLE' => 'Timesheet for Selected User',

	'NO_ACCESS' => 'You do not have access to view this Timesheet.',
	'IN_OUT_CANCEL_CONFIRM' => 'Are you sure you want to cancel this clock in?',
	'IN_OUT_INVALID_END' => 'Please enter a valid end time in the format HH:MM.',
	'IN_OUT_INVALID_HOUR' => 'Invalid hour, please enter a valid end time.',
	'IN_OUT_INVALID_MINUTE' => 'Invalid minute, please enter a valid end time.',
	'IN_OUT_INVALID_AFTER' => 'The end time must be after',

	'IN_OUT_INVALID_START' => 'Please enter a valid start time in the format HH:MM.',
	'IN_OUT_INVALID_HOUR_START' => 'Invalid hour, please enter a valid start time.',
	'IN_OUT_INVALID_MINUTE_START' => 'Invalid minute, please enter a valid start time.',

	'FOR' => 'for',
	'NO_TIME' => 'No time entered for this criteria - ',

	'TIME_SUMMARY_TITLE' => 'Time: Summary',
);
?>
