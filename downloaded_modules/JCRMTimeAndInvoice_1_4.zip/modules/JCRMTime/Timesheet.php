<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMTime/EnterCheck.php');
require_once ('include/JSON.php');
require_once('modules/JCRMTime/JCRMTime.php');
require_once ('include/TimeDate.php');
require_once('XTemplate/xtpl.php');

$timedate = new TimeDate();
global $current_language;
global $current_user;
global $mod_strings;
global $app_strings;
global $image_path;

$json = new JSON(JSON_LOOSE_TYPE);

global $theme;
$theme_path = 'themes/' . $theme . '/';
$image_path = $theme_path .'images/';
require_once($theme_path . 'layout_utils.php');

echo "\n<p>\n";
echo get_module_title('', "<IMG src='themes/Default/images/CreateJCRMTime.gif' width='16' height='16' border='0' style='margin-top: 3px;'>&nbsp;".$mod_strings['TS_TITLE'], false);
echo "\n</p>\n";

require_once('modules/MySettings/StoreQuery.php');
$storeQuery = new StoreQuery();
if(!isset($_REQUEST['query'])){
    $storeQuery->loadQuery('JCRMTIME_TIMESHEET');
    $storeQuery->populateRequest();
}else{
    $storeQuery->saveFromGet('JCRMTIME_TIMESHEET');
}

if(isset($_REQUEST['one_case_id']) && $_REQUEST['one_case_id'] !='')
	$one_case_id=$_REQUEST['one_case_id'];
else
	$one_case_id='';

if(isset($_REQUEST['one_case_name']) && $_REQUEST['one_case_name'] !='')
	$one_case_name=$_REQUEST['one_case_name'];
else
	$one_case_name='';

$JCRMTime = new JCRMTime();

//date is always in the users local time, not gmt
//date and time in jcrmtime table is always in local time / date too
if(isset($_REQUEST['date']) && $_REQUEST['date'] !='')
	$date=$_REQUEST['date'];
else
	$date = $JCRMTime->local_date();

//bring back the start date to the previous monday
//date is in local time and format and must not be converted
//strtotime returns the gmt date / time
//so convert to gmt using db format first then convert back
//wday of zero is sunday, 1 is monday
$date =$JCRMTime->format_user_date_for_db($date);
$startday=getdate(strtotime($date));
if($startday['wday']==0) {
	$startday = getdate(strtotime("-6 days", strtotime($date)));
} elseif($startday['wday']!=1) {
	$startday = getdate(strtotime((1-$startday['wday']) ." days", strtotime($date)));
}

$endday=getdate(strtotime($date));
if($endday['wday']!=0) {
	$endday = getdate(strtotime((7-$endday['wday']) ." days", strtotime($date)));
}

$date = $JCRMTime->format_db_date_for_user("{$startday['year']}-{$startday['mon']}-{$startday['mday']}");
$date_end = $JCRMTime->format_db_date_for_user("{$endday['year']}-{$endday['mon']}-{$endday['mday']}");

//echo " date is now ".$date." date end is ".$date_end;

if(isset($_REQUEST['assigned_user_id']) && $_REQUEST['assigned_user_id']!='')
	$assigned_user_id=$_REQUEST['assigned_user_id'];
else
	$assigned_user_id=$current_user->id;

if(isset($_REQUEST['assigned_user_name']) && $_REQUEST['assigned_user_name'] !='')
	$assigned_user_name=$_REQUEST['assigned_user_name'];
else
	$assigned_user_name=$current_user->user_name;

//show search form
$search_form = new XTemplate('modules/JCRMTime/TimesheetSelect.html');
$header = get_form_header($mod_strings['TS_SEARCH_FORM_TITLE'], '', false);

$search_form->assign('header',     $header);
$search_form->assign('MOD',        $mod_strings);
$search_form->assign('APP',        $app_strings);
$search_form->assign("IMAGE_PATH", $image_path);
$search_form->assign("JAVASCRIPT", get_clear_form_js());

$search_form->assign("CALENDAR_DATEFORMAT", $timedate->get_cal_date_format());

if(isset($assigned_user_id)) $search_form->assign("ASSIGNED_USER_ID",$assigned_user_id);
if(isset($assigned_user_name)) $search_form->assign("ASSIGNED_USER_NAME",$assigned_user_name);
if(isset($date)) $search_form->assign("DATE",$date);
$search_form->assign("ASSIGNED_USER_OPTIONS", get_select_options_with_id(get_user_array(TRUE, "Active", $assigned_user_id), $assigned_user_id));

$popup_request_data = array(
        'call_back_function' => 'set_return',
        'form_name' => 'timesheet_select',
        'field_to_name_array' => array(
                'id' => 'assigned_user_id',
                'user_name' => 'assigned_user_name',
                ),
        );
$search_form->assign('encoded_users_popup_request_data', $json->encode($popup_request_data));

$search_form->assign('ONE_CASE_ID',     $one_case_id);
$search_form->assign('ONE_CASE_NAME',     $one_case_name);

$popup_request_data = array(
	'call_back_function' => 'set_return',
	'form_name' => 'timesheet_select',
	'field_to_name_array' => array(
		'id' => 'one_case_id',
		'name' => 'one_case_name',
		),
	);
$encoded_popup_request_data = $json->encode($popup_request_data);
$search_form->assign("encoded_one_case_popup_request_data",$encoded_popup_request_data);
$search_form->parse('main');

$search_form->out('main');

//show timesheet
$week= date("W", strtotime($date));
//if W is shown in week then we are not php version 4.1.0 or later
if(stristr($week, "W") > 1) {
	$week= $mod_strings['TS_UPDATE_UPDATE'];
}
else {
	$week= $mod_strings['TS_UPDATE_UPDATE'] . ' ' . $mod_strings['TS_UPDATE_WEEK'] . ' ' . $week;
}

if($one_case_id=='')
	echo get_form_header($week . ' ' . $mod_strings['TS_UPDATE_TITLE'], '', false);
else
	echo get_form_header($week . ' ' . $mod_strings['TS_UPDATE_CASE_TITLE'], '', false);


if(isset($_REQUEST['saved']) && $_REQUEST['saved'] =='true')
echo $mod_strings['SAVED'].'<br>';


$seed = new JCRMTime();

global $theme;
$theme_path = "themes/".$theme."/";
$image_path = $theme_path."images/";
require_once ($theme_path.'layout_utils.php');

$xtpl=new XTemplate ('modules/JCRMTime/Timesheet.html');
$xtpl->assign('MOD',  $mod_strings);
$xtpl->assign('APP',  $app_strings);
$xtpl->assign("CALENDAR_LANG", "en");
$xtpl->assign("USER_DATEFORMAT", '('.$timedate->get_user_date_format().')');
$xtpl->assign("CALENDAR_DATEFORMAT", $timedate->get_cal_date_format());

$xtpl->assign("THEME", $theme);
$xtpl->assign("IMAGE_PATH", $image_path);
$xtpl->assign("PRINT_URL", "index.php?".$GLOBALS['request_string']);

if($seed->ACLAccess('EditView', $assigned_user_id == $current_user->id)) {

	$save_button='<p>
		<input tabindex="2" title="'.$app_strings['LBL_SAVE_BUTTON_TITLE'].'" accessKey="'.$app_strings['LBL_SAVE_BUTTON_KEY'].'" class="button"
		type="submit" name="button" value="'.$app_strings['LBL_SAVE_BUTTON_LABEL'].'" onclick="this.form.action.value=\'TimesheetSave\';return check_form(\'Timesheet\');"/>
		</p>';
	$xtpl->assign("SAVE_BUTTON", $save_button);

	$popup_request_data = array(
		'call_back_function' => 'set_return_timesheet',
		'form_name' => 'Timesheet',
		'field_to_name_array' => array(
			'id' => 'case_id',
			'name' => 'name',
			'account_name' => 'account_name',
			'account_id' => 'account_id',
			),
		);

	$encoded_popup_request_data = $json->encode($popup_request_data);
	$add_case='<p>'.$mod_strings['TS_ADD_CASE'].'&nbsp;
		<input name="case_id" id="case_id" type="hidden" value="" />
		<input tabindex="2" title="' . $app_strings['LBL_SELECT_BUTTON_TITLE'] . '" accessKey="' . $app_strings['LBL_SELECT_BUTTON_KEY'] . '" type="button" class="button" value="' . $app_strings['LBL_SELECT_BUTTON_LABEL'] . '" name="btn1"
			onclick=\'win=open_popup("Cases", 600, 400, "", false, true, ' . $encoded_popup_request_data . ', "notmultiselect");\' />
		</p>';
	$xtpl->assign('ADD_CASE', $add_case);

}

$xtpl->assign("ASSIGNED_USER_ID",$assigned_user_id);
$xtpl->assign("DATE",$date);

$datenum = strtotime($seed->format_user_date_for_db($date));
$xtpl->assign('LBL_MON_DATE', $seed->format_db_date_for_user(date('Y-m-d', $datenum)));
$xtpl->assign('LBL_TUE_DATE', $seed->format_db_date_for_user(date('Y-m-d', $datenum+(1*86400))));
$xtpl->assign('LBL_WED_DATE', $seed->format_db_date_for_user(date('Y-m-d', $datenum+(2*86400))));
$xtpl->assign('LBL_THU_DATE', $seed->format_db_date_for_user(date('Y-m-d', $datenum+(3*86400))));
$xtpl->assign('LBL_FRI_DATE', $seed->format_db_date_for_user(date('Y-m-d', $datenum+(4*86400))));
$xtpl->assign('LBL_SAT_DATE', $seed->format_db_date_for_user(date('Y-m-d', $datenum+(5*86400))));
$xtpl->assign('LBL_SUN_DATE', $seed->format_db_date_for_user(date('Y-m-d', $datenum+(6*86400))));

$count=0;

// check user has access - can they view other peoples time?
if($seed->ACLAccess('DetailView', $assigned_user_id == $current_user->id)) {
	//has access
	$data=$seed->create_timesheet_list('5, 2', $assigned_user_id, $date, $date_end, 0, $one_case_id);


	global $odd_bg;
	global $even_bg;
	global $hilite_bg;
	$xtpl->assign('BG_HILITE', $hilite_bg);

	$oddRow=true;

	foreach($data as $line){
		$line['NUM']=$count;

		if($oddRow)
		{
			$ROW_COLOR = 'oddListRow';
			$BG_COLOR =  $odd_bg;
		}
		else
		{
			$ROW_COLOR = 'evenListRow';
			$BG_COLOR =  $even_bg;
		}
		$oddRow = !$oddRow;
		$xtpl->assign('ROW_COLOR', $ROW_COLOR);
		$xtpl->assign('BG_COLOR', $BG_COLOR);

		$xtpl->assign('TIMESHEET', $line);
		$xtpl->parse("main.row");

		$count++;
	}

	if($oddRow)
	{
		$xtpl->assign('BOTTOM_BG_COLOR', $odd_bg);
	}
	else
	{
		$xtpl->assign('BOTTOM_BG_COLOR', $even_bg);
	}

	$xtpl->assign('ODD_BG', $odd_bg);
	$xtpl->assign('EVEN_BG', $even_bg);

}

$xtpl->assign('ROWCOUNT', $count);

if (isset($sugar_config)) {
	if ($sugar_config['sugar_version'] >= '4.5.0') {
		require_once('include/QuickSearchDefaults.php');
		$qsd = new QuickSearchDefaults();
		echo $qsd->GetQSScripts();
		$qsUser = $qsd->getQSUser();
	}else{
		include('include/QuickSearchDefaults.php');
		echo $qsScripts;
	}
}

$qsCase = array(
					'method' => 'query',
					'modules' => array('Cases'),
					'group' => 'or',
					'field_list' => array('name', 'id', 'account_name', 'account_id'),
					'populate_list' => array('name', 'id', 'account_name', 'account_id'),
					'conditions' => array(array('name'=>'name','op'=>'like_custom','end'=>'%','value'=>'')),
					'order' => 'name',
					'limit' => '30',
					'no_match_text' => $app_strings['ERR_SQS_NO_MATCH']
					);

$qs1Case = array(
					'method' => 'query',
					'modules' => array('Cases'),
					'group' => 'or',
					'field_list' => array('name', 'id'),
					'populate_list' => array('one_case_name', 'one_case_id'),
					'conditions' => array(array('name'=>'name','op'=>'like_custom','end'=>'%','value'=>'')),
					'order' => 'name',
					'limit' => '30',
					'no_match_text' => $app_strings['ERR_SQS_NO_MATCH']
					);

$sqs_objects = array('one_case_name' => $qs1Case, 'case_name' => $qsCase, 'assigned_user_name' => $qsUser);
$quicksearch_js = '<script type="text/javascript" language="javascript">sqs_objects = ' . $json->encode($sqs_objects) . '</script>';
$xtpl->assign("JAVASCRIPT", $quicksearch_js);



// check user has access - can they view other peoples time?
if($seed->ACLAccess('DetailView', $assigned_user_id == $current_user->id)) {
	$xtpl->parse("main");
	$xtpl->out("main");
}
else {
	$xtpl->parse("noaccess");
	$xtpl->out("noaccess");
}

?>
