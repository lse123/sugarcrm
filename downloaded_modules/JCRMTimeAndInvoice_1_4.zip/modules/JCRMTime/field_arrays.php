<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMTime/EnterCheck.php');

$fields_array['JCRMTime'] = array (
'column_fields' => array(
  'id',
  'date_entered',
  'date_modified',
  'assigned_user_id',
  'modified_user_id',
  'created_by',
  'name',
  'description',
  'deleted',
  'date',
 ),
 'list_fields' =>  array(
  'id',
  'assigned_user_id',
  'assigned_user_name',
  'name',
  'relation_id',
  'relation_name',
  'relation_type',
  'account_name',
  'date',
 ),
 'required_fields' =>  array('date'=>1, ),
);
?>
