<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMTime/EnterCheck.php');
require_once('modules/JCRMTime/JCRMTime.php');
require_once('include/TimeDate.php');

/*
save_assigned_user_id => person saving
date "19/03/2007"
assigned_user_id => timesheet of person being saved
TimeCaseID=> array(4) case ids
BeforeMON-SUN=> array(4) values before
TimeMON-SUN=> array(4) values to save if changed form before
["case_id"]=> string(0) ""
["button"]=> string(4) "Save"
*/

//loop through array and save values
$dt=new TimeDate();
$date = $dt->swap_formats($_REQUEST['date'], $dt->get_date_format(), $dt->dbDayFormat);

$i=0;
$days=array('MON','TUE','WED','THU','FRI','SAT','SUN');
$result='';
while(isset($_REQUEST['TimeCaseID'][$i])) {
	foreach($days as $dayno=>$day) {
		if(isset($_REQUEST['Time'.$day][$i]) && isset($_REQUEST['Before'.$day][$i]) && $_REQUEST['Time'.$day][$i] !=$_REQUEST['Before'.$day][$i]) {
//			echo "Save $day Case ".$_REQUEST['TimeCaseID'][$i]." replace old value ". $_REQUEST['Before'.$day][$i] ." with new value ". $_REQUEST['Time'.$day][$i] ." start date " . $start_date." <br>";

			//what day is this
			$dbdate = strtotime($date);
			$dbdate = $dbdate+(86400*$dayno);
			$dbdate=date($dt->dbDayFormat, $dbdate);
//			echo "date is $dbdate <br>";

			//new time
			$new_time=$_REQUEST['Time'.$day][$i];
			if($new_time=='') $new_time='0:00';
//			echo "new_time is $new_time <br>";

			//timesheet entries are through a balancing record with no time start/end
			$cell = new JCRMTime();
			$result .= $cell->set_timesheet_cell($dbdate, $_REQUEST['TimeAccountID'][$i], $_REQUEST['TimeCaseID'][$i], $_REQUEST['assigned_user_id'], $new_time);

		}
    }
	$i++;
}

if($result!='') {
	echo $result;
}
else {
	//redirect to re-show the timesheet
	header("Location: index.php?action=Timesheet&module=JCRMTime&saved=true");
	exit;
}
?>
