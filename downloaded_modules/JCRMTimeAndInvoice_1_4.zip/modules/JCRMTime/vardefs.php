<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMTime/EnterCheck.php');

$dictionary['JCRMTime']=array(
	'table' =>'jcrmtime',
	'audited'=>false,
	'fields'=>array(
		'id'  =>array(
			'name'  =>'id',
			'vname'  =>'LBL_ID',
			'required' =>true,
			'type'  =>'id',
			'reportable' =>false,
		),
		'date_entered' =>array(
			'name'  =>'date_entered',
			'vname'  =>'LBL_DATE_ENTERED',
			'type'  =>'datetime',
			'required' =>true,
		),
		'date_modified' =>array(
			'name'  =>'date_modified',
			'vname'  =>'LBL_DATE_MODIFIED',
			'type'  =>'datetime',
			'required' =>true,
		),
		'assigned_user_id'=>array(
			'name'  =>'assigned_user_id',
			'rname'  =>'user_name',
			'id_name'  =>'assigned_user_id',
			'type'  =>'assigned_user_name',
			'vname'  =>'LBL_ASSIGNED_USER_ID',
			'required' =>false,
			'len'   =>36,
			'dbType'  =>'id',
			'table'  =>'users',
			'isnull'  =>false,
			'reportable' =>true,
			'massupdate'=>false,
		),
		'modified_user_id'=>array(
			'name'  =>'modified_user_id',
			'rname'  =>'user_name',
			'id_name'  =>'modified_user_id',
			'vname'  =>'LBL_MODIFIED_USER_ID',
			'type'  =>'assigned_user_name',
			'table'  =>'users',
			'isnull'  =>'false',
			'dbType'  =>'id',
			'reportable' =>true,
			'massupdate'=>false,
		),
		'created_by' =>array(
			'name'  =>'created_by',
			'rname'  =>'user_name',
			'id_name'  =>'modified_user_id',
			'vname'  =>'LBL_CREATED_BY',
			'type'  =>'assigned_user_name',
			'table'  =>'users',
			'isnull'  =>'false',
			'dbType'  =>'id',
		),
		'deleted'  =>array(
			'name'  =>'deleted',
			'vname'  =>'LBL_DELETED',
			'type'  =>'bool',
			'required' =>true,
			'default'  =>'0',
		),
		'created_by_link' =>array(
			'name'  =>'created_by_link',
			'type'  =>'link',
			'relationship' =>'JCRMTime_created_by',
			'vname'  =>'LBL_CREATED_BY_USER',
			'link_type'  =>'one',
			'module'  =>'Users',
			'bean_name'  =>'User',
			'source'  =>'non-db',
		),
		'modified_user_link'=>array(
			'name'  =>'modified_user_link',
			'type'  =>'link',
			'relationship' =>'JCRMTime_modified_user',
			'vname'  =>'LBL_MODIFIED_BY_USER',
			'link_type'  =>'one',
			'module'  =>'Users',
			'bean_name'  =>'User',
			'source'  =>'non-db',
		),
		'assigned_user_link'=>array(
			'name'  =>'assigned_user_link',
			'type'  =>'link',
			'relationship' =>'JCRMTime_assigned_user',
			'vname'  =>'LBL_ASSIGNED_TO_USER',
			'link_type'  =>'one',
			'module'  =>'Users',
			'bean_name'  =>'User',
			'source'  =>'non-db',
		),
		'assigned_user_name'=>array(
			'name'  =>'assigned_user_name',
			'rname'  =>'user_name',
			'id_name'  =>'assigned_user_id',
			'vname'  =>'LBL_ASSIGNED_USER_NAME',
			'type'  =>'relate',
			'table'  =>'users',
			'module'  =>'Users',
			'dbType'  =>'varchar',
			'link'  =>'users',
			'len'   =>'255',
			'source'  =>'non-db',
			'massupdate'=>false,
		),

		'case_id'=>array(
			'name'=>'case_id',
			'type'=>'id',
			'reportable'=>false,
			'vname'=>'LBL_CASE',
			'audited'=>true,
			'massupdate'=>false,
			'required'=>true,
			),

		'case_name'=>array(
			'name'  =>'case_name',
			'type'  =>'relate',
			'rname'  =>'name',
			'link'				=>'case_name_link',
			'table'				=>'cases',
				'module'			=>'Cases',
			'id_name'  =>'case_id',
			'vname'  =>'LBL_CASE_NAME',
			'dbType'  =>'varchar',
			'len'   =>'255',
			'source'  =>'non-db',
			'massupdate'=>false,
		),
		'case_name_link'=>array(
			'name'=>'case_name_link',
			'type'=>'link',
			'relationship'=>'cases_jcrmtime',
			'link_type'=>'one',
			'side'=>'right',
			'source'=>'non-db',
			'vname'=>'',
		),
		'case_owner_id'=>array(
			'name'  =>'case_owner_id',
			'source'  =>'non-db',
			'type'=>'id',
		),
		'account_id'=>array(
			'name'=>'account_id',
			'type'=>'id',
			'reportable'=>false,
			'audited'=>false,
			'massupdate'=>false,
			),
		'account_name'=>array(
			'name'=>'account_name',
			'rname'=>'name',
			'id_name'=>'account_id',
			'vname'=>'LBL_REPORTS_TO',
			'type'=>'relate',
			'link'=>'account_name_link',
			'table'=>'accounts',
			'isnull'=>'true',
			'module'=>'Accounts',
			'dbType'=>'varchar',
			'len'=>'255',
			'reportable'=>false,
			'source'=>'non-db',
			'massupdate'=>false,
		),
		'account_name_link'=>array(
			'name'=>'account_name_link',
			'type'=>'link',
			'relationship'=>'relate_account',
			'link_type'=>'one',
			'side'=>'right',
			'source'=>'non-db',
			'vname'=>'LBL_REPORTS_TO',
		),

		'account_owner_id'=>array(
			'name'  =>'account_owner_id',
			'source'  =>'non-db',
			'type'=>'id',
		),
		'date'=>array(
			'name' =>'date',
			'vname' =>'LBL_DATE',
			'type' =>'date',
			'len' =>255,
			'required'=>true,
			'audited' =>false,
			'massupdate'=>false,
		),
		'time_start'=>array(
			'name' =>'time_start',
			'vname' =>'LBL_TIME_START',
			'type' =>'time',
			'len' =>255,
			'required'=>false,
			'audited' =>false,
			'massupdate'=>false,
		),
		'time_end'=>array(
			'name' =>'time_end',
			'vname' =>'LBL_TIME_END',
			'type' =>'time',
			'len' =>255,
			'required'=>false,
			'audited' =>false,
			'massupdate'=>false,
		),
		//length could be negative so use a custom type negtime
		'time_length'=>array(
			'name' =>'time_length',
			'vname' =>'LBL_TIME_LENGTH',
			'type' =>'negtime',
			'dbType'=>'time',
			'len' =>255,
			'required'=>false,
			'audited' =>false,
			'massupdate'=>false,
		),
		'invoice_id'=>array(
			'name' =>'invoice_id',
			'vname' =>'LBL_INVOICE',
			'type' =>'id',
			'len' =>255,
			'required'=>false,
			'audited' =>false,
			'massupdate'=>false,
		),

		'invoice_number'=>array(
			'name'=>'invoice_number',
			'rname'=>'invoice_number',
			'id_name'=>'invoice_id',
			'type'=>'relate',
			'link'=>'invoice_number_link',
			'table'=>'jcrminvoices',
			'isnull'=>'true',
			'module'=>'JCRMInvoices',
			'dbType'=>'int',
			'reportable'=>false,
			'source'=>'non-db',
			'massupdate'=>false,
		),
		'invoice_number_link'=>array(
			'name'=>'invoice_number_link',
			'type'=>'link',
			'relationship'=>'relate_jcrminvoice',
			'link_type'=>'one',
			'side'=>'right',
			'source'=>'non-db',
		),

		'invoice_owner_id'=>array(
			'name'  =>'invoice_owner_id',
			'source'  =>'non-db',
			'type'=>'id',
		),

  	 // BEGIN SUGARCRM PRO ONLY
  'team_id' =>
  array (
    'name' => 'team_id',
    'vname' => 'LBL_TEAM_ID',
    'reportable'=>false,
    'dbtype' => 'id',
    'type' => 'team_list',
    'audited'=>true,
    'comment' => 'The team ID for the time',
    'massupdate' => false,
  ),
  	 // END SUGARCRM PRO ONLY

	),

	'indices'=>array(
		array('name'  =>'JCRMTime_primary_key_index','type'  =>'primary','fields'  =>array('id')),
//		array('name'  =>'JCRMTime_speed_index','type'  =>'index','fields'  =>array('assigned_user_id', 'date', 'case_id', 'account_id')),
	),

	'relationships'=>array(
		'JCRMTime_assigned_user'=>array(
			'lhs_module'=>'Users','lhs_table'=>'users','lhs_key'=>'id',
			'rhs_module'=>'JCRMTime','rhs_table'=>'jcrmtime','rhs_key'=>'assigned_user_id',
			'relationship_type'=>'one-to-many'),

		'JCRMTime_modified_user'=>array(
			'lhs_module'=>'Users','lhs_table'=>'users','lhs_key'=>'id',
			'rhs_module'=>'JCRMTime','rhs_table'=>'jcrmtime','rhs_key'=>'modified_user_id',
			'relationship_type'=>'one-to-many'),

		'JCRMTime_created_by'=>array(
			'lhs_module'=>'Users','lhs_table'=>'users','lhs_key'=>'id',
			'rhs_module'=>'JCRMTime','rhs_table'=>'jcrmtime','rhs_key'=>'created_by',
			'relationship_type'=>'one-to-many'),

		'cases_jcrmtime'=>array(
			'lhs_module'=>'Cases','lhs_table'=>'cases','lhs_key'=>'id',
			'rhs_module'=>'JCRMtime','rhs_table'=>'jcrmtime','rhs_key'=>'case_id',
			'relationship_type'=>'one-to-many'),

		'relate_account'=>array(
			'lhs_module'=>'Accounts','lhs_table'=>'accounts','lhs_key'=>'id',
			'rhs_module'=>'JCRMTime','rhs_table'=>'jcrmtime','rhs_key'=>'account_id',
			'relationship_type'=>'one-to-many'),

		'relate_jcrminvoice'=>array(
			'lhs_module'=>'JCRMInvoices','lhs_table'=>'jcrminvoices','lhs_key'=>'id',
			'rhs_module'=>'JCRMTime','rhs_table'=>'jcrmtime','rhs_key'=>'invoice_id',
			'relationship_type'=>'one-to-many'),

	),
);
?>
