<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');

require_once('modules/JCRMInvoices/JCRMInvoice.php');
require_once('log4php/LoggerManager.php');
require_once('include/formbase.php');

$focus = new JCRMInvoice();

$focus = populateFromPost('', $focus);

$lines=array();
$i=1;
foreach($_REQUEST['line_num'] as $parent => $key) {
	if (isset($_REQUEST['line_desc'][$parent])) {
		$lines[$i]=array('desc'=>html_entity_decode($_REQUEST['line_desc'][$parent], ENT_QUOTES),
					 'vat_rate'=>html_entity_decode($_REQUEST['line_vat_rate'][$parent], ENT_QUOTES),
					 'amount'=>html_entity_decode($_REQUEST['line_amount'][$parent], ENT_QUOTES),
					 );
		$i++;
	}
}
$focus->set_invoice_lines($lines);

global $current_user;
if(empty($_REQUEST['currency_id'])){
    $currency_id = $current_user->getPreference('currency');
    if(isset($currency_id)){
        $focus->currency_id =   $currency_id;
    }
}

if(!$focus->ACLAccess('Save')){
	ACLController::displayNoAccess(true);
	sugar_cleanup(true);
}

$focus->save($GLOBALS['check_notify']);
$return_id = $focus->id;

if(is_array($_REQUEST['select_case'])) {
	$sql_add='';
	$sql_remove='';
	foreach($_REQUEST['select_case'] as $key=>$value) {
		$case_id=$_REQUEST['select_case'][$key];
		$user_id=$_REQUEST['select_user'][$key];
		$date=$_REQUEST['select_date'][$key];

		$sql="(jcrmtime.case_id='$case_id' and jcrmtime.assigned_user_id='$user_id' and jcrmtime.date='$date')";

		if($_REQUEST['select_invoice_id'][$key]==''){
			//if selected then we add this to invoice
			if(isset($_REQUEST['select_checked'][$key])) {
				if($sql_add != '') $sql_add.=' OR ';
				$sql_add.=$sql;
			}
		}
		else {
			//if not selected then we remove
			if(!isset($_REQUEST['select_checked'][$key])) {
				if($sql_remove != '') $sql_remove.=' OR ';
				$sql_remove.=$sql;
			}
		}

	}
	if($sql_add !='') {
		$sql="update jcrmtime set invoice_id='$return_id' where (".$sql_add.") and jcrmtime.invoice_id is null and jcrmtime.deleted != 1;";
	 	$focus->db->query($sql, true);
 	}
	if($sql_remove !='') {
		$sql="update jcrmtime set invoice_id=null where (".$sql_remove.") and jcrmtime.invoice_id='$return_id' and jcrmtime.deleted != 1;";
	 	$focus->db->query($sql, true);
 	}
}

handleRedirect($return_id,'JCRMInvoices');

?>
