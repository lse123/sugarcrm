<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');

global $current_user;
global $mod_strings;
$module_menu = array();

if(ACLController::checkAccess('JCRMInvoices', 'edit', true))
 $module_menu[] = array("index.php?module=JCRMInvoices&action=EditView&return_module=JCRMInvoices&return_action=DetailView", $mod_strings['LNK_NEW_JCRMINVOICES'], 'CreateJCRMInvoice');
if(ACLController::checkAccess('JCRMInvoices', 'edit', true))
 $module_menu[] = array('index.php?module=JCRMInvoices&action=CreateFromTime', $mod_strings['LNK_INVOICE_TIME_SUMMARY'], 'CreateJCRMInvoice');
if(ACLController::checkAccess('JCRMInvoices', 'list', true))
 $module_menu[] = array('index.php?module=JCRMInvoices&action=index', $mod_strings['LNK_LIST_JCRMINVOICES'], 'JCRMInvoices');

?>
