<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');

require_once('data/SugarBean.php');
require_once('include/database/PearDatabase.php');
require_once('include/utils.php');
include_once('config.php');
require_once('log4php/LoggerManager.php');
require_once('modules/Meetings/Meeting.php');
require_once('modules/Notes/Note.php');
require_once('modules/Emails/Email.php');

class JCRMInvoice extends SugarBean {
	var $id;
	var $date_entered;
	var $date_modified;
	var $assigned_user_id;
	var $modified_user_id;
	var $created_by;
	var $description;
	var $deleted;
	var $date_invoice;
	var $internal_ref;
	var $account_name;
	var $account_id;
	var $account_owner_id;
	var $contact_name;
	var $contact_id;
	var $contact_owner_id;
	var $invoice_number;
	var $invoice_lines;
	var $amount;
	var $amount_usdollar;
	var $currency_id;
	var $status;

	var $assigned_user_name;
	var $modified_by_name;
	var $created_by_name;
	var $email_id;

	var $object_name = 'JCRMInvoice';
	var $module_dir  = 'JCRMInvoices';
	var $new_schema  = true;
	var $table_name  = 'jcrminvoices';

	// This is used to retrieve related fields from form posts.
	var $additional_column_fields = array('description', 'date_invoice', 'internal_ref', 'account_id', 'contact_id', 'amount', 'status', 'currency_id');

	//used for accounts subpanel
	var $relationship_fields = array('account_name');

	function JCRMInvoice(){
		 parent::SugarBean();
//		 $this->unserialize_me();
	}

	function get_summary_text()
	{
		global $app_list_strings;
		return $app_list_strings['moduleListSingular']['JCRMInvoices'] . " ". $this->invoice_number;
	}

  /******************************************************************************
   * overriding the base class function to do a join with users table
   ******************************************************************************/
	function create_list_query($order_by, $where, $show_deleted = 0){
		$custom_join = $this->custom_fields->getJOIN();
		$query       = "SELECT
		                users.user_name assigned_user_name,
		                accounts.name account_name, ";

		//partial mssql compatability - need to resolve time aggregation
		//look at removing this override so not required
		if($this->db->dbType=='mssql') {
			$query .= "contacts.first_name + ' ' + contacts.last_name contact_name,";
		}
		else {
			$query .= "concat(contacts.first_name, ' ', contacts.last_name) contact_name,";
	    }

		$query .= "jcrminvoices.* ";

		if($custom_join){ $query .=  $custom_join['select']; }

		$query .= "     FROM jcrminvoices ";
		$query .= "LEFT JOIN users ON jcrminvoices.assigned_user_id=users.id ";
		$query .= "LEFT JOIN accounts ON jcrminvoices.account_id=accounts.id ";
		$query .= "LEFT JOIN contacts ON jcrminvoices.contact_id=contacts.id ";

		if($custom_join){ $query .=  $custom_join['join']; }

		$where_auto = '1=1';

		if($show_deleted == 0){
			$where_auto = "$this->table_name.deleted=0";
		}else if($show_deleted == 1){
			$where_auto = "$this->table_name.deleted=1";
		}
		if($where != '')
			$query .= "WHERE ($where) AND ".$where_auto;
		else
			$query .= "WHERE ".$where_auto;

		if(!empty($order_by))
			$query .= " ORDER BY $order_by";

		return $query;
	}

function create_export_query($order_by, $where){
	$custom_join = $this->custom_fields->getJOIN();
	$query       = "SELECT users.user_name assigned_user_name, jcrminvoices.*";

	if($custom_join){ $query .=  $custom_join['select']; }
	$query .= " FROM jcrminvoices ";
	$query .= "LEFT JOIN users ON jcrminvoices.assigned_user_id=users.id ";

	if($custom_join){ $query .=  $custom_join['join']; }

	$where_auto  = '1=1';
	if($show_deleted == 0){
		$where_auto = "$this->table_name.deleted=0";
	}else if($show_deleted == 1){
		$where_auto = "$this->table_name.deleted=1";
	}
	if($where != '')
		$query .= "WHERE ($where) AND ".$where_auto;
	else
	 	$query .= "WHERE ".$where_auto;

	if(!empty($order_by))
	 	$query .= " ORDER BY $order_by";

	return $query;
}

	function fill_in_additional_detail_fields(){
		//echo "fill_in_additional_detail_fields<br>";
	  	$this->assigned_user_name = get_assigned_user_name($this->assigned_user_id);

		//partial mssql compatability - need to resolve time aggregation
		if($this->db->dbType=='mssql') {
			$query  = " SELECT c.first_name + ' ' + c.last_name contact_name, ";
		}
		else {
			$query  = " SELECT concat(ifnull(c.first_name,'') , ' ', ifnull(c.last_name,'')) contact_name, ";
	    }

		$query .= " c.assigned_user_id contact_owner_id, a.name account_name, a.assigned_user_id account_owner_id ";
		$query .= " FROM jcrminvoices inv, contacts c, accounts a ";
		$query .= " WHERE inv.id='".$this->id."' AND c.id=inv.contact_id and a.id=inv.account_id";

		$result =$this->db->query($query,true," Error filling in additional detail fields: ");

		// Get the id and the name.
		$row = $this->db->fetchByAssoc($result);

		if($row != null)
		{
			$this->account_name = $row['account_name'];
		    $this->account_owner_id = $row['account_owner_id'];

			$this->contact_name = $row['contact_name'];
		    $this->contact_owner_id = $row['contact_owner_id'];

		     	}

		$this->created_by_name = get_assigned_user_name($this->created_by);
		$this->modified_by_name = get_assigned_user_name($this->modified_user_id);

		global $sugar_config;
		$symbol = $sugar_config['default_currency_symbol'];
		require_once('modules/Currencies/Currency.php');
		$currency = new Currency();
		$currency->retrieve($this->currency_id);
		if($currency->id != $this->currency_id || $currency->deleted == 1){
				$this->amount = $this->amount_usdollar;
				$this->currency_id = $currency->id;
		}
	}

	function fill_in_additional_list_fields(){
		//called by listview but not subpanel
		//echo "fill_in_additional_list_fields<br>";
		$this->assigned_user_name     = get_assigned_user_name($this->assigned_user_id);
	}

	function get_list_view_data(){
		//also used by subpanels
		global $current_user, $sugar_config;
		$field_list                       = $this->get_list_view_array();

		$symbol = $sugar_config['default_currency_symbol'];
		require_once('modules/Currencies/Currency.php');
		$currency = new Currency();
		$currency->retrieve($this->currency_id);
		$symbol = $currency->symbol;

//		$field_list['AMOUNT'] =   $symbol.'&nbsp;'. round($this->amount,2);
		$field_list['AMOUNT'] =  format_number($this->amount_usdollar, 2, 2, array('convert' => true, 'currency_symbol' => true));

		$field_list['USER_NAME']          = empty($this->user_name) ? '' : $this->user_name;
		$field_list['ASSIGNED_USER_NAME'] = $this->assigned_user_name;
		$field_list['ACCOUNT_NAME'] = $this->account_name;
		$field_list['CONTACT_NAME'] = $this->contact_name;
		return $field_list;
	}

	function bean_implements($interface){
		switch($interface){
			case 'ACL':return true;
		}
		return false;
	}

	function listviewACLHelper(){
		$array_assign = parent::listviewACLHelper();
		$is_contact_owner = false;
		$is_account_owner = false;
		if(!empty($this->contact_id)){

			if(!empty($this->contact_owner_id)){
				global $current_user;
				$is_contact_owner = $current_user->id == $this->contact_owner_id;
			}
		}

		if(!empty($this->account_id)){
			if(!empty($this->account_owner_id)){
				global $current_user;
				$is_account_owner = $current_user->id == $this->account_owner_id;
			}
		}

		if(!ACLController::moduleSupportsACL('Accounts') || ACLController::checkAccess('Accounts', 'view', $is_account_owner)){
			$array_assign['ACCOUNT'] = 'a';
		}else{
			$array_assign['ACCOUNT'] = 'span';
		}

		if(!ACLController::moduleSupportsACL('Cases') || ACLController::checkAccess('Contacts', 'view', $is_contact_owner)){
			$array_assign['CONTACT'] = 'a';
		}else{
			$array_assign['CONTACT'] = 'span';
		}


		return $array_assign;
	}

	function retrieve($id = -1, $encode=true) {
		$result=parent::retrieve($id, $encode);
//		$this->unserialize_me();
		return $result;
	}

	function add_invoice_line($line) {
		$lines=$this->invoice_lines_array();
		$lines[]=$line;
		$this->invoice_lines=serialize($lines);
	}

	function set_invoice_lines($lines) {
		$this->invoice_lines=serialize($lines);
	}

	function invoice_lines_array() {
		if($this->invoice_lines =='' || empty($this->invoice_lines)) {
//			$default_line=array(1=>array('desc'=>'', 'vat_rate'=>'', 'amount'=>''));
//			$this->invoice_lines=$default_line;
			return array();
		}
		elseif(!is_array($this->invoice_lines) && $this->invoice_lines !='Array') {
			return unserialize(html_entity_decode($this->invoice_lines, ENT_QUOTES));
		}
		elseif(is_array($this->invoice_lines)) {
			return $this->invoice_lines;
		}
		else {
			return array();
		}
	}

	function save($check_notify = FALSE) {
		require_once('modules/Currencies/Currency.php');
		//US DOLLAR
		if(isset($this->amount) && !number_empty($this->amount)){
			$currency = new Currency();
			$currency->retrieve($this->currency_id);
			$this->amount_usdollar = $currency->convertToDollar($this->amount);
		}
		return parent::save($check_notify);
	}

	function get_case_summary($sql=''){
		//show a summary of cases
		if($sql=='') $sql="jcrmtime.invoice_id='" . $this->id. "'";

		require_once('modules/JCRMReports/JCRMReport.php');
		//mssql note - may need to remove distinct
		$rpt_info=array("sql_select" => "distinct accounts.name as 'Account Name', cases.case_number as 'Case Number', cases.name as 'Case Name', cases.status as 'Status', cases.date_closed as 'Closed Date', cases.resolution as 'Resolution', accounts.id as 'account_id', cases.id as 'case_id'",
				  "sql_from" => "jcrmtime, cases, accounts",
				  "sql_where_join" => "jcrmtime.case_id = cases.id and accounts.id=cases.account_id and jcrmtime.deleted=0 and cases.deleted=0 and ($sql)",
				  "sql_group_by" => "",
				  "sql_order_by" => "1,2",
				  "columns" => array("account_id"=>array("query_only"=>true),
				  					"Account Name"=>array("callback"=>"DisplayAccountCell"),
									"case_id"=>array("query_only"=>true),
				  					"Case Name"=>array("callback"=>"DisplayCaseCell"),
				  					"Closed Date"=>array("callback"=>"DisplayDateCell")),
			  );

		global $moduleList;
		if(!in_array('Autocases',  $moduleList)) {
			// dont include closed date which is provided by autocases enhancement
			$rpt_info["sql_select"] = str_replace ( "cases.date_closed as 'Closed Date',", "",  $rpt_info["sql_select"]);
		}

		$rpt = new JCRMReport($rpt_info);
		return $rpt->report_html();

	}

	function get_time_summary($sql=''){
		//show a summary of time
		if($sql=='') $sql="jcrmtime.invoice_id='" . $this->id. "'";

		require_once('modules/JCRMReports/JCRMReport.php');
		$rpt_info=array("sql_select" => "accounts.name as 'Account Name', cases.case_number as 'Case Number', cases.name as 'Case Name', users.user_name as 'User', accounts.id as 'account_id', cases.id as 'case_id', TIME_FORMAT(sec_to_time(sum(time_to_sec(jcrmtime.time_length))), '%H:%i') as 'Time'",
				  "sql_from" => "jcrmtime, users, cases, accounts",
				  "sql_where_join" => "jcrmtime.assigned_user_id=users.id and jcrmtime.case_id = cases.id and accounts.id=cases.account_id and jcrmtime.deleted=0 and cases.deleted=0 and ($sql)",
				  "sql_group_by" => "1, 2, 3, 4, 5, 6",
				  "sql_order_by" => "1,3,4",
				  "columns" => array("account_id"=>array("query_only"=>true),
				  					"Account Name"=>array("callback"=>"DisplayAccountCell"),
									"case_id"=>array("query_only"=>true),
				  					"Case Name"=>array("callback"=>"DisplayCaseCell"),
				  					"Time"=>array("callback"=>"DisplayTimeCell")),
			  );

		$rpt = new JCRMReport($rpt_info);
		return $rpt->report_html();

	}

	function get_time_summary_by_date($sql=''){

		//show all time by date and user
		if($sql=='') $sql="jcrmtime.invoice_id='" . $this->id. "'";

		$rpt_info=array("sql_select" => "accounts.name as 'Account Name', accounts.id as 'account_id', cases.case_number as 'Case Number', cases.name as 'Case Name', cases.status as 'Status', users.user_name as 'User', jcrmtime.date as 'Date', jcrmtime.case_id, jcrmtime.assigned_user_id, jcrmtime.invoice_id, TIME_FORMAT(sec_to_time(sum(time_to_sec(jcrmtime.time_length))), '%H:%i') as 'Time', '' as 'Select'",
				  "sql_from" => "jcrmtime, users, cases, accounts",
				  "sql_where_join" => "jcrmtime.assigned_user_id=users.id and jcrmtime.case_id = cases.id and accounts.id=cases.account_id and jcrmtime.deleted=0 and cases.deleted=0 and ($sql)",
				  "sql_group_by" => "1, 2, 3, 4, 5, 6, 7, 8, 9",
				  "sql_order_by" => "1,2,6",
				  "table_id" => "tbl_select_time",
				  "columns" => array("Account Name"=>array("callback"=>"DisplayAccountCell"),
				                     "account_id"=>array("query_only"=>true),
									 "Case Name"=>array("callback"=>"DisplayCaseCell"),
				  					 "Select"=>array("callback"=>"DisplaySelectCell"),
								     "Date"=>array("callback"=>"DisplayDateCell"),
				  					 "invoice_id"=>array("query_only"=>true),
				  					 "assigned_user_id"=>array("query_only"=>true),
								     "case_id"=>array("query_only"=>true)),
			  );
		//disable the select time if not being created from time
		if($_REQUEST['action']!='EditView')
		$rpt_info['columns']['Select']=array("query_only"=>true);

		$rpt = new JCRMReport($rpt_info);
		return $rpt->report_html();

	}
 }

function DisplayAccountCell($row, $key, $value) {
	return '<a href="index.php?module=Accounts&action=DetailView&record='.$row['account_id'].'" class="listViewTdLinkS1">'.$value.'</a>';
}

function DisplayCaseCell($row, $key, $value) {
	return '<a href="index.php?module=Cases&action=DetailView&record='.$row['case_id'].'" class="listViewTdLinkS1">'.$value.'</a>';
}

function DisplayDateCell($row, $key, $value) {
	global $timedate;
	return $timedate->to_display_date($value);
}
function DisplayTimeCell($row, $key, $value) {
	return '<span id = "'. $row['Case Number'].$row['User'] .'">'.$value.'</span>';
}

function DisplaySelectCell($row, $key, $value) {
	static $rownum=0;
	$rownum++;
	$html=  '<input name="select_checked['.$rownum.']" type="checkbox" value="true" class="checkbox" CHECKED onclick="update_summary(this, \''.$row['Case Number'].'\', \''.$row['User'].'\', \''.$row['Time'].'\');">';
	$html.= '<input name="select_case['.$rownum.']" type="hidden" value="'.$row['case_id'].'">';
	$html.= '<input name="select_user['.$rownum.']" type="hidden" value="'.$row['assigned_user_id'].'">';
	$html.= '<input name="select_date['.$rownum.']" type="hidden" value="'.$row['Date'].'">';
	$html.= '<input name="select_invoice_id['.$rownum.']" type="hidden" value="'.$row['invoice_id'].'">';

	return $html;
}

 ?>
