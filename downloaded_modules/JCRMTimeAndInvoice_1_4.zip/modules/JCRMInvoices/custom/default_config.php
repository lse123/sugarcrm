<?php
/*********************************************************************************
justcrms - contacts us for license information
Use this file to alter the invoice

Instructions -

1) create a copy of this file and call it /modules/JCRMInvoices/custom/config.php

2) modify Print.html into a new file and point to it using the below structure.
   Note that the HTML2PDF mechanism is not very functional e.g. you can't have
   different styles in different table cells and it favours A4 Portrait.

3) and / or create new graphics files and point to them using the below structure.
   Note that the dimensions are in mm.

if a config.php file is found then it will be used instead of default_config.php
this way when you upgrade to the latest version of the module your customisations
will be kept !
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');

//april 2009
global $InvoiceConfig;

$InvoiceConfig=array("template_path"=>'modules/JCRMInvoices/custom/default_print.html',
					"header"=>array('x'=>10, 'y'=>10, 'w'=>70, 'h'=>27, 'path'=>'modules/JCRMInvoices/custom/default_invoice_header.jpg'),
					"footer"=>array('x'=>0, 'y'=>265, 'w'=>210, 'h'=>32, 'path'=>'modules/JCRMInvoices/custom/default_invoice_footer.jpg'));


?>
