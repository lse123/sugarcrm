<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');
include ("modules/JCRMInvoices/ListView.php");

?>
