<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');

//Create javascript to validate the data entered into a record.
  function get_validate_record_js ()
  {
   return '';
  }

?>
