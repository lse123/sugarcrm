<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');

/* use manual subpanel for time as we summarise by date and user */
$layout_defs['JCRMInvoices'] = array();
?>
