<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');

require_once('XTemplate/xtpl.php');
require_once('modules/JCRMInvoices/JCRMInvoice.php');
require_once('modules/JCRMReports/JCRMExpression.php');
require_once("modules/JCRMReports/html2pdf/html2fpdf.php");

global $app_list_strings;
$GLOBALS['log']->info('JCRMInvoice module print view');
$focus = new JCRMInvoice();
if(!$focus->retrieve($_REQUEST['record'])) {
     sugar_die("Error retrieving record.  You may not be authorized to view this record.");
}

if(file_exists('modules/JCRMInvoices/custom/config.php')) {
	require_once('modules/JCRMInvoices/custom/config.php');
}
else {
	require_once('modules/JCRMInvoices/custom/default_config.php');
}

class InvoicePDF extends HTML2FPDF
{
  var $header; //array for header information
  var $footer; //array for footer information

	function Header()
	{
		//global $InvoiceConfig;
		$pos=$this-> header;

		if(file_exists($pos['path']))
	    $this->Image($pos['path'], $pos['x'], $pos['y'], $pos['w'], $pos['h']);

	    //Line break
	    //$this->Ln(10);
		//$this->y=80;
	}
	//Page footer
	function Footer()
	{
	    //Position at 1.5 cm from bottom
//	    $this->SetY(-30);
	    //Arial italic 8
	 //   $this->SetFont('Arial','I',8);
	    //Page number
	   // $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');

		//global $InvoiceConfig;

		$pos=$this-> footer;
		if(file_exists($pos['path']))
	    $this->Image($pos['path'], $pos['x'], $pos['y'], $pos['w'], $pos['h']);
	}

}

function currency($amt, $zero='') {
	if($amt!=0) {
		return number_format($amt, 2);
	}
	else {
		return $zero;
	}
}

//Get file contents
global $InvoiceConfig;
$xtpl=new XTemplate($InvoiceConfig['template_path']);

//now we can assign variables from account and contact
$expr=new JCRMExpression();
require_once('modules/Accounts/Account.php');
$account=new Account();
$account->retrieve($focus->account_id);
$account->billing_address_street=str_replace("\r\n", "<br>", $account->billing_address_street); //windows
$account->billing_address_street=str_replace("\n", "<br>", $account->billing_address_street);   //unix
$xtpl->assign('ACCOUNT', $expr->bean_to_array($account));

require_once('modules/Contacts/Contact.php');
$contact=new Contact();
$contact->retrieve($focus->contact_id);
$xtpl->assign('CONTACT', $expr->bean_to_array($contact));

$xtpl->assign('INVOICE', $expr->bean_to_array($focus));

//now load invoice lines
$vat=array();
$total=0;

$lines=$focus->invoice_lines_array();
foreach($lines as $num=>$array) {
	$vat_rate=$app_list_strings['jcrminvoice_vat_rate_dom'][$array['vat_rate']];

	//vat totalling start
	if(!isset($vat[$vat_rate])) {
		$vat[$vat_rate]=array('amt'=>0, 'vat'=>0);
	}

	$vat[$vat_rate]['vat']=$vat[$vat_rate]['vat']+($array['amount'] * ($vat_rate/100));
	$vat[$vat_rate]['amt']=$vat[$vat_rate]['amt']+$array['amount'];
	$total=$total+$array['amount'];
	//end of vat totalling

	$xtpl->assign('LINE_NUM', $num);
	$xtpl->assign('LINE_DESC', $array['desc']);

	if($array['amount']!='' && $array['amount']!='0'){
		$xtpl->assign("LINE_VAT_RATE", $vat_rate.'%');
	}
	else {
		$xtpl->assign("LINE_VAT_RATE", '');
	}
	$xtpl->assign('LINE_AMOUNT', currency($array['amount']));

	//fix for blank lines
	if (trim(currency($array['amount']).$array['desc'])=='') {
		$xtpl->assign('FORCE_BLANK_LINE', '</table><br><table>');
	}

	$xtpl->parse("main.line");
}

//loop through vat summary
foreach($vat as $rate=>$vat_total) {
	if($vat_total['vat']>0){
		$total=$total+$vat_total['vat'];
		$xtpl->assign("SUMMARY_VAT_RATE", $rate);
		$xtpl->assign('SUMMARY_VAT_AMOUNT', currency($vat_total['amt'], '0.00'));
		$xtpl->assign('SUMMARY_VAT_VAT', currency($vat_total['vat'], '0.00'));
		$xtpl->parse("main.summary");
	}
}

$xtpl->assign('TOTAL_AMOUNT', currency($total));


require_once('modules/Currencies/Currency.php');
$currency  = new Currency();
$curr='';
if(isset($focus->currency_id) && !empty($focus->currency_id))
{
	$currency->retrieve($focus->currency_id);
	if( $currency->deleted != 1){
		$curr=$currency->name;
	}else $curr= $currency->getDefaultCurrencyName();
}else{
	$curr=$currency->getDefaultCurrencyName();
}
if($curr=='Euro') $curr='�';

$xtpl->assign("CURRENCY", $curr);

//now output and get result
$xtpl->parse("main");
$buffer=$xtpl->text("main");

//Initialize class
//define RELATIVE_PATH,FPDF_FONTPATH if needed
$pdf=new InvoicePDF();
$pdf->header=$InvoiceConfig['header'];
$pdf->footer=$InvoiceConfig['footer'];
$pdf->tMargin=40;
$pdf->bMargin=30;
$pdf->AddPage();

//Code below used only if you want relative links to be understood
//$pdf->setBasePath(dirname(__FILE__)."\".$htmlFile);//insert full path where

//april 2009
header('Content-type: application/pdf');

$pdf->WriteHTML($buffer);

$pdf->Output("Invoice.pdf", "I"); //Read the FPDF.org manual to know the other options
exit;

?>