<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');
require_once('include/utils.php');

function additionalDetailsJCRMInvoice($fields) {
	static $mod_strings;
	if(empty($mod_strings)) {
		global $current_language;
		$mod_strings = return_module_language($current_language, 'JCRMInvoices');
	}
	$overlib_string = '';

	if(!empty($fields['DESCRIPTION'])) {
		$overlib_string .= '<b>'. $mod_strings['LBL_DESCRIPTION'] . '</b> ' . substr($fields['DESCRIPTION'], 0, 300).'<br>';
		if(strlen($fields['DESCRIPTION']) > 300) $overlib_string .= '...';
	}

	//may be string 'Array' if incorrectly set by mass update bug sept 2007
	if(!empty($fields['INVOICE_LINES']) && $fields['INVOICE_LINES'] != 'Array') {
		$lines=unserialize(html_entity_decode($fields['INVOICE_LINES'], ENT_QUOTES));

		if(is_array($lines)) {
			$overlib_string .= '<table>';
			$overlib_string .= '<tr><td><b>'. $mod_strings['LBL_LINE_DESC'] . '</td><td>'. $mod_strings['LBL_LINE_VAT_RATE'].'</td><td>'.$mod_strings['LBL_LINE_AMOUNT'].'</b></td></tr>';
			foreach ($lines as $line) {
				$overlib_string .= '<tr><td>'. str_replace('"', '', $line['desc']) . '</td><td>'. $line['vat_rate'].'</td><td>'.$line['amount'].'</td></tr>';
			}
			$overlib_string .= '</table>';
		}
	}

	return array(
       'fieldToAddTo' => 'INVOICE_NUMBER',
       'string'       => $overlib_string,
       'editLink'     => "index.php?action=EditView&module=JCRMInvoices&return_module=JCRMInvoices&record={$fields['ID']}",
       'viewLink'     => "index.php?action=DetailView&module=JCRMInvoices&return_module=JCRMInvoices&record={$fields['ID']}");
}

 ?>


