<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');

require_once('include/generic/SugarWidgets/SugarWidgetSubPanelTopButton.php');

class SugarWidgetJCRMCreateInvoiceFromTime extends SugarWidgetSubPanelTopButton
{
	function SugarWidgetJCRMCreateInvoiceFromTime($module='', $title='', $access_key='', $form_value='')
	{
		$mymodule=array('module'=>'JCRMInvoices',
					  'form_value'=>'LNK_INVOICE_TIME_SUMMARY',
					  'ACL'=>'edit',
		        		'additional_form_fields' => array(
		        			'reports_to_name' => 'name',
							'reports_to_id' => 'id',
						));

		return parent::SugarWidgetSubPanelTopButton($mymodule, $title, $access_key, $form_value);
	}

	function display($defines, $additionalFormFields = null)
 	{
 		$html=parent::display($defines, $additionalFormFields);
 		$html=str_replace('EditView', 'CreateFromTime', $html);
 		return $html;
 	}
}

class SugarWidgetJCRMCreateInvoice extends SugarWidgetSubPanelTopButton
{
	function SugarWidgetJCRMCreateInvoice($module='', $title='', $access_key='', $form_value='')
	{
		$mymodule=array('module'=>'JCRMInvoices',
					  'form_value'=>'LNK_NEW_JCRMINVOICES',
					  'ACL'=>'edit',
		        		'additional_form_fields' => array()
		        		);

		return parent::SugarWidgetSubPanelTopButton($mymodule, $title, $access_key, $form_value);
	}
}

$subpanel_layout = array(
	'top_buttons' => array(array('widget_class'=>'JCRMCreateInvoiceFromTime'),
							array('widget_class'=>'JCRMCreateInvoice'),
					 ),

	'where'            => "jcrminvoices.account_id='".$_REQUEST['record']."'",
	'default_order_by' => 'jcrminvoices.invoice_number',

	'list_fields' => array(
		'invoice_number'         =>array(
		 	'vname'         => 'LBL_LIST_INVOICE_NUMBER',
			'widget_class'  => 'SubPanelDetailViewLink',
		 	'width'         => '5%',
			),
		'date_invoice'         =>array(
		 	'vname'         => 'LBL_LIST_DATE_INVOICE',
		 	'width'         => '10%',
			),
		'contact_name'         =>array(
		 	'vname'         => 'LBL_LIST_CONTACT_NAME',
		 	'width'         => '25%',
			'widget_class'  => 'SubPanelDetailViewLink',
			 'target_record_key' => 'contact_id',
			 'target_module' => 'Contacts',
			),
		'internal_ref'         =>array(
		 	'vname'         => 'LBL_LIST_INTERNAL_REF',
		 	'width'         => '15%',
			),
		'amount'         =>array(
		 	'vname'         => 'LBL_LIST_AMOUNT',
		 	'width'         => '10%',
			),
		'usdollor_amount'         =>array(
			'usage' => 'query_only',
			),
		'currency_id'         =>array(
			'usage' => 'query_only',
			),
		'status'         =>array(
		 	'vname'         => 'LBL_LIST_STATUS',
		 	'width'         => '15%',
			),
		'assigned_user_name'         =>array(
		 	'vname'         => 'LBL_LIST_ASSIGNED_USER',
		 	'width'         => '10%',
			),
		'edit_button' => array(
			'widget_class' => 'SubPanelEditButton',
			'width' => '4%',
		),
	),
);


?>
