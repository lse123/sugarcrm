<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');

require_once('XTemplate/xtpl.php');
require_once('include/ListView/ListView.php');
require_once('log4php/LoggerManager.php');
require_once('include/modules.php');
require_once('modules/JCRMInvoices/JCRMInvoice.php');

global $current_language;
global $app_strings;
global $app_list_strings;
global $theme;
$theme_path = 'themes/' . $theme . '/';
$image_path = $theme_path .'images/';
require_once($theme_path . 'layout_utils.php');
global $mod_strings;

echo "\n<p>\n";
echo get_module_title('', "<IMG src='themes/Default/images/JCRMInvoices.gif' width='16' height='16' border='0' style='margin-top: 3px;' alt='JCRMInvoices'>&nbsp;".$mod_strings['LBL_MODULE_NAME'], true);
echo "\n</p>\n";

if (isset($sugar_config)) {
	if ($sugar_config['sugar_version'] >= '4.5.0') {
		require_once('include/QuickSearchDefaults.php');
		$qsd = new QuickSearchDefaults();
		echo $qsd->GetQSScripts();
	}else{
		include('include/QuickSearchDefaults.php');
		echo $qsScripts;
	}
}

$mod_strings = return_module_language($current_language, 'JCRMInvoices');

if (!isset($where)) $where = '';
require_once('modules/MySettings/StoreQuery.php');
$storeQuery = new StoreQuery();
if($_REQUEST['action'] == 'index' || $_REQUEST['action'] == 'ListView'){
	if(!isset($_REQUEST['query'])){
		$storeQuery->loadQuery($currentModule);
		$storeQuery->populateRequest();
	}else{
		$storeQuery->saveFromGet($currentModule);
	}
}
$seedJCRMInvoice = new JCRMInvoice();
$where_clauses = array();

if(isset($_REQUEST['query'])){
	// we have a query
	if (isset($_REQUEST['invoice_number'])) $invoice_number = $_REQUEST['invoice_number'];
	if (isset($_REQUEST['internal_ref'])) $internal_ref = $_REQUEST['internal_ref'];
	if (isset($_REQUEST['account_name'])) $account_name = $_REQUEST['account_name'];
	if (isset($_REQUEST['contact_name'])) $contact_name = $_REQUEST['contact_name'];
	if (isset($_REQUEST['date_from'])) $date_from = $_REQUEST['date_from'];
	if (isset($_REQUEST['date_to'])) $date_to = $_REQUEST['date_to'];
	if (isset($_REQUEST['assigned_user_id'])) $assigned_user_id = $_REQUEST['assigned_user_id'];
	if (isset($_REQUEST['status'])) $status = $_REQUEST['status'];

	if (isset($assigned_user_id) && is_array($assigned_user_id))
	{
		$count = count($assigned_user_id);
		if ($count > 0 ) {
			if (!empty($where)) {
				$where .= " AND ";
			}
			$where .= "jcrminvoices.assigned_user_id IN(";
			foreach ($assigned_user_id as $key => $val) {
				$where .= "'$val'";
				$where .= ($key == count($assigned_user_id) - 1) ? ")" : ", ";
			}

			array_push($where_clauses, $where);

		}
	}

	require_once('include/TimeDate.php');
	$dt = new TimeDate();

	if(isset($date_from) && $date_from != "") {
		$convdt = $dt->swap_formats($date_from, $dt->get_date_format(), $dt->dbDayFormat);
		array_push($where_clauses, "jcrminvoices.date_invoice >= '$convdt 00:00:00'");
	}

	if(isset($date_to) && $date_to != "") {
		$convdt = $dt->swap_formats($date_to, $dt->get_date_format(), $dt->dbDayFormat);
		array_push($where_clauses, "jcrminvoices.date_invoice <= '$convdt 23:59:59'");
	}

	if(isset($account_name) && $account_name != "") array_push($where_clauses, "accounts.name like '%".PearDatabase::quote($account_name)."%'");
	if(isset($contact_name) && $contact_name != "") array_push($where_clauses, "concat(contacts.first_name, ' ', contacts.last_name) like '%".PearDatabase::quote($contact_name)."%'");
	if(isset($invoice_number) && $invoice_number != "") array_push($where_clauses, "invoice_number = '".PearDatabase::quote($invoice_number)."'");
	if(isset($internal_ref) && $internal_ref != "") array_push($where_clauses, "jcrminvoices.internal_ref like '%".PearDatabase::quote($internal_ref)."%'");
	if(isset($status) && $status != "") array_push($where_clauses, "jcrminvoices.status = '".PearDatabase::quote($status)."'");


	$seedJCRMInvoice->custom_fields->setWhereClauses($where_clauses);

	$where = '';
	foreach($where_clauses as $clause){
		if($where != '')
		$where .= ' AND ';
		$where .= $clause;
	}
	$GLOBALS['log']->info("Here is the where clause for the list view: $where");

}

$seed_simple = new JCRMInvoice();

if(empty($_REQUEST['search_form'])){
	$search_form = new XTemplate('modules/JCRMInvoices/SearchForm.html');

	$header_text = '';
	if(is_admin($current_user)
	 && $_REQUEST['module'] != 'DynamicLayout'
	 && !empty($_SESSION['editinplace']))
	{
	 $header_text = "<a href='index.php?action=index&module=DynamicLayout&from_action=SearchForm&from_module="
	  .$_REQUEST['module'] ."'>"
	  .get_image($image_path."EditLayout","border='0' alt='Edit Layout' align='bottom'")
	  ."</a>";
	}

	$header = get_form_header($mod_strings['LBL_SEARCH_FORM_TITLE'], $header_text, false);

	$search_form->assign('header',     $header);
	$search_form->assign('MOD',        $mod_strings);
	$search_form->assign('APP',        $app_strings);
	$search_form->assign("IMAGE_PATH", $image_path);

	$search_form->assign("JAVASCRIPT", get_clear_form_js());
	$search_form->assign("CALENDAR_DATEFORMAT", $timedate->get_cal_date_format());
	global $theme;
	$search_form->assign("THEME", $theme);

	if (!empty($assigned_user_id)) $search_form->assign("USER_FILTER", get_select_options_with_id(get_user_array(FALSE), $assigned_user_id));
	else $search_form->assign("USER_FILTER", get_select_options_with_id(get_user_array(FALSE), ''));

	$status_dom = $app_list_strings['jcrminvoice_status'];
	array_unshift($status_dom, '');

	if (!empty($status)) $search_form->assign("STATUS_FILTER", get_select_options_with_id($status_dom, $status));
	else $search_form->assign("STATUS_FILTER", get_select_options_with_id($status_dom, ''));

	if(isset($invoice_number)) $search_form->assign("INVOICE_NUMBER", $invoice_number);
	if(isset($internal_ref)) $search_form->assign("INTERNAL_REF", $internal_ref);
	if(isset($account_name)) $search_form->assign("ACCOUNT_NAME", $account_name);
	if(isset($contact_name)) $search_form->assign("CONTACT_NAME", $contact_name);
	if(isset($date_from)) $search_form->assign("DATE_FROM", $date_from);
	if(isset($date_to)) $search_form->assign("DATE_TO", $date_to);

	// Adding custom fields:
	$seedJCRMInvoice->custom_fields->populateXTPL($search_form, 'search' );
	$search_form->parse('main');
	$search_form->out('main');
}

$theme_path = "themes/$theme";
$img_path   = "$theme_path/images";

$listview   = new ListView();
$listview->initNewXTemplate('modules/JCRMInvoices/ListView.html', $mod_strings);
$listview->setHeaderTitle($mod_strings['LBL_LIST_FORM_TITLE']);

if(is_admin($current_user)
 && $_REQUEST['module'] != 'DynamicLayout'
 && !empty($_SESSION['editinplace']))
{
 $listview->setHeaderText("<a href='index.php?action=index&module=DynamicLayout&from_action=ListView&from_module="
  .$_REQUEST['module'] ."'>"
  .get_image($image_path."EditLayout","border='0' alt='Edit Layout' align='bottom'")
  ."</a>" );
}

$listview->setQuery($where, '', 'invoice_number', 'JCRMINVOICE');
$listview->setAdditionalDetails();
$listview->processListView($seed_simple,  'main', 'JCRMINVOICE');

?>
