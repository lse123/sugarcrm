<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');
$mod_strings = array (
 'LBL_MODULE_NAME'                      => 'Invoices',
 'LBL_MODULE_TITLE'                     => 'Invoices: Home',
 'LBL_SEARCH_FORM_TITLE'                => 'Invoices Search',
 'LBL_LIST_FORM_TITLE'                  => 'Invoices List',
 'LBL_HISTORY_TITLE'                    => 'History',

 'LBL_ID'                               => 'Id:',
 'LBL_DATE_ENTERED'                     => 'Date Entered:',
 'LBL_DATE_MODIFIED'                    => 'Date Modified:',
 'LBL_ASSIGNED_USER_ID'                 => 'Assigned To:',
 'LBL_ASSIGNED_USER_NAME'               => 'Assigned To:',
 'LBL_LAST_MODIFIED'                 	=> 'Last Modified:',
 'LBL_CREATED_BY'                       => 'Created:',
 'LBL_TEAM_ID'                          => 'Team:',
 'LBL_NAME'                             => 'Name:',
 'LBL_DESCRIPTION'                      => 'Description:',
 'LBL_DELETED'                          => 'Deleted:',
 'LBL_DATE_FROM'                          => 'Date From:',
 'LBL_DATE_TO'                          => 'Date To:',

 'LBL_LIST_ASSIGNED_USER_NAME'            => 'Assigned To',

 'LBL_DEFAULT_SUBPANEL_TITLE'           => 'Invoices',

 'LNK_NEW_JCRMINVOICES'                    => 'Create Invoice',
 'LNK_LIST_JCRMINVOICES'                   => 'Invoices',

 'LBL_DATE_INVOICE' => 'Invoice Date:',
 'LBL_INTERNAL_REF' => 'Internal Reference:',
 'LBL_ACCOUNT_NAME' => 'Account Name:',
 'LBL_CONTACT_NAME' => 'Contact Name:',
 'LBL_INVOICE_NUMBER' => 'Invoice Number:',
 'LBL_INVOICE_LINES' => 'Invoice Lines:',
 'LBL_AMOUNT' => 'Amount:',
 'LBL_STATUS' => 'Status:',

 'LBL_LIST_DATE_INVOICE' => 'Invoice Date',
 'LBL_LIST_INTERNAL_REF' => 'Internal Reference',
 'LBL_LIST_ACCOUNT_NAME' => 'Account Name',
 'LBL_LIST_CONTACT_NAME' => 'Contact Name',
 'LBL_LIST_INVOICE_NUMBER' => 'Invoice Number',
 'LBL_LIST_INVOICE_LINES' => 'Invoice Lines',
 'LBL_LIST_AMOUNT' => 'Amount',
 'LBL_LIST_STATUS' => 'Status',
 'LBL_LIST_VIEW' =>'View',

 'LBL_JCRMTIME_SUBPANEL_TITLE' => 'Time',

  'LBL_CURRENCY' => 'Currency:',
  'LBL_LINE_NUM' => 'No',
  'LBL_LINE_DESC' => 'Description',
  'LBL_LINE_VAT_RATE' => 'Vat',
  'LBL_LINE_AMOUNT' => 'Amount',

  'ADD_LINE' => 'Add Line',
  'UP' => 'Up',
  'DOWN' => 'Down',
  'REMOVE' => 'Remove',

  'LNK_INVOICE_TIME_SUMMARY' => 'Create from Time',
  'LBL_CASE_SUMMARY' => 'Case Summary',
  'LBL_TIME_SUMMARY' => 'Time Summary',
  'LBL_TIME_DETAIL' => 'Time Detail',

  'LBL_ADD_TIME_BUTTON_TITLE' =>'Add Time',
  'LBL_ADD_TIME_BUTTON' =>'Add Time',

  'LBL_TIME_SUBPANEL' =>'Time for Invoice',

	'CREATE_INV_FROM_TIME' => 'Create Invoice from unbilled Time',
	'ADD_TIME_TO_INV' => 'Add unbilled Time to Invoice',
	'SELECT_CASES' => 'You must select one or more cases.',
	'NO_UNBILLED_TIME' => 'No unbilled time found.',
	'ADD_SELECTED' => 'Add Selected to Invoice',
	'CREATE_INVOICE' => 'Create Invoice',

);
?>
