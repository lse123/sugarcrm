<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');
$mod_strings = array (
 'LBL_MODULE_NAME'                      => 'Rechnungen',
 'LBL_MODULE_TITLE'                     => 'Rechnung: Start',
 'LBL_SEARCH_FORM_TITLE'                => 'Rechnungen Suche',
 'LBL_LIST_FORM_TITLE'                  => 'Rechnungen Liste',
 'LBL_HISTORY_TITLE'                    => 'Historie',

 'LBL_ID'                               => 'Id:',
 'LBL_DATE_ENTERED'                     => 'Erfassungsdatum:',
 'LBL_DATE_MODIFIED'                    => 'Bearbeitungsdatum:',
 'LBL_ASSIGNED_USER_ID'                 => 'Mitarbeiter ID:',
 'LBL_ASSIGNED_USER_NAME'               => 'Mitarbeiter:',
 'LBL_LAST_MODIFIED'                 	=> 'Zuletzt bearbeitet:',
 'LBL_CREATED_BY'                       => 'Erstellt von:',
 'LBL_TEAM_ID'                          => 'Team:',
 'LBL_NAME'                             => 'Name:',
 'LBL_DESCRIPTION'                      => 'Beschreibung:',
 'LBL_DELETED'                          => 'Gel&ouml;scht:',
 'LBL_DATE_FROM'                        => 'Von Datum:',
 'LBL_DATE_TO'                          => 'Bis Datum:',

 'LBL_LIST_ASSIGNED_USER_NAME'          => 'Zugeordneter Mitarbeiter',

 'LBL_DEFAULT_SUBPANEL_TITLE'           => 'Rechnungen',

 'LNK_NEW_JCRMINVOICES'               => 'Rechnung erstellen',
 'LNK_LIST_JCRMINVOICES'              => 'Rechnungen',

 'LBL_DATE_INVOICE' => 'Rechnungsdatum:',
 'LBL_INTERNAL_REF' => 'Unser Zeichen:',
 'LBL_ACCOUNT_NAME' => 'Kunde:',
 'LBL_CONTACT_NAME' => 'Ihr Zeichen:',
 'LBL_INVOICE_NUMBER' => 'Rechnungsnummer:',
 'LBL_INVOICE_LINES' => 'Rechnungspositonen:',
 'LBL_AMOUNT' => 'Betrag:',
 'LBL_STATUS' => 'Status:',

 'LBL_LIST_DATE_INVOICE' => 'Rechnungsdatum',
 'LBL_LIST_INTERNAL_REF' => 'Unser Zeichen',
 'LBL_LIST_ACCOUNT_NAME' => 'Kunde',
 'LBL_LIST_CONTACT_NAME' => 'Ihr Zeichen',
 'LBL_LIST_INVOICE_NUMBER' => 'Rechnugsnummer',
 'LBL_LIST_INVOICE_LINES' => 'Rechnungspositonen',
 'LBL_LIST_AMOUNT' => 'Betrag',
 'LBL_LIST_STATUS' => 'Status',
 'LBL_LIST_VIEW' =>'Vorschau',

 'LBL_JCRMTIME_SUBPANEL_TITLE' => 'Zeit',

  'LBL_CURRENCY' => 'W&auml;hrung:',
  'LBL_LINE_NUM' => 'Nr.',
  'LBL_LINE_DESC' => 'Beschreibung',
  'LBL_LINE_VAT_RATE' => 'MwSt.',
  'LBL_LINE_AMOUNT' => 'Betrag',

  'ADD_LINE' => 'Position hinzuf&uuml;gen',
  'UP' => 'Auf',
  'DOWN' => 'Ab',
  'REMOVE' => 'Entfernen',

  'LNK_INVOICE_TIME_SUMMARY' => 'Zeitpunkt der Erstellung',
  'LBL_CASE_SUMMARY' => 'Total der F&auml;lle',
  'LBL_TIME_SUMMARY' => 'Zeiten &Uuml;bersicht',
  'LBL_TIME_DETAIL' => 'Zeiten Details',

  'LBL_ADD_TIME_BUTTON_TITLE' =>'Zeit hinzuf&uuml;gen',
  'LBL_ADD_TIME_BUTTON' =>'Zeit hinzuf&uuml;gen',

  'LBL_TIME_SUBPANEL' =>'Zeiten der Rechnung',

	'CREATE_INV_FROM_TIME' => 'Rechnung f&uuml;r unverechnete Positionen erstellen',
	'ADD_TIME_TO_INV' => 'Unvererechnete Zeiten zu Rechnung hinzuf&uuml;gen',
	'SELECT_CASES' => 'Sie m&uuml;ssen einen oder mehrere F&auml;lle ausw&auml;hlen.',
	'NO_UNBILLED_TIME' => 'Keine unverechnete Zeiten gefunden.',
	'ADD_SELECTED' => 'Ausgew&auml;hlte Zeiten zur Rechnung hinzuf&uuml;gen',
	'CREATE_INVOICE' => 'Rechnung erstellen',

);
?>
