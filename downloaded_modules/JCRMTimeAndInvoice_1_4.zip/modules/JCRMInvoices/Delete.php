<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');

require_once('modules/JCRMInvoices/JCRMInvoice.php');
require_once('log4php/LoggerManager.php');

$sugarbean = new JCRMInvoice();

//Perform the delete if given a record to delete
if(empty($_REQUEST['record'])){
	$GLOBALS['log']->info('delete called without a record id specified');
}else{
	$record = $_REQUEST['record'];
	$sugarbean->retrieve($record);
	if(!$sugarbean->ACLAccess('Delete')){
		ACLController::displayNoAccess(true);
		sugar_cleanup(true);
	}
	$GLOBALS['log']->info("deleting record: $record");
	$sugarbean->mark_deleted($record);
}

//Handle the return location variables
$return_module = empty($_REQUEST['return_module']) ? 'JCRMInvoices'   : $_REQUEST['return_module'];
$return_action = empty($_REQUEST['return_action']) ? 'index'          : $_REQUEST['return_action'];
$return_id = empty($_REQUEST['return_id']) ? ''                       : $_REQUEST['return_id'];
$return_location = "index.php?module=$return_module&action=$return_action";

if(!empty($return_id)){
   $return_location .= "&record=$return_id";
}

header("Location: $return_location");

?>
