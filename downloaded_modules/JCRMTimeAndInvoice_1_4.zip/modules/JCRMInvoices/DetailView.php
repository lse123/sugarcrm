<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');

require_once('XTemplate/xtpl.php');
require_once('data/Tracker.php');
require_once('include/time.php');
require_once('modules/JCRMInvoices/JCRMInvoice.php');
require_once('include/DetailView/DetailView.php');

global $app_strings;
global $mod_strings;
global $theme;
global $current_user;

$GLOBALS['log']->info('JCRMInvoice module detail view');
$focus = new JCRMInvoice();

//Only load a record if a record id is given;
//a record id is not given when viewing in layout editor
$detailView = new DetailView();
$offset=0;

if (isset($_REQUEST['offset']) or isset($_REQUEST['record'])) {
	 $result = $detailView->processSugarBean("JCRMINVOICE", $focus, $offset);
	 if($result == null) {
	     sugar_die($app_strings['ERROR_NO_RECORD']);
	 }
	 $focus=$result;
}else {
	 header("Location: index.php?module=Accounts&action=index");
}

$theme_path = 'themes/' . $theme . '/';
$image_path = $theme_path . 'images/';
require_once($theme_path.'layout_utils.php');

echo "\n<p>\n";
echo get_module_title('JCRMInvoices', "<IMG src='themes/Default/images/JCRMInvoices.gif' width='16' height='16' border='0' style='margin-top: 3px;' alt='JCRMInvoices'>&nbsp;".$mod_strings['LBL_MODULE_NAME'].": ".$focus->invoice_number, true);
echo "\n</p>\n";

$xtpl = new XTemplate('modules/JCRMInvoices/DetailView.html');

$xtpl->assign('MOD', $mod_strings);
$xtpl->assign('APP', $app_strings);
if(isset($_REQUEST['return_module'])){
	$xtpl->assign("RETURN_MODULE", $_REQUEST['return_module']);
}

if(isset($_REQUEST['return_action'])){
	$xtpl->assign("RETURN_ACTION", $_REQUEST['return_action']);
}

if(isset($_REQUEST['return_id'])){
	$xtpl->assign("RETURN_ID", $_REQUEST['return_id']);
}

$xtpl->assign('PRINT_URL',              "index.php?".$GLOBALS['request_string']);
$xtpl->assign('THEME',                  $theme);
$xtpl->assign('GRIDLINE',               $gridline);
$xtpl->assign('IMAGE_PATH',             $image_path);
$xtpl->assign('id',                     $focus->id);
$xtpl->assign('ASSIGNED_USER_NAME',     $focus->assigned_user_name);
$xtpl->assign('DESCRIPTION',            nl2br(url2html($focus->description)));
$xtpl->assign("DATE_MODIFIED", $focus->date_modified);
$xtpl->assign("DATE_ENTERED", $focus->date_entered);
$xtpl->assign("CREATED_BY", $focus->created_by_name);
$xtpl->assign("MODIFIED_BY", $focus->modified_by_name);


$xtpl->assign('DATE_INVOICE',  $focus->date_invoice);
$xtpl->assign('INTERNAL_REF',  $focus->internal_ref);
$xtpl->assign('ACCOUNT_NAME',  $focus->account_name);
$xtpl->assign('ACCOUNT_ID',  $focus->account_id);
$xtpl->assign('CONTACT_NAME',  $focus->contact_name);
$xtpl->assign('CONTACT_ID',  $focus->contact_id);
$xtpl->assign('INVOICE_NUMBER',  $focus->invoice_number);
$xtpl->assign("STATUS", (empty($focus->status)? "" : $app_list_strings['jcrminvoice_status'][$focus->status]));
$xtpl->assign("TAG", $focus->listviewACLHelper());


$lines=$focus->invoice_lines_array();
if(is_array($lines)) {
	foreach($lines as $num=>$array) {
		$xtpl->assign('LINE_NUM', $num);
		$xtpl->assign('LINE_DESC', $array['desc']);
		$xtpl->assign("LINE_VAT_RATE", (empty($array['vat_rate'])? "" : $app_list_strings['jcrminvoice_vat_rate_dom'][$array['vat_rate']]));
		$xtpl->assign('LINE_AMOUNT', $array['amount']);
		$xtpl->parse("main.line");

	}
}

require_once('modules/Currencies/Currency.php');
$currency  = new Currency();
if(isset($focus->currency_id) && !empty($focus->currency_id))
{
	$currency->retrieve($focus->currency_id);
	if( $currency->deleted != 1){
		$xtpl->assign("CURRENCY", $currency->name .' : '.$currency->symbol );
	}else $xtpl->assign("CURRENCY", $currency->getDefaultCurrencyName() .' : '.$currency->getDefaultCurrencySymbol() );
}else{

	$xtpl->assign("CURRENCY", $currency->getDefaultCurrencyName() .' : '.$currency->getDefaultCurrencySymbol() );

}
$xtpl->assign('AMOUNT',  format_number($focus->amount_usdollar, 2, 2, array('convert' => true, 'currency_symbol' => false)));

$xtpl->assign('CASE_SUMMARY', $focus->get_case_summary());
$xtpl->assign('TIME_SUMMARY', $focus->get_time_summary());
$xtpl->assign('TIME_DETAIL', $focus->get_time_summary_by_date());


if(is_admin($current_user)
	 && $_REQUEST['module'] != 'DynamicLayout'
	 && !empty($_SESSION['editinplace']))
{
	$xtpl->assign('ADMIN_EDIT',
	 '<a href="index.php?action=index&module=DynamicLayout&from_action='
	 . $_REQUEST['action'] . '&from_module=' . $_REQUEST['module']
	 . '&record=' . $_REQUEST['record'] . '">'
	 . get_image($image_path . 'EditLayout',
	   'border="0" alt="Edit Layout" align="bottom"') . '</a>');
}

$detailView->processListNavigation($xtpl, "JCRMINVOICE", $offset, $focus->is_AuditEnabled());

require_once('modules/DynamicFields/templates/Files/DetailView.php');

$xtpl->parse('main.open_source');
$xtpl->parse('main');
$xtpl->out('main');

$sub_xtpl = $xtpl;
$old_contents = ob_get_contents();
ob_end_clean();
ob_start();
echo $old_contents;

?>
