<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');

$fields_array['JCRMInvoice'] = array (
'column_fields' => array(
  'id',
  'date_entered',
  'date_modified',
  'assigned_user_id',
  'modified_user_id',
  'created_by',
  'name',
  'description',
  'deleted',
  'date',
  'date_invoice',
  'internal_ref',
  'account_name',
  'account_id',
  'contact_name',
  'contact_id',
  'invoice_number',
  'invoice_lines',
 ),
 'list_fields' =>  array(
  'id',
  'assigned_user_id',
  'assigned_user_name',
  'name',
  'date_invoice',
  'internal_ref',
  'account_name',
  'account_id',
  'contact_name',
  'contact_id',
  'invoice_number',
 ),
 'required_fields' =>  array('account_name'=>1, ),
);
?>
