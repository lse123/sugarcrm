<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');

require_once('modules/JCRMReports/JCRMReport.php');
require_once('include/TimeDate.php');

global $mod_strings;

//check user has access
if(!ACLController::checkAccess('JCRMInvoices', 'edit', true)) {
   ACLController::displayNoAccess(true);
   sugar_cleanup(true);
}


$dt = new TimeDate();

$rpt_info=array( "title"=> $mod_strings['CREATE_INV_FROM_TIME'],
			  "module" => "JCRMTime",
			  "menu_module" => "JCRMInvoices",  //location (module) of calling file
			  "menu_action" => "CreateFromTime",//name of calling file
			  "sql_select" => "jcrmtime.case_id as 'Select', accounts.name as 'Account Name', concat(cases.name, ' (Case: ', cases.case_number ,')') as 'Case Name', cases.status as 'Status', cases.date_closed as 'Closed Date', cases.resolution as 'Resolution', cases.account_id, TIME_FORMAT(sec_to_time(sum(time_to_sec(jcrmtime.time_length))), '%H:%i') as 'Time'",
			  "sql_from" => "jcrmtime, cases, accounts",
			  "sql_where_join" => "jcrmtime.case_id = cases.id and accounts.id=cases.account_id and jcrmtime.deleted=0 and jcrmtime.invoice_id is null and cases.deleted=0",
			  "sql_group_by" => "1, 2, 3, 4, 5, 6 ",
			  "sql_order_by" => "2,4",
			  "criteria_required"=>false,
			  "columns" => array("case_id"=>array("query_only"=>true),
			  					"account_id"=>array("query_only"=>true),
			  					"Closed Date"=>array("callback"=>"DisplayDateCell"),
			  					"Account Name"=>array("callback"=>"DisplayAccountCell"),
			  					"Case Name"=>array("callback"=>"CFTDisplayCaseCell"),
			  					"Select"=>array("callback"=>"CFTDisplaySelectCell", "style"=>"width='5%'"),
			  					"Number"=>array("style"=>"width='5%'"),),
		  );

$add_existing = ((isset($_REQUEST['record']) && $_REQUEST['record']!='') || (isset($_REQUEST['fwd_return_id']) && $_REQUEST['fwd_return_id']!='')) ? true: false;

if($add_existing) $rpt_info['title']=$mod_strings['ADD_TIME_TO_INV'];

global $moduleList;
if(!in_array('Autocases',  $moduleList)) {
	// dont include closed date which is provided by autocases enhancement
	$rpt_info["sql_select"] = str_replace ( "cases.date_closed as 'Closed Date',", "",  $rpt_info["sql_select"]);
}

$one_account=false;
if(isset($_REQUEST['account_id'])) {
	$one_account=true;
	$rpt_info["sql_where_join"].=" AND cases.account_id='".PearDatabase::quote(from_html($_REQUEST['account_id']))."'";
	$rpt_info['title']='Create Invoice from unbilled Time for Account '.$_REQUEST['account_name'];
}


function CFTDisplaySelectCell($row, $key, $value) {
	return '<input type="checkbox" class="checkbox" name="cases['.$value.']" value="'. $row['Case Name'].'">';
}
/*function DisplayAccountCell($row, $key, $value) {
	return '<a  href="index.php?module=Accounts&action=DetailView&record='.$row['account_id'].'" class="listViewTdLinkS1">' . $value.'</a>';
} */
function CFTDisplayCaseCell($row, $key, $value) {
	return '<a  href="index.php?module=Cases&action=DetailView&record='.$row['Select'].'" class="listViewTdLinkS1">' . $value.'</a>';
}
/*function DisplayDateCell($row, $key, $value) {
	global $timedate;
	return $timedate->to_display_date($value);
} */



//User has requested the report itself
//we need to select items and pass them on so we add a form
$rpt = new JCRMReport($rpt_info);
echo $rpt->select_html(true);

$ret_record='';
if(isset($_REQUEST['fwd_return_id']))
$ret_record=$_REQUEST['fwd_return_id'];
if(isset($_REQUEST['return_id']))
$ret_record=$_REQUEST['return_id'];

$ret_module=isset($_REQUEST['return_module']) ? $_REQUEST['return_module'] : 'JCRMInvoices';
$id=isset($_REQUEST['record']) ? $_REQUEST['record'] : '';

echo '<form name="CreateFromTime" method="POST" action="index.php">
    <input type="hidden" name="module" value="JCRMInvoices">
    <input type="hidden" name="record" value="'.$id.'">
    <input type="hidden" name="action" value="EditView">
    <input type="hidden" name="return_module" value="'.$ret_module.'">
    <input type="hidden" name="return_id" value="'.$ret_record.'">
    <input type="hidden" name="return_action" value="DetailView">
 <script type="text/javascript">
 function check_selected() {
 	var selected=0;
	for (i=0;i<document.CreateFromTime.length;i++)
	{
		if (document.CreateFromTime[i].type=="checkbox")
		{
		if(document.CreateFromTime[i].checked) selected++;
		}
	}

 	if(selected==0) {
 		alert("'.$mod_strings['SELECT_CASES'].'");
 		return false;
 	}

 	return true;
 }
    </script>';

echo $rpt->report_html();

if($rpt->recordcount==0){
	echo $mod_strings['NO_UNBILLED_TIME'];
} else {
	if($add_existing)
	echo '<p><br><input title="'.$mod_strings['ADD_SELECTED'].'" class="button" type="submit" name="button" value="'.$mod_strings['ADD_SELECTED'].'" onclick="return check_selected();"></p></form>';
	else
	echo '<p><br><input title="'.$mod_strings['CREATE_INVOICE'].'" class="button" type="submit" name="button" value="'.$mod_strings['CREATE_INVOICE'].'" onclick="return check_selected();"></p></form>';
}


?>
