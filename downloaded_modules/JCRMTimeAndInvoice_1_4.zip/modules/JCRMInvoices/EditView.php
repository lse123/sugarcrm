<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');

require_once('XTemplate/xtpl.php');
require_once('data/Tracker.php');
require_once('modules/JCRMInvoices/JCRMInvoice.php');
require_once('include/time.php');
require_once('include/TimeDate.php');
require_once('modules/JCRMInvoices/Forms.php');
require_once('include/JSON.php');

//var_dump($_REQUEST);

$timedate = new TimeDate();

global $app_strings;
global $app_list_strings;
global $current_language;
global $current_user;
global $sugar_version, $sugar_config;

$focus = new JCRMInvoice();
if(!empty($_REQUEST['record'])){
	$focus->retrieve($_REQUEST['record']);
}
else {
	//accept defaults from account subpanel
	if(isset($_REQUEST['account_id']))
	$focus->account_id=$_REQUEST['account_id'];
	if(isset($_REQUEST['account_name']))
	$focus->account_name=$_REQUEST['account_name'];
}

global $theme;
$theme_path="themes/".$theme."/";
$image_path=$theme_path."images/";
require_once($theme_path.'layout_utils.php');

echo "\n<p>\n";
echo get_module_title('JCRMInvoices', "<IMG src='themes/Default/images/JCRMInvoices.gif' width='16' height='16' border='0' style='margin-top: 3px;' alt='JCRMInvoices'>&nbsp;".$mod_strings['LBL_MODULE_NAME'].": ".$focus->invoice_number, true);
echo "\n</p>\n";

$GLOBALS['log']->info("detail view");

$xtpl=new XTemplate ('modules/JCRMInvoices/EditView.html');

//Users Popup
$json = new JSON(JSON_LOOSE_TYPE);
$popup_request_data = array(
	 'call_back_function'  => 'set_return',
	 'form_name'           => 'EditView',
	 'field_to_name_array' => array(
		  'id'        => 'assigned_user_id',
		  'user_name' => 'assigned_user_name',
	  ),
 );
$xtpl->assign('encoded_users_popup_request_data', $json->encode($popup_request_data));

//Account Popup
$popup_request_data = array(
	'call_back_function' => 'set_return',
	'form_name' => 'EditView',
	'field_to_name_array' => array(
		'id' => 'account_id',
		'name' => 'account_name',
		),
	);

$encoded_popup_request_data = $json->encode($popup_request_data);
$xtpl->assign('encoded_popup_request_data', $encoded_popup_request_data);

  //Contact Popup
$popup_request_data = array(
	'call_back_function' => 'set_return',
	'form_name' => 'EditView',
	'field_to_name_array' => array(
		'id' => 'contact_id',
		'name' => 'contact_name',
		),
	);

$encoded_popup_request_data = $json->encode($popup_request_data);
$xtpl->assign('encoded_contact_popup_request_data', $encoded_popup_request_data);


$xtpl->assign('MOD',  $mod_strings);
$xtpl->assign('APP',  $app_strings);

if (empty($focus->assigned_user_id) && empty($focus->id))  $focus->assigned_user_id = $current_user->id;
if (empty($focus->assigned_name) && empty($focus->id))     $focus->assigned_user_name = $current_user->user_name;
$xtpl->assign("ASSIGNED_USER_OPTIONS",                     get_select_options_with_id(get_user_array(TRUE, "Active", $focus->assigned_user_id), $focus->assigned_user_id));
$xtpl->assign("ASSIGNED_USER_NAME",                        $focus->assigned_user_name);
$xtpl->assign("ASSIGNED_USER_ID",                          $focus->assigned_user_id );

$xtpl->assign('description', $focus->description);

if(isset($_REQUEST['isDuplicate']) && $_REQUEST['isDuplicate'] == 'true') {
 $focus->id = "";
}

if(isset($_REQUEST['account_id']))     $xtpl->assign("ACCOUNT_ID",     $_REQUEST['account_id']);
if(isset($_REQUEST['contact_id']))     $xtpl->assign("CONTACT_ID",     $_REQUEST['contact_id']);

if (isset($_REQUEST['return_module'])) $xtpl->assign("RETURN_MODULE",  $_REQUEST['return_module']);
if (isset($_REQUEST['return_action'])) $xtpl->assign("RETURN_ACTION",  $_REQUEST['return_action']);
if (isset($_REQUEST['return_id']))     $xtpl->assign("RETURN_ID",      $_REQUEST['return_id']);

if (empty($_REQUEST['return_id'])) {
 $xtpl->assign("RETURN_ACTION", 'index');
}

//quick searches
$qsContact = array(
			'method' => 'query',
			'modules' => array('Contacts'),
			'group' => 'or',
			'field_list' => array('name', 'id'),
			'populate_list' => array('contact_name', 'contact_id'),
			'conditions' => array(array('name'=>'name','op'=>'like_custom','end'=>'%','value'=>'')),
			'order' => 'name',
			'limit' => '30',
			'no_match_text' => $app_strings['ERR_SQS_NO_MATCH']
			);

if (isset($sugar_config)) {
	if ($sugar_config['sugar_version'] >= '4.5.0') {
		require_once('include/QuickSearchDefaults.php');
		$qsd = new QuickSearchDefaults();

		$sqs_objects = array('contact_name' => $qsContact,
							'account_name' => $qsd->getQSParent(),
							'assigned_user_name' => $qsd->getQSUser(),
							);
		$sqs_objects['account_name']['field_list'] = array('name', 'id');
		$sqs_objects['account_name']['populate_list'] = array('account_name', 'account_id');
		$quicksearch_js = $qsd->getQSScripts();
		$quicksearch_js .= '<script type="text/javascript" language="javascript">sqs_objects = ' . $json->encode($sqs_objects) . '</script>';
	}else{
		require_once('include/QuickSearchDefaults.php');

		$sqs_objects     = array('contact_name' => $qsContact,
									'account_name' => $qsParent,
									'assigned_user_name' => $qsUser,
		                         'team_name'          => $qsTeam);

		$sqs_objects['account_name']['populate_list'] = array('account_name', 'account_id');
		$quicksearch_js  = $qsScripts;
		$quicksearch_js .= '<script type="text/javascript" language="javascript">sqs_objects = ' . $json->encode($sqs_objects) . '</script>';
	}
}

$xtpl->assign("JAVASCRIPT", get_set_focus_js().get_validate_record_js() . $quicksearch_js);

$xtpl->assign("USER_DATEFORMAT", '('.$timedate->get_user_date_format().')');
$xtpl->assign("CALENDAR_DATEFORMAT", $timedate->get_cal_date_format());

$xtpl->assign("THEME",      $theme);
$xtpl->assign("IMAGE_PATH", $image_path);
$xtpl->assign("PRINT_URL", "index.php?".$GLOBALS['request_string']);
$xtpl->assign("ID",         $focus->id);

$xtpl->assign('DATE_INVOICE',  $focus->date_invoice==''? $timedate->to_display_date($timedate->get_gmt_db_datetime()) :$focus->date_invoice);
$xtpl->assign('INTERNAL_REF',  $focus->internal_ref);
$xtpl->assign('ACCOUNT_NAME',  $focus->account_name);
$xtpl->assign('ACCOUNT_ID',  $focus->account_id);
$xtpl->assign('CONTACT_NAME',  $focus->contact_name);
$xtpl->assign('CONTACT_ID',  $focus->contact_id);
$xtpl->assign('INVOICE_NUMBER',  $focus->invoice_number);

global $current_user;
require_once('modules/Currencies/ListCurrency.php');
$currency = new ListCurrency();
if(isset($focus->currency_id) && !empty($focus->currency_id)){
	$selectCurrency = $currency->getSelectOptions($focus->currency_id);
	$xtpl->assign("CURRENCY", $selectCurrency);
}
else if($current_user->getPreference('currency') && !isset($focus->id))
{
	$selectCurrency = $currency->getSelectOptions($current_user->getPreference('currency'));
	$xtpl->assign("CURRENCY", $selectCurrency);
}else{

	$selectCurrency = $currency->getSelectOptions();
	$xtpl->assign("CURRENCY", $selectCurrency);

}

$xtpl->assign("STATUS_OPTIONS", get_select_options_with_id($app_list_strings['jcrminvoice_status'], $focus->status));

require_once('modules/DynamicFields/templates/Files/EditView.php');

global $current_user;
if(is_admin($current_user)
 && $_REQUEST['module'] != 'DynamicLayout'
 && !empty($_SESSION['editinplace']))
{
 $record = '';
 if(!empty($_REQUEST['record'])){
  $record =  $_REQUEST['record'];
 }
 $xtpl->assign("ADMIN_EDIT","<a href='index.php?action=index&module=DynamicLayout&from_action="
  .$_REQUEST['action'] ."&from_module=".$_REQUEST['module']
  ."&record=".$record. "'>".get_image($image_path
  ."EditLayout","border='0' alt='Edit Layout' align='bottom'")."</a>");
}

$sql='';


if(isset($_REQUEST['cases']) && is_array($_REQUEST['cases']) && !empty($_REQUEST['cases'])) {
	//creating from time or adding time

	$first_case_id='';
	foreach($_REQUEST['cases'] as $key=>$value) {
		if($first_case_id=='') $first_case_id = $key;

		$focus->add_invoice_line(array('desc'=>$value, 'vat_rate'=>'', 'amount'=>''));

		if ($sql <> '') $sql.=' OR '; else $sql .="(";
		$sql.="cases.id='$key'";
	}
	$sql.=' and jcrmtime.invoice_id is null)';

	//default account name if not already set
	if(empty($focus->account_id)) {
		require_once('modules/Cases/Case.php');
		$case=new aCase();
		$case->retrieve($first_case_id);
		$xtpl->assign('ACCOUNT_NAME',  $case->account_name);
		$xtpl->assign('ACCOUNT_ID',  $case->account_id);
	}

}

if(!empty($_REQUEST['record'])){
	if ($sql <> '') {
    	$sql="(".$sql." or jcrmtime.invoice_id='".$_REQUEST['record']."')";
	}
	else {
    	$sql="jcrmtime.invoice_id='".$_REQUEST['record']."'";
    }
}

//time summary only applies if there is some time added to invoice
if($sql!='') {
	//show a summary of time
	$out='<h3><img src="themes/Sugar/images/h3Arrow.gif" width="11" height="11" border="0" alt="' . $mod_strings['LBL_CASE_SUMMARY'] .
		'">&nbsp;' . $mod_strings['LBL_CASE_SUMMARY'] . '</h3>' . $focus->get_case_summary($sql);
	$xtpl->assign('CASE_SUMMARY', $out);

	$out='<h3><img src="themes/Sugar/images/h3Arrow.gif" width="11" height="11" border="0" alt="' . $mod_strings['LBL_TIME_SUMMARY'] .
		'">&nbsp;' . $mod_strings['LBL_TIME_SUMMARY'] . '</h3>' . $focus->get_time_summary($sql);
	$xtpl->assign('TIME_SUMMARY', $out);

	$out='<h3><img src="themes/Sugar/images/h3Arrow.gif" width="11" height="11" border="0" alt="' . $mod_strings['LBL_TIME_DETAIL'] .
		'">&nbsp;' . $mod_strings['LBL_TIME_DETAIL'] . '</h3>' . $focus->get_time_summary_by_date($sql);
	$xtpl->assign('TIME_DETAIL', $out);
}

//if at this stage there are no invoice lines then add one
if (count($focus->invoice_lines_array())==0) {
	$focus->add_invoice_line(array('desc'=>'', 'vat_rate'=>'', 'amount'=>''));
}

$lines=$focus->invoice_lines_array();
foreach($lines as $num=>$array) {
	$xtpl->assign('LINE_NUM', $num);
	$xtpl->assign('LINE_DESC', $array['desc']);
	$xtpl->assign("LINE_VAT_RATE_OPTIONS", get_select_options_with_id($app_list_strings['jcrminvoice_vat_rate_dom'], $array['vat_rate']));
	$xtpl->assign('LINE_AMOUNT', $array['amount']);
	$xtpl->parse("main.line");

}

$xtpl->assign('LINE_ROWS', count($lines));

$xtpl->parse("main");
$xtpl->out("main");
require_once('include/javascript/javascript.php');
$javascript = new javascript();
$javascript->setFormName('EditView');
$javascript->setSugarBean($focus);

$javascript->addToValidateBinaryDependency('assigned_user_name', 'alpha', $app_strings['ERR_SQS_NO_MATCH_FIELD'] . $app_strings['LBL_ASSIGNED_TO'], 'false', '', 'assigned_user_id');
$javascript->addToValidateBinaryDependency('account_name', 'alpha', $app_strings['ERR_SQS_NO_MATCH_FIELD'] . $mod_strings['LBL_LIST_ACCOUNT_NAME'], 'false', '', 'account_id');
$javascript->addToValidateBinaryDependency('contact_name', 'alpha', $app_strings['ERR_SQS_NO_MATCH_FIELD'] . $mod_strings['LBL_LIST_CONTACT_NAME'], 'false', '', 'contact_id');
$javascript->addAllFields('');

echo $javascript->getScript();

?>
