<?php
require_once('modules/JCRMReports/JCRMReport.php');
$rpt = new JCRMReport();
var_dump($rpt->arr);
?>
