<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
require_once('modules/Accounts/Account.php');
require_once('include/JSON.php');
require_once('include/utils/array_utils.php');
require_once('XTemplate/xtpl.php');
require_once('include/TimeDate.php');

class JCRMReport {
	var $db;

	var $module;
	var $menu_module;
	var $table_name;
	var $arr;
	var $form_name;
	var $table_id;
	var $html_in_form;
	var $html_last;
	var $sql_select;
	var $sql_from;
	var $sql_where_join;
	var $sql_group_by;
	var $sql_order_by;
	var $criteria_required;
	var $columns;
	var $recordcount;

	//to do - find a cleaner way to do this
	var $_opkey2=array('NE','LE','GE','E','LT','GT');
	var $_opkey=array('_NE_','_LE_','_GE_','_E_','_LT_','_GT_');
	var $_opval=array('!=','<=','>=','=','<','>');

	var $_related_variables;
	var $_mod_strings;

	var $where;
	var $where_cstm;

	var $mod_strings;

    /*This bean's constructor*/
     function JCRMReport($rpt_info, $arr='') {
		$this->db = & PearDatabase::getInstance();

     	$this->form_name='JCRMReport';
		$this->sql_select=isset($rpt_info['sql_select'])?$rpt_info['sql_select']:'';
		$this->sql_from=isset($rpt_info['sql_from'])?$rpt_info['sql_from']:'';
		$this->sql_group_by=isset($rpt_info['sql_group_by'])?$rpt_info['sql_group_by']:'';
		$this->sql_order_by=isset($rpt_info['sql_order_by'])?$rpt_info['sql_order_by']:'';
		$this->sql_where_join=isset($rpt_info['sql_where_join'])?$rpt_info['sql_where_join']:'';
		$this->criteria_required=isset($rpt_info['criteria_required'])?$rpt_info['criteria_required']:'';
		if($this->criteria_required=='') $this->criteria_required='false';
		$this->columns=isset($rpt_info['columns'])?$rpt_info['columns']:'';
		$this->title=isset($rpt_info['title'])?$rpt_info['title']:'';
		$this->menu_module=isset($rpt_info['menu_module'])?$rpt_info['menu_module']:'';
		$this->menu_action=isset($rpt_info['menu_action'])?$rpt_info['menu_action']:'';
		$this->table_id=isset($rpt_info['table_id'])?$rpt_info['table_id']:'';
		$this->module=isset($rpt_info['module'])?$rpt_info['module']:'';
		if($this->module!='')
			$this->get_related_variable_array(); //sets table name

		global $current_language;
		$this->mod_strings=return_module_language($current_language, 'JCRMReports');

     	if($arr=='') {
     		$this->GetFromPost();
     	}
     	else {
	     	$this->arr=$arr;
        }
     }

     function SetFromSerial($serial){
     	$this->arr=unserialize(html_entity_decode($serial, ENT_QUOTES));
     }

	function time_to_sql( $time )
	{
		$sec=0;
		if(substr($time, 0, 1) == '-') {
	    	list( $neg, $hour, $minute) = split( '([^0-9])', $time );
	    	$sec= 0 - ((($hour * 60) + $minute) * 60);
		}
		else {
	    	list( $hour, $minute) = split( '([^0-9])', $time );
	    	$sec= (($hour * 60) + $minute) * 60;
	    }
	    return 'sec_to_time(' . $sec . ')';
	}

     function GetFromPost(){
		if (!isset($_REQUEST['filter_entry_max'])) return;

		$temp=array();
		$rows=0;
		$where="";
		$where_cstm="";
		$usescustom=false;
		$this->arr=array();

		for($i = 1; $i <= $_REQUEST['filter_entry_max']; $i++) {
			if(isset($_REQUEST['filter_'.$i.'_field_name'])){
				$rows++;
				$type=html_entity_decode($_REQUEST['filter_'.$i.'_datatype']);

				$temp[$rows]=array('name'=>html_entity_decode($_REQUEST['filter_'.$i.'_field_name'], ENT_QUOTES),
						 'operator_desc'=>html_entity_decode($_REQUEST['filter_'.$i.'_operator'], ENT_QUOTES),
						 'force'=>html_entity_decode($_REQUEST['filter_'.$i.'_force'], ENT_QUOTES),
						 'value'=>'');

				$temp[$rows]['type']=$type;
				if($type=='relate') {
					if(isset($_REQUEST['filter_'.$i.'_id_name']))
					$temp[$rows]['id_name']=html_entity_decode($_REQUEST['filter_'.$i.'_id_name'], ENT_QUOTES);
				}
				$temp[$rows]['operator']=str_replace($this->_opkey, $this->_opval, '_'.html_entity_decode($_REQUEST['filter_'.$i.'_operator'], ENT_QUOTES).'_');
				$temp[$rows]['operator']=str_replace('_', '', $temp[$rows]['operator']);

                $valarr=array();
                $va=0;

                $dt=new TimeDate();

				for($y = 1; $y <= $_REQUEST['filter_'.$i.'_values']; $y++) {
					if(isset($_REQUEST['filter_'.$i.'_value'.$y])){
						$va++;
						$valarr[$va]['value']= html_entity_decode($_REQUEST['filter_'.$i.'_value'.$y], ENT_QUOTES);

						if($type=='date') {
							$valarr[$va]['value']=$dt->swap_formats($valarr[$va]['value'], $dt->get_date_format(), $dt->dbDayFormat);
						}

						if($type=='time' || $type=='negtime') {
							$valarr[$va]['value']=$this->time_to_sql($valarr[$va]['value']);
						}

						if(isset($_REQUEST['filter_'.$i.'_desc'.$y]))
						$valarr[$va]['desc']= html_entity_decode($_REQUEST['filter_'.$i.'_desc'.$y], ENT_QUOTES);
						else
						$valarr[$va]['desc']= html_entity_decode($_REQUEST['filter_'.$i.'_value'.$y], ENT_QUOTES);
					}
				}
				$temp[$rows]['value_arr']=$valarr;

				/* build value which can be used in SQL */
				$op=$temp[$rows]['operator'];
				$val="";

				if($temp[$rows]['operator']=='IN' || $temp[$rows]['operator']== 'NOT IN'){
					$res="";
					foreach($valarr as $item){
						if($res!="") $res.=', ';
						$res.=$this->_valueSql($type, html_entity_decode($item['value'], ENT_QUOTES));
					}
					$res="(" . $res . ")";
					$val=$res;
				}
				elseif($type=='datetime' && $temp[$rows]['operator']=='BETWEEN' || $temp[$rows]['operator']== 'NOT BETWEEN') {
					$val="".$this->_valueSql($type, $valarr[1]['value'].' 00:00:00') . " AND " . $this->_valueSql($type, $valarr[2]['value'].' 23:59:59') . "";
				}
				elseif($type=='datetime' && ($temp[$rows]['operator']=='<' || $temp[$rows]['operator']=='<=')) {
					$val=$this->_valueSql($type, $valarr[1]['value'].' 23:59:59');
				}
				elseif($type=='datetime' && ($temp[$rows]['operator']=='>' || $temp[$rows]['operator']=='>=')) {
					$val=$this->_valueSql($type, $valarr[1]['value'].' 00:00:00');
				}
				elseif($type=='datetime' && ($temp[$rows]['operator']=='=' || $temp[$rows]['operator']=='!=')) {
					$val="".$this->_valueSql($type, $valarr[1]['value'].' 00:00:00') . " AND " . $this->_valueSql($type, $valarr[1]['value'].' 23:59:59') . "";
					if($temp[$rows]['operator']=='=')
					$op="BETWEEN";
					else $op="NOT BETWEEN";
				}
				elseif($temp[$rows]['operator']=='IS NULL' || $temp[$rows]['operator']== 'IS NOT NULL') {
					$val="";
				}
				elseif($temp[$rows]['operator']=='BETWEEN' || $temp[$rows]['operator']== 'NOT BETWEEN') {
					$val="".$this->_valueSql($type, $valarr[1]['value']) . " AND " . $this->_valueSql($type, $valarr[2]['value']) . "";
				}
				else{
					if(isset($valarr[1]['value']))
					$val=$this->_valueSql($type, $valarr[1]['value']);
					else
					$val="";
				}

				//append where
				if(substr($temp[$rows]['name'], strlen($temp[$rows]['name']) - 2 ) === '_c' ) {
					if($where_cstm!="") $where_cstm.=" AND ";
					$where_cstm.=$this->table_name."_cstm.";
					if(isset($temp[$rows]['id_name']))
						$where_cstm.=$temp[$rows]['id_name']." ";
					else $where_cstm.=$temp[$rows]['name']." ";

					$where_cstm.=" ".$op." ";
					$where_cstm.=$val." ";
				}
				else {
					if($where!="") $where.=" AND ";
					$where.=$this->table_name.".";
					if(isset($temp[$rows]['id_name']))
						$where.=$temp[$rows]['id_name']." ";
					else $where.=$temp[$rows]['name']." ";

					$where.=" ".$op." ";
					$where.=$val." ";
				}


				/* build value_desc which can be used to show user */
				if($temp[$rows]['operator']=='IN' || $temp[$rows]['operator']== 'NOT IN'){
					$res="";
					foreach($valarr as $item){
						if($res!="") $res.=', ';
						$res.=html_entity_decode($item['desc'], ENT_QUOTES);
					}
					$res="(" . $res . ")";
					$temp[$rows]['value_desc']=$res;
				}
				elseif($temp[$rows]['operator']=='BETWEEN' || $temp[$rows]['operator']== 'NOT BETWEEN') {
					$temp[$rows]['value_desc']="(". $valarr[1]['desc'] . " and " . $valarr[2]['desc'] . ")";
				}
				else{
					if(isset($valarr[1]['desc']))
					$temp[$rows]['value_desc']=$valarr[1]['desc'];
					else
					$temp[$rows]['value_desc']="";
				}


			}
		}


		$this->arr['rows']=$temp;
		$this->arr['count']=$rows;
		$this->where=$where;
		$this->arr['where']=$where;
		$this->where_cstm=$where_cstm;
		$this->arr['where_cstm']=$where_cstm;
		$this->arr['desc']=$this->getDesc();

     }

	 function getDesc(){
	 	global $app_list_strings;
	 	$fields=$this->get_related_variable_array();
	 	$desc='';

		for($i = 1; $i <= $this->arr['count']; $i++) {
			if ($desc!='')
			$desc.=" and ";

			$desc.=$fields[$this->arr['rows'][$i]['name']]." ".$app_list_strings['jcrmreport_whereoperator_dom'][$this->arr['rows'][$i]['operator_desc']]." ".$this->arr['rows'][$i]['value_desc'];

		}

	 	return $desc;
	 }


     function SetHtml() {
		$html="";
		$html.=$this->_header();
		$html.=$this->_entry();
		$html.=$this->_footer();


		$this->html_in_form = $html;

		$html=$this->_rows();

  		$html.=$this->_javascript();

  		if(is_array($this->arr['rows'])) {

	     	$html.='<script>'."\n";
	        $i=0;

			foreach($this->arr['rows'] as $line) {

				$label=$this->_related_variables[$line['name']];

				$i++;
				$op = str_replace($this->_opval, $this->_opkey2, $line['operator']);

     			$force='false';
     			if(isset($line['force'])) $force=$line['force'];

	     		$html.="addrow('{$line['name']}', '{$op}', false, $force, '$label');\n";

	     		if($line['operator']=='IN' || $line['operator']=='NOT IN')
	     		$remove='true';
	     		else
	     		$remove='false';

	     		foreach($line['value_arr'] as $key=>$val){

	     			$desc='';
	     			if(isset($val['desc'])) $desc=$val['desc'];

		     		$html.="addValue('{$line['name']}', '{$line['type']}', $i , '{$val['value']}', '$remove', '$desc', '$label');\n";

	     	    }
			}

     	$html.='</script>';
     	}
		$this->html_last = $html;


		return $html;
     }

     function _header(){

		return '';//<table width="100%"><tr><td>';

     }

     function _entry(){

		$options = get_select_options_with_id($this->get_related_variable_array(), '');

		$html = <<<EOQ
		<table width="100%" id="filter_entry">
		<tbody><tr><td colspan="5">
		<input type="hidden" id="filter_entry_max" name="filter_entry_max" value=0>
		<select id="filter_addrow">$options</select>
		&nbsp; <input value="Add" title="Add Line" type="button" class="button" onclick="addrow(document.getElementById('filter_addrow').value, '', 'true', 'false', document.getElementById('filter_addrow').options[document.getElementById('filter_addrow').selectedIndex].text);">
		</td></tr>
		</tbody></table>
EOQ;

		return $html;

     }

     function _rows(){
		global $beanFiles, $beanList, $current_language;

		$entity = $beanList[$this->module];
		require_once ($beanFiles[$entity]);
		$obj = new $entity ();

     	$html="<form id='filter_rows'>";

     	foreach($obj->field_defs as $line){
     		if($this->_valid_field_def($line)){
				$html.=$this->_get_entry_row($this->module, $line);
     		}
     	}

     	$html.="</form>";

     	return $html;
     }

     function _footer(){
     	return "";//</td></tr></table>";
     }

	function _in_array($value, $field){
       	foreach($this->arr as $item_arr)
       	{
       		if($value==$item_arr[$field])
       		return true;
       	}
		return false;
	}

	function _get_line($name){
       	foreach($this->arr as $item_arr)
       	{
       		if($name==$item_arr['name'])
       		return $item_arr;
       	}
		return false;
	}

	function _makespan($field, $html) {
		return "<span id='$field' style='display:none'>".$html."</span>";
	}

	//todo - move all of this into javascript...
	function _get_entry_row($module, $field) {
			$newhtml = '';

      		if(isset($field['vname']) && isset($this->_mod_strings[$field['vname']])){
      			$displayname = $this->_mod_strings[$field['vname']];
      		}else{
      			$displayname = $field['name'];
      		}

      		if($displayname=='') $displayname = $field['name'].':';

      		$name="filter_add_".$field['name'];


			if(isset($field['type']))
			{
				$type = $field['type'];
				if(!empty($field['custom_type']))
				{
					$type  = 	$field['custom_type'];
				}

//	     		$newhtml.="<tr><div id='filter_{$name}' style='display:none'>";
				//$newhtml.=$this->_makespan($name.'_label', "<input type='hidden' name='set_id' value='{$field['name']}'>".$displayname);
				$newhtml.=$this->_makespan($name.'_type', $type);

				if($type=="enum") {
      				$newhtml .= $this->_makespan($name.'_enum', $this->addEnum($displayname,  $name, translate($field["options"])));
				}

				if($type=="relate") {
      				$newhtml .= $this->_makespan($name.'_id_name', $field['id_name']);
      				$newhtml .= $this->_makespan($name.'_module', $field['module']);
				}

			}

			return $newhtml;
  	}

	function addEnum($displayname, $varname, $options){
		global $app_strings, $app_list_strings;

		if(!isset($options['']) && !isset($options['0']))
			$options = array_merge(array(''=>''), $options);
		$options = get_select_options_with_id($options, '');

		$html = '<select name="set_name" >'.$options.'</select>';
		return $html;
	}

	function _javascript(){
		require_once('include/TimeDate.php');
		$timedate = new TimeDate();
		$cal_dateformat = $timedate->get_cal_date_format();

		global $sugar_config;
		if ($sugar_config['sugar_version'] >= '4.5.0') {
			$jsjson='';
		}else{
			$jsjson='<script type="text/javascript" src="json_server.php?module=_configonly"></script>';
		}

		global $app_list_strings;
		$operator_list=$app_list_strings['jcrmreport_whereoperator_dom'];

		$js= <<<EOQ
		<script type="text/javascript" src="include/javascript/popup_parent_helper.js"></script>
		<script type="text/javascript" src="include/JSON.js"></script>
		<script type="text/javascript" src="include/jsolait/init.js"></script>
		<script type="text/javascript" src="include/jsolait/lib/urllib.js"></script>
		{$jsjson}
		<script type="text/javascript" src="include/javascript/jsclass_base.js"></script>
		<script type="text/javascript" src="include/javascript/jsclass_async.js"></script>
		<script type="text/javascript">sqsWaitGif = "themes/Sugar/images/sqsWait.gif";</script>
		<script type="text/javascript" src="include/javascript/quicksearch.js"></script>
		<script type="text/javascript">
		var valuesinrow = new Array();
		var sqs_objects = { };
		var requiredTxt = 'Missing required field:';

		//firefox replacement for innerText
		function getText(el) {
			if(document.all){
			     return el.innerText;
			} else{
			    return el.textContent;
			}
		}
		function setText(el, val) {
			if(document.all){
			     el.innerText=val;
			} else{
			     el.textContent=val;
			}
		}

		function id_from_obj(obj) {
			return parseInt(obj.id.split('_')[1]);
		}

		function op_change(dropdown){
//			alert("row operator change " + dropdown.id);
//			alert(dropdown.parentNode.parentNode.innerHTML);
			var id = id_from_obj(dropdown);
			var cell_value = document.getElementById("filter_" + id + "_label").parentNode.parentNode.cells[2];
			var cell_addbtn = document.getElementById("filter_" + id + "_add_value");
			var nextval = document.getElementById("filter_" + id + "_values");
			var field_name = document.getElementById("filter_" + id + "_field_name");
			var datatype = document.getElementById("filter_" + id + "_datatype");
			var operator = document.getElementById("filter_" + id + "_operator");
			var label = document.getElementById("filter_" + id + "_label").value;

//			alert("currently this row has " + valuesinrow[id] + " values and the max is " + nextval.value);
//			alert(datatype.value + operator.value);

			switch(operator.value){
				case 'IS TRUE':
				case 'IS FALSE':
				case 'IS NULL':
				case 'IS NOT NULL':
				/* no values or buttons */
				cell_addbtn.style.display='none';
//				alert('remove any values');
				for(i=1; i<=nextval.value; i++) {
					deleteValue(id, i, false);
				}
				nextval.value=0;

				break;

				case 'IN':
				case 'NOT IN':
				/* show + button */
				cell_addbtn.style.display='inline';

				/* show remove buttons that may be hidden */
				var rembtn = document.getElementById("filter_" + id + "_rembtn_1");
				if (rembtn != 'undefined' && rembtn !== null) {
					rembtn.style.display='inline';
				}
				else {
					/* no values shown so add one now */
					addValue(field_name.value, datatype.value, id, '', 'true', '', label);
				}

				rembtn = document.getElementById("filter_" + id + "_rembtn_2");
				if (rembtn != 'undefined' && rembtn !== null) {
					rembtn.style.display='inline';
				}

				break;

				case 'BETWEEN':
				case 'NOT BETWEEN':
				cell_addbtn.style.display='none';

				if(valuesinrow[id]==0){
//					alert('add 2 values');
					nextval.value=0;
					addValue(field_name.value, datatype.value, id, '', 'false', '', label);
					addValue(field_name.value, datatype.value, id, '', 'false', '', label);
				}
				else if(valuesinrow[id]==1) {
//					alert('add 1 value');
					addValue(field_name.value, datatype.value, id, '', 'false', '', label);
                }
				else {
//					alert('remove any values above 2');
					for(i=3; i<=nextval.value; i++) {
						deleteValue(id, i, false);
					}
					nextval.value=2;
				}

				/*remove remove button*/
//				alert('remove remove button');
				var rembtn = document.getElementById("filter_" + id + "_rembtn_1");
				rembtn.style.display='none';
				var rembtn = document.getElementById("filter_" + id + "_rembtn_2");
				rembtn.style.display='none';

				break;

				default:
				/* show value entry */
				cell_addbtn.style.display='none';

				if(valuesinrow[id]==0){
//					alert('add 1 value');
					nextval.value=0;
					addValue(field_name.value, datatype.value, id, '', 'false', '', label);
				}
				else if(valuesinrow[id]==1) {
//					alert('nothing to do');
                }
				else if(valuesinrow[id]>1) {
//					alert('remove all existing values and add 1');
					for(i=1; i<=nextval.value; i++) {
						deleteValue(id, i, true);
					}
					nextval.value=0;
					addValue(field_name.value, datatype.value, id, '', 'false', '', label);
				}

				/*remove remove button*/
//				alert('remove remove button');
				var rembtn = document.getElementById("filter_" + id + "_rembtn_1", '');
				rembtn.style.display='none';

				break;
			}

		}

		function deleteRow(i){
//			alert(document.getElementById('filter_entry').rows(i).innerHTML);
//			return;

			document.getElementById('filter_entry').deleteRow(i);
		}

		function add_value(button) {
			var id = id_from_obj(button);
			var field_name = document.getElementById("filter_" + id + "_field_name").value;
			var datatype = document.getElementById("filter_" + id + "_datatype").value;
			var label = document.getElementById("filter_" + id + "_label").value;

			addValue(field_name, datatype, id, '', 'true', '', label);
		}

		function addValue(field_name, datatype, id, val, remove, desc, label){

//			alert("adding value: fieldname->" + field_name + " datatype->"+datatype+" id->"+id+" value->"+val+" remove->" +remove+" desc->"+desc +' label->'+label);
		    valuesinrow[id]++;

			var nextval = document.getElementById("filter_" + id + "_values");
			nextval.value++;

			var cell = document.getElementById("filter_" + id + "_label").parentNode.parentNode.cells[2];

			var strname='filter_' + id + '_value' + nextval.value;
			var strdesc='filter_' + id + '_desc' + nextval.value;

			var span = document.createElement('span');
			span.setAttribute('id', 'filter_' + id + '_remvalue' + nextval.value);
       		setText(span, '    ');

			var newInput =  document.createElement('input');
			newInput.setAttribute('id', "filter_" + id + "_rembtn_" + nextval.value);
			newInput.setAttribute('value', '-');
			newInput.setAttribute('title', 'Remove from List');
			newInput.setAttribute('type','button');
			newInput.setAttribute('className','button');
			if(remove!='true') {
				newInput.style.display='none';
			}
			newInput.onclick = function() {
			  delete_value(this);
			};

			switch(datatype){
				case 'date':
				case 'datetime':

				//manually build TODO move to using this only
				var input = document.createElement('input');
				input.setAttribute('id',strname);
				input.setAttribute('name',strname);
				input.setAttribute('type','text');
				input.setAttribute('size','11');
				input.setAttribute('maxlength','10');

				if(desc !== null)
				input.setAttribute('value',desc);

				var trigger = document.createElement('img');
				trigger.setAttribute('id',strname+'_trigger');
				trigger.setAttribute('src','themes/default/images/jscalendar.gif');
				trigger.setAttribute('alt','Enter Date');
				trigger.setAttribute('align','absmiddle');

				span.appendChild(input);
				span.appendChild(trigger);
				span.appendChild(newInput);
				cell.appendChild(span);

				Calendar.setup ({inputField : strname, ifFormat : '$cal_dateformat', showsTime : false, button :  strname + '_trigger', singleClick : true, step : 1});
				addToValidate('$this->form_name', strname, 'date', true, label + nextval.value );

				break;

				case "assigned_user_name":
				var input = document.createElement('input');
				input.setAttribute('id',strdesc);
				input.setAttribute('name',strdesc);
				input.setAttribute('type','text');
				input.setAttribute('size','15');
				input.setAttribute('className','sqsEnabled');
				input.setAttribute('autocomplete','off');
				if(desc != 'undefined'){
					if(desc !== null)
					input.setAttribute('value',desc);
				}

				sqs_objects[strdesc] = {"method":"get_user_array","field_list":["user_name","id"],"populate_list":[strname+"_desc",strname],"conditions":[{"name":"user_name","op":"like_custom","end":"%","value":""}],"limit":"30","no_match_text":"No Match"};

				var valinput = document.createElement('input');
				valinput.setAttribute('id',strname);
				valinput.setAttribute('name',strname);
				valinput.setAttribute('type','hidden');
				if(val !== null) {
					valinput.setAttribute('value',val);
				}

				var trigger = document.createElement('input');
				trigger.setAttribute('type','button');
				trigger.setAttribute('className','button');
				trigger.setAttribute('id',strname+'_trigger');
				trigger.setAttribute('name',strname+'_trigger');
				trigger.setAttribute('title','Select');
				trigger.setAttribute('value','Select');
				trigger.onclick= function() {
 					 showUserPopup(strname, strdesc);
				}


				span.appendChild(input);
				span.appendChild(valinput);
				span.appendChild(trigger);
				span.appendChild(newInput);

				cell.appendChild(span);

				addToValidate('$this->form_name', strname, 'text', true, label + nextval.value );
				addToValidateBinaryDependency('$this->form_name', strdesc, 'alpha', false, 'No match for field: '+label, strname);
				break;

				case "relate":
				var module = getText(document.getElementById("filter_add_" + field_name + "_module"));
				var input = document.createElement('input');
				input.setAttribute('id',strdesc);
				input.setAttribute('name',strdesc);
				input.setAttribute('type','text');
				input.setAttribute('size','15');
				input.readOnly=true;
				if(desc != 'undefined'){
					if(desc !== null)
					input.setAttribute('value',desc);
				}

				var valinput = document.createElement('input');
				valinput.setAttribute('id',strname);
				valinput.setAttribute('name',strname);
				valinput.setAttribute('type','hidden');
				if(val !== null)
				valinput.setAttribute('value',val);

				var trigger = document.createElement('input');
				trigger.setAttribute('type','button');
				trigger.setAttribute('className','button');
				trigger.setAttribute('id',strname+'_trigger');
				trigger.setAttribute('name',strname+'_trigger');
				trigger.setAttribute('title','Select');
				trigger.setAttribute('value','Select');
				trigger.onclick= function() {
 					 showRelatePopup(strname, strdesc, module);
				}

				span.appendChild(input);
				span.appendChild(valinput);
				span.appendChild(trigger);
				span.appendChild(newInput);
				cell.appendChild(span);
				addToValidate('$this->form_name', strname, 'text', true, label + nextval.value );
				addToValidateBinaryDependency('$this->form_name', strdesc, 'alpha', false, 'No match for field: '+label, strname);
				break;

				case "time": case "negtime":
				var input = document.createElement('input');
				input.setAttribute('id',strname);
				input.setAttribute('name',strname);
				input.setAttribute('type','text');
				input.setAttribute('size','6');
				input.setAttribute('maxlength','6');
				if(desc != 'undefined'){
					if(desc !== null)
					input.setAttribute('value',desc);
				}
				span.appendChild(input);
				span.appendChild(newInput);
				cell.appendChild(span);
				addToValidate('$this->form_name', strname, "time", true, label + nextval.value );
				break;

   				case "num": case "int":
   				case "text": case "varchar":  case "email":  case "phone":  case "name":
				var input = document.createElement('input');
				input.setAttribute('id',strname);
				input.setAttribute('name',strname);
				input.setAttribute('type','text');
				if(val != 'undefined'){
					if(val !== null)
					input.setAttribute('value',val);
				}
				span.appendChild(input);
				span.appendChild(newInput);
				cell.appendChild(span);
				addToValidate('$this->form_name', strname, datatype, true, label + nextval.value );
				break;

				case "enum":
  				var opt_enum = document.getElementById("filter_add_" + field_name + "_enum").getElementsByTagName('SELECT')[0];
				var input = document.createElement('select');
				input.setAttribute('id',strname);
				input.setAttribute('name',strname);

				for (i=0; i < opt_enum.options.length; i++){
					addopt(input, opt_enum.options[i].value, opt_enum.options[i].text);
				}

				if(val != 'undefined'){
					selectOption(input, val);
				}
				span.appendChild(input);
				span.appendChild(newInput);
				cell.appendChild(span);
				addToValidate('$this->form_name', strname, 'text', true, label + nextval.value );
				break;

				default:
				alert('unknown datatype -> ' + datatype);
				if(val!='undefined'){
					var node=document.getElementById('filter_'+id+'_remvalue'+nextval.value).getElementsByTagName('SELECT')[0];
					selectOption(node, val);
				}

				break;
			}

//			alert('addValue Complete');
		}

		function showUserPopup(id, desc){
//			alert('show popup '+id);

			var objRef = { };
			objRef["call_back_function"]="set_return";
			objRef["form_name"]="$this->form_name";
			var objRef2 = { };
			objRef2["id"]= id;
			objRef2["user_name"]= desc;
			objRef["field_to_name_array"]=objRef2;

			open_popup("Users", 600, 400, "", true, false, objRef);
		}

		function showRelatePopup(id, name, Module){
//			alert('show popup id: '+id + ' name: ' + name + ' module: ' + Module);

			var objRef = { };
			objRef["call_back_function"]="set_return";
			objRef["form_name"]="$this->form_name";
			var objRef2 = { };
			objRef2["id"]= id;
			objRef2["name"]= name;
			objRef["field_to_name_array"]=objRef2;

			open_popup(Module, 600, 400, "", true, false, objRef);
		}

		function delete_value(button) {
			var id = id_from_obj(button);
			var val = parseInt(button.id.split('_')[3]);
			deleteValue(id, val, true);
		}

		function deleteValue(id, val, check){
//			alert('atempting to remove value ' + id + ' ' + val);
			//CHECK NOT LAST ONE
			if(valuesinrow[id]==1 && check) {
				alert('{$this->mod_strings['LBL_MUST_HAVE_LIST']}');
			}
			else {
				var node=document.getElementById('filter_'+id+'_remvalue'+val);
				if(node!==null) {

					node.parentNode.removeChild(node);
	//				alert('value removed');
				    valuesinrow[id]--;
					removeFromValidate('$this->form_name', 'filter_' +id + '_value' +val );

			    }
		    }
		}

		function selectOption(opt, key)
		{
			for(i=0; i<opt.options.length; i++) {
				if(opt.options[i].value==key){
					opt.selectedIndex=i;
					return;
				}
			}
		}

		function addopt(sel, val, txt) {
			var newopt = new Option(txt, val);
			sel.options[sel.options.length]=newopt;
		}

	 	function addrow (field_name, opval, addval, force, label){
//			alert('add row: field_name-> ' + field_name + ', opval-> ' + opval + ', addval-> ' + addval + ' force->'  + force + ' label->' + label);

			var datatype = getText(document.getElementById("filter_add_" + field_name + "_type"));
			var max = document.getElementById("filter_entry_max");
			max.value++;
			valuesinrow[max.value]=0;

			var tbody = document.getElementById("filter_entry").getElementsByTagName("tbody")[0];

			var newrow = document.createElement('TR');

			var cell_label=document.createElement('TD');
			var newInput=document.createElement('input');
			newInput.type='hidden';
			newInput.value=field_name;
			newInput.name='filter_'+max.value+'_field_name';
			newInput.id='filter_'+max.value+'_field_name';
			cell_label.appendChild(newInput);

			var newInput=document.createElement('input');
			newInput.type='hidden';
			newInput.value=label;
			newInput.name='filter_'+max.value+'_label';
			newInput.id='filter_'+max.value+'_label';
			cell_label.appendChild(newInput);

			var newInput=document.createElement('span');
			setText(newInput, label);
			cell_label.appendChild(newInput);

			var newInput=document.createElement('input');
			newInput.type='hidden';
			newInput.value=0;
			newInput.name='filter_'+max.value+'_values';
			newInput.id='filter_'+max.value+'_values';
			cell_label.appendChild(newInput);

			var newInput=document.createElement('input');
			newInput.type='hidden';
			newInput.value=datatype;
			newInput.name='filter_'+max.value+'_datatype';
			newInput.id='filter_'+max.value+'_datatype';
			cell_label.appendChild(newInput);

			var cell_operator=document.createElement('TD');
			var newInput=document.createElement('select');
			newInput.name='filter_'+max.value+'_operator';
			newInput.id='filter_'+max.value+'_operator';

			newInput.onchange = function() {
			  op_change(this);
			};
			cell_operator.appendChild(newInput);

			switch(datatype){
				case "relate":
				case "parent":
				case "contact_id":
				case "assigned_user_name":
				case "account_id":
				case "account_name":
				case "enum":
				addopt(newInput, 'E','{$operator_list['E']}');
				addopt(newInput, 'NE','{$operator_list['NE']}');
				addopt(newInput, 'IS NULL','{$operator_list['IS NULL']}');
				addopt(newInput, 'IS NOT NULL','{$operator_list['IS NOT NULL']}');
				addopt(newInput, 'IN','{$operator_list['IN']}');
				addopt(newInput, 'NOT IN','{$operator_list['NOT IN']}');
				break;

				case "date": case "datetime": case "num": case "float": case "currency": case "int": case "time": case "negtime":
				addopt(newInput, 'E','{$operator_list['E']}');
				addopt(newInput, 'NE','{$operator_list['NE']}');
				addopt(newInput, 'IS NULL','{$operator_list['IS NULL']}');
				addopt(newInput, 'IS NOT NULL','{$operator_list['IS NOT NULL']}');
				addopt(newInput, 'LE','{$operator_list['LE']}');
				addopt(newInput, 'LT','{$operator_list['LT']}');
				addopt(newInput, 'GE','{$operator_list['GE']}');
				addopt(newInput, 'GT','{$operator_list['GT']}');
				addopt(newInput, 'BETWEEN','{$operator_list['BETWEEN']}');
				addopt(newInput, 'NOT BETWEEN','{$operator_list['NOT BETWEEN']}');

				break;

				case "text": case "varchar":  case "email":  case "phone":  case "name":
				addopt(newInput, 'E','{$operator_list['E']}');
				addopt(newInput, 'NE','{$operator_list['NE']}');
				addopt(newInput, 'IS NULL','{$operator_list['IS NULL']}');
				addopt(newInput, 'IS NOT NULL','{$operator_list['IS NOT NULL']}');
				addopt(newInput, 'IN','{$operator_list['IN']}');
				addopt(newInput, 'NOT IN','{$operator_list['NOT IN']}');
				addopt(newInput, 'LIKE','{$operator_list['LIKE']}');
				addopt(newInput, 'NOT LIKE','{$operator_list['NOT LIKE']}');
				break;

				case "bool":
				addopt(newInput, 'IS TRUE','{$operator_list['IS TRUE']}');
				addopt(newInput, 'IS FALSE','{$operator_list['IS FALSE']}');
				addopt(newInput, 'IS NULL','{$operator_list['IS NULL']}');
				addopt(newInput, 'IS NOT NULL','{$operator_list['IS NOT NULL']}');
				break;
			}

			selectOption(cell_operator.getElementsByTagName("SELECT")[0], opval);

			var cell_value=document.createElement('TD');
			cell_value.setAttribute("width", "100%");
			cell_value.setAttribute("align", "left");

			var cell_add_value=document.createElement('TD');
			cell_add_value.setAttribute("align", "left");

			var newSpan=document.createElement('span');
			newSpan.id='filter_' + max.value + '_add_value';

			if(opval=="IN" || opval =="NOT IN") {
				newSpan.style.display='inline';
			}
			else {
				newSpan.style.display='none';
			}
			cell_add_value.appendChild(newSpan);


			var newInput=document.createElement('input');
			newInput.type='button';
			newInput.value='+';
			newInput.title='Add to List';
			newInput.setAttribute('className','button');
			newInput.id='filter_'+max.value+'_addbutton';
			newInput.onclick = function() {
			  add_value(this);
			};
			newSpan.appendChild(newInput);

			var cell_remove=document.createElement('TD');
			var newInput=document.createElement('input');
			newInput.type='hidden';
			newInput.value=force;
			newInput.name='filter_' + max.value + '_force';
			newInput.id='filter_' + max.value + '_force';
			cell_remove.appendChild(newInput);

			var newInput=document.createElement('input');
			newInput.type='button';
			newInput.value='Remove';
			newInput.title='Remove';
			newInput.setAttribute('className','button');
			newInput.name='filter_' + max.value + '_remove';
			newInput.id='filter_' + max.value + '_remove';
			newInput.onclick=function(){deleteRow(this.parentNode.parentNode.rowIndex);};
			cell_remove.appendChild(newInput);

			var cell_pad=document.createElement('TD');

			newrow.appendChild(cell_label);
			newrow.appendChild(cell_operator);
			newrow.appendChild(cell_value);
			newrow.appendChild(cell_add_value);
			newrow.appendChild(cell_pad);
			newrow.appendChild(cell_remove);

			tbody.appendChild(newrow);

			//relate data type must also save back the id_name
			if(datatype=='relate') {
				var id_name = getText(document.getElementById("filter_add_" + field_name + "_id_name"));
				var stridname="filter_" + max.value + "_id_name";
				var idname = document.createElement('input');
				idname.setAttribute('id',stridname);
				idname.setAttribute('name',stridname);
				idname.setAttribute('type','hidden');
				idname.setAttribute('value',id_name);
				tbody.appendChild(idname);
			}

			if(addval=='true'){
				if(datatype != 'bool') {
					addValue(field_name, datatype, max.value, '', 'false', '', label);
				}
			}

		}

		function check_filter () {

			var result=check_form('$this->form_name');

			var max = document.getElementById("filter_entry_max");

			//check at leat 1 row
			if(max.value==0 && '$this->criteria_required' == 'true') {
				result=false;
				alert('You must have at least 1 criteria');
			}

			return result;
		}


		</script>
EOQ;
		return $js;
	}

	function get_related_variable_array() {
		if(isset($this->_related_variables)){
			return $this->_related_variables;
		}

		//create selection options based on Account only
		global $beanFiles, $beanList, $current_language;

		$entity = $beanList[$this->module];
		require_once ($beanFiles[$entity]);
		$obj = new $entity ();

		$this->table_name = $obj->table_name;

		$this->_mod_strings = return_module_language($current_language, $this->module);

		$fields = array();

		foreach($obj->field_defs as $field_def)
		{
			if($this->_valid_field_def($field_def)){

				if(isset($this->_mod_strings[$field_def['vname']]))
		        $desc=rtrim($this->_mod_strings[$field_def['vname']], ':');
		        else $desc=$field_def['name'];

				//add to possible values to compare
				$fields[$field_def['name']]=$desc;
			}
		}

		$this->_related_variables= $fields;
		return $this->_related_variables;
	}

	function _valid_field_def($field_def){

			$source=isset($field_def['source']) ? $field_def['source'] : '';


     		if(isset($field_def['type']) && ($field_def['type'] != "link" && $field_def['type'] != "id") && $source != 'non-db'){
     			if(isset($field_def['reportable']) && $field_def['reportable']===false) return false;
     			return true;
     		}

     		return false;

	}

	function _valueSql($type, $value) {

		switch($type){
			case "date": case "datetime":
			return "'".PearDatabase::quote(from_html($value))."'";
			break;

			case "text": case "varchar":  case "email":  case "phone":  case "name":
			case "enum":
			case "assigned_user_name":
			case "relate":
			return "'".PearDatabase::quote(from_html($value))."'";
			break;

			case "num":
			return $value;
			break;

			default:
			return $value;
			break;

		}

	 }

	 function select_html($title_only=false) {
		$this->SetHtml();

/*		include('include/QuickSearchDefaults.php');
	 	$json = new JSON(JSON_LOOSE_TYPE);
		$sqs_objects = array('assigned_user_name' => $qsUser);
		$quicksearch_js = $qsScripts;
		$quicksearch_js .= '<script type="text/javascript" language="javascript">sqs_objects = ' . $json->encode($sqs_objects) . '</script>';
 */
//		$ret=$quicksearch_js;
//		$ret.='<script type="text/javascript" src="include/javascript/popup_parent_helper.js"></script>';

		$ret='';

		$icon='themes/Default/images/'.$this->menu_module.'.gif';
		if(file_exists($icon))
			$title="<IMG src='$icon' width='16' height='16' border='0' style='margin-top: 3px;'>&nbsp;".$this->title;
		else
			$title=$this->title;

		$ret.="\n<p>\n";
		$ret.= get_module_title('', $title, true);
		$ret.= "\n</p>\n";

		if($title_only) return $ret;

		$return_module = isset($_REQUEST['return_module']) ? $_REQUEST['return_module'] : '';
		$return_module = isset($_REQUEST['fwd_return_module']) ? $_REQUEST['fwd_return_module'] : $return_module;
		$return_id = isset($_REQUEST['return_id']) ? $_REQUEST['return_id'] : '';
		$return_id = isset($_REQUEST['fwd_return_id']) ? $_REQUEST['fwd_return_id'] : $return_id;
		$return_action = isset($_REQUEST['return_action']) ? $_REQUEST['return_action'] : '';
		$return_action = isset($_REQUEST['fwd_return_action']) ? $_REQUEST['fwd_return_action'] : $return_action;

		$ret.=<<<EOQ
     <form name="{FORM_NAME}" method="GET" action="index.php">
     <input type="hidden" name="module" value="{MENU_MODULE}">
     <input type="hidden" name="action" value="{MENU_ACTION}">
     <input type="hidden" name="option" value="">
     <input type="hidden" name="fwd_return_module" value="$return_module">
     <input type="hidden" name="fwd_return_id" value="$return_id">
     <input type="hidden" name="fwd_return_action" value="$return_action">
EOQ;



			$ret.=<<<EOQ
	<p><table width="100%" border="0" cellspacing="0" cellpadding="0"  class="tabForm">
		<tr>
			<th colspan='4' align="left" class="tabDetailViewDL" width="100%" valign="top">
			<h4 class="tabDetailViewDL"><slot>Select Criteria</slot></h4></th>
		</tr>
        <tr>
			<td width="100%"  class="dataField">
EOQ;

	$ret=str_replace("{FORM_NAME}", $this->form_name, $ret);
	$ret=str_replace("{MENU_MODULE}", $this->menu_module, $ret);
	$ret=str_replace("{MENU_ACTION}", $this->menu_action, $ret);


	$ret.=  $this->html_in_form;

	$ret.=	'</td></tr></table></p><p>';

	global $current_user;
	if(is_admin($current_user)) {
		//show view button
		$ret.=<<<EOQ
		<input title="View" class="button" type="submit" name="button" value="View Array" onclick="this.form.option.value='ViewArray';">
EOQ;
	}

	$ret.=	' <input title="Report" class="button" type="submit" name="button" value="Report" onclick="this.form.option.value=\'Report\';return check_filter();" >
	</p>
	</form><div id="test"></div>';


	$ret.= $this->html_last;

	return $ret;

	 }


	 function report_html() {
	 	$ret='';
	 	//admin can view array
		if(isset($_REQUEST['option']) && $_REQUEST['option']=='ViewArray') {
			$ret=var_export_helper($this->arr);
	 	}


		if(isset($this->module) && $this->module!=''){
			if(!ACLController::checkAccess($this->module, 'view', false)) {
				//no access
				echo "You do not have access to view $this->module.";
				die;
			}
		}

	 	//run the report
	 	//echo "<pre>";
	 	//var_dump($this->arr);
	 	//echo "</pre>";
//	 	echo "<br> ".  $this->report_sql() ."<br><br>";

		global $theme, $app_strings;
		$theme_path = "themes/".$theme."/";
		$image_path = $theme_path."images/";
		require_once ($theme_path.'layout_utils.php');

		$xtpl=new XTemplate ('modules/JCRMReports/Report.html');
		$xtpl->assign('APP',  $app_strings);
/*		$xtpl->assign("CALENDAR_LANG", "en");
		$xtpl->assign("USER_DATEFORMAT", '('.$timedate->get_user_date_format().')');
		$xtpl->assign("CALENDAR_DATEFORMAT", $timedate->get_cal_date_format());
*/
		$xtpl->assign("THEME", $theme);
		$xtpl->assign("IMAGE_PATH", $image_path);
		$xtpl->assign("PRINT_URL", "index.php?".$GLOBALS['request_string']);
		$xtpl->assign("TABLEID", $this->table_id);

		global $odd_bg;
		global $even_bg;
		global $hilite_bg;
		$xtpl->assign('BG_HILITE', $hilite_bg);

		$result = $this->db->query($this->report_sql(), true, "Unable to retrieve report");
		if (empty($result)) {
			return '';
		}

        $oddRow=true;
        $rownum=0;
        $once=true;
		while ($row = $this->db->fetchByAssoc($result, -1, true))	{
			if($once){
				foreach($row as $key => $value) {
					if(!(isset($this->columns[$key]['query_only']) && $this->columns[$key]['query_only']==true)) {
						$xtpl->assign('COLHEAD', $key);
						$style=isset($this->columns[$key]['style']) ? $this->columns[$key]['style'] : '';
						$xtpl->assign('COLSTYLE', $style);

						$xtpl->parse("main.colhead");
					}
				}

				$once=false;
			}

			if($oddRow)
			{
				$ROW_COLOR = 'oddListRow';
				$BG_COLOR =  $odd_bg;
			}
			else
			{
				$ROW_COLOR = 'evenListRow';
				$BG_COLOR =  $even_bg;
			}
			$oddRow = !$oddRow;

			$xtpl->assign('ROW_COLOR', $ROW_COLOR);
			$xtpl->assign('BG_COLOR', $BG_COLOR);
    		$cell='';
			foreach($row as $key => $value) {
				if(!(isset($this->columns[$key]['query_only']) && $this->columns[$key]['query_only']==true)) {

					if(isset($this->columns[$key]['callback'])) {
						$eval='$cell='.$this->columns[$key]['callback'].'($row, $key, $value);';
						eval($eval);
					}
					else $cell=$value;

					$xtpl->assign('CELL', $cell);
					$xtpl->parse("main.row.cell");
				}
			}

			$xtpl->assign('ROWNUM', $rownum);
			$xtpl->parse("main.row");

			$rownum++;

		}

		if($oddRow)
		{
			$xtpl->assign('BOTTOM_BG_COLOR', $odd_bg);
		}
		else
		{
			$xtpl->assign('BOTTOM_BG_COLOR', $even_bg);
		}

		$xtpl->assign('ODD_BG', $odd_bg);
		$xtpl->assign('EVEN_BG', $even_bg);

		$xtpl->parse("main");

		$ret.=	$xtpl->text("main");
  		$this->recordcount=$rownum;

      	return $ret;
	 }

	 function report_sql() {
	 	$sql="SELECT ";
	 	$sql.=$this->sql_select;
	 	$sql.=" FROM " . $this->sql_from;

		if($this->sql_where_join!='')
	 		$sqlwhere=" WHERE " ;
	 	$sqlwhere.=$this->sql_where_join;

	 	if($this->where!='') {
			if($sqlwhere=='')
		 		$sqlwhere.=" WHERE " ;
		 	if($this->sql_where_join!='')
	 			$sqlwhere.=" AND ";
	 		$sqlwhere.= $this->where;
	 	}
	 	if($this->where_cstm!='') {
			if($sqlwhere=='')
		 		$sqlwhere.=" WHERE " ;
	 		$sqlwhere.=" AND " . $this->where_cstm;
	 	}

		$sql.=$sqlwhere;

	 	if($this->sql_group_by!='') {
		 	$sql.=" GROUP BY " . $this->sql_group_by;
		}
	 	if($this->sql_order_by!='') {
		 	$sql.=" ORDER BY " . $this->sql_order_by;
		}
		$sql.=';';

		return $sql;
	 }

	 function rptheader() {
	 	if ($this->getDesc()=="") {
	 		return "List all " . $this->module . ':<br>';
	 	}
	 	else {
	 		return "List " . $this->module . " where " . $this->getDesc() . ':<br>';
	 	}
	 }
	 function rptfooter() {
		return $this->recordcount . " records(s) found.";
	 }
}
?>
