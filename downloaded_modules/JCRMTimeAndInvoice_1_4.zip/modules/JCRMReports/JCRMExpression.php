<?php
class JCRMExpression {

	//modified from email_template
      function bean_to_array(&$focus) {
              global $beanFiles, $beanList;
              $repl_arr = array();
              $bean_name=$focus->module_dir;

              foreach($focus->field_defs as $field_def) {
                      if(isset($focus->$field_def['name'])) {
                              if(($field_def['type'] == 'relate' && empty($field_def['custom_type'])) || $field_def['type'] == 'assigned_user_name') {
                           continue;
                              }

                              if($field_def['type'] == 'enum') {
                                      $translated = translate($field_def['options'],$bean_name,$focus->$field_def['name']);

                                      if(isset($translated) && ! is_array($translated)) {
                                              $repl_arr[strtoupper($field_def['name'])] = $translated;
                                      } else { // unset enum field, make sure we have a match string to replace with ""
                                              $repl_arr[strtoupper($field_def['name'])] = '';
                                      }
                              } else {
                                      $repl_arr[strtoupper($field_def['name'])] = $focus->$field_def['name'];
                              }
                      } else {
                              if($field_def['name'] == 'full_name') {
                                      $repl_arr[strtoupper('full_name')] = $focus->get_summary_text();
                              } else {
                                      $repl_arr[strtoupper($field_def['name'])] = '';
                              }
                      }
              } // end foreach()


              krsort($repl_arr);
              reset($repl_arr);

              return $repl_arr;
      }


}
?>
