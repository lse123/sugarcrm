<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');
$mod_strings = array (
 'LBL_MUST_HAVE_LIST'                      => 'Sie m�ssen mindestens 1 Element in der Liste haben.',
);

?>
