<?php

require_once('modules/JCRMReports/language/en_us.lang.php');

?>
