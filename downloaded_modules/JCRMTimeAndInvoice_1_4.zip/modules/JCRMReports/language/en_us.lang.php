<?php
/*********************************************************************************
justcrms - contacts us for license information
 ********************************************************************************/
include('modules/JCRMInvoices/EnterCheck.php');
$mod_strings = array (
 'LBL_MUST_HAVE_LIST'                      => 'You must have at least 1 item in your list.',
);

?>
