<?PHP
$manifest = array(
	'acceptable_sugar_versions' => array (
		'exact_matches' => array (	),
		'regex_matches' => array ( 0=>"5\\.*\\.*")),
    'acceptable_sugar_flavors' => array (
       0 => 'OS', 1 => 'PRO', 2 => 'ENT', 3 => 'DEV', 4 => 'CE',
    ),
    'name'                      => 'JCRMTimeAndInvoice',
    'description'               => 'Provide time entry and invoice generation.',
    'author'                    => 'JustCRMs',
    'published_date'            => '3 April 2009',
    'version'                   => '1.4',
    'type'                      => 'module',
    'icon'                      => '',
    'is_uninstallable'          => true,
);
$installdefs = array(
	//language files will be saved to the following name which must be the name of a module
	//if they are to be picked up by the extensions builder
	'id'       => 'JCRMTime',
	'image_dir'=>'<basepath>/images',
	'copy'     => array(
		//widget
        array('from'    => '<basepath>/widgets/SugarWidgetJCRMSubPanelIcon.php',
              'to'      => 'include/generic/SugarWidgets/SugarWidgetJCRMSubPanelIcon.php',
        ),
		//common
        array('from'    => '<basepath>/modules/JCRMReports',
              'to'      => 'modules/JCRMReports',
        ),
		//time
        array('from'    => '<basepath>/modules/JCRMTime',
              'to'      => 'modules/JCRMTime',
        ),
        array('from'    => '<basepath>/images/CreateJCRMTime.gif',
              'to'      => 'themes/Default/images/CreateJCRMTime.gif',
        ),
        array('from'    => '<basepath>/images/JCRMTime.gif',
              'to'      => 'themes/Default/images/JCRMTime.gif',
        ),
		//invoicing
        array('from'    => '<basepath>/modules/JCRMInvoices',
              'to'      => 'modules/JCRMInvoices',
        ),
        array('from'    => '<basepath>/images/CreateJCRMInvoice.gif',
              'to'      => 'themes/Default/images/CreateJCRMInvoice.gif',
        ),
        array('from'    => '<basepath>/images/JCRMInvoices.gif',
              'to'      => 'themes/Default/images/JCRMInvoices.gif',
        ),
    ),

	'language'=> array(
		array('from'     => '<basepath>/language/jcrmtimeandinvoice_cases.php',
		      'to_module'=> 'Cases',
		      'language' => 'en_us'
		  ),
		array('from'     => '<basepath>/language/jcrmtimeandinvoice_cases.php',
		      'to_module'=> 'Cases',
		      'language' => 'en_gb'
				),
		array('from'     => '<basepath>/language/ge_jcrmtimeandinvoice_cases.php',
		      'to_module'=> 'Cases',
		      'language' => 'ge_ge'
				),
		array('from'     => '<basepath>/language/jcrmtimeandinvoice_accounts.php',
		      'to_module'=> 'Accounts',
		      'language' => 'en_us'
		  ),
		array('from'     => '<basepath>/language/jcrmtimeandinvoice_accounts.php',
		      'to_module'=> 'Accounts',
		      'language' => 'en_gb'
				),
		array('from'     => '<basepath>/language/ge_jcrmtimeandinvoice_accounts.php',
		      'to_module'=> 'Accounts',
		      'language' => 'ge_ge'
				),
		//the following are saved to the id
		array('from'     => '<basepath>/language/app_strings.php',
		      'to_module'=> 'application',
		      'language' => 'en_us'
		  ),
		array('from'     => '<basepath>/language/app_strings.php',
		      'to_module'=> 'application',
		      'language' => 'en_gb'
		  ),
		array('from'     => '<basepath>/language/ge_app_strings.php',
		      'to_module'=> 'application',
		      'language' => 'ge_ge'
		  ),
	),

	'beans'=> array(
		array('module'=> 'JCRMTime',
		      'class' => 'JCRMTime',
		      'path'  => 'modules/JCRMTime/JCRMTime.php',
		      'tab'   => true,
	   ),
	   array('module'=> 'JCRMInvoices',
	         'class' => 'JCRMInvoice',
	         'path'  => 'modules/JCRMInvoices/JCRMInvoice.php',
	         'tab'   => true,
      ),
	),

    'relationships'=>array(),

    'layoutdefs' => array(
    	//the following are saved to custom/ext/Modules/xxx/Ext/Layoutdefs/manifest->id .php
		array('from'     => '<basepath>/layoutdefs/JCRMInvoices_accounts.php',
		      'to_module'=> 'Accounts',
	    ),
		array('from'     => '<basepath>/layoutdefs/JCRMTime_cases.php',
		      'to_module'=> 'Cases',
	    ),
    ),

    'vardefs' => array(
    	//the following are saved to custom/ext/Modules/xxx/Ext/Layoutdefs/manifest->id .php
		array('from'     => '<basepath>/vardefs/JCRMInvoices_accounts.php',
		      'to_module'=> 'Accounts',
	    ),
		array('from'     => '<basepath>/vardefs/JCRMTime_cases.php',
		      'to_module'=> 'Cases',
	    ),
    ),

	 'menu'=>array(
    	//the following is saved to custom/ext/application/Ext/Menus/manifest->id .php
	   array('from'     => '<basepath>/menus/app_menu.php',
	         'to_module'=> 'application',
		    ),
     ),

);
?>