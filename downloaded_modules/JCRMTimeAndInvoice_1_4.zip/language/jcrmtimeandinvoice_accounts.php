<?php
$mod_strings['LBL_JCRMINVOICES_SUBPANEL_TITLE']='Invoices';
?>