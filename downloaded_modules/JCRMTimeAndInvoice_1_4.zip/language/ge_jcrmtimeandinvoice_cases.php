<?php
/*********************************************************************************
justcrms - not for use by service providers
 ********************************************************************************/
$mod_strings['LBL_JCRMTIME_SUBPANEL_TITLE']='Zeiterfassung';
?>