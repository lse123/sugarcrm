<?PHP
/*********************************************************************************
 * APP strings and Dropdown fields for JCRMTime and JCRMInvoices modules.
 ********************************************************************************/
$app_list_strings['moduleList']['JCRMTime']='Zeiterfassung';
$app_list_strings['moduleListSingular']['JCRMTime']='Zeiterfassung';
$app_list_strings['moduleList']['JCRMInvoices']='Rechnungen';
$app_list_strings['moduleListSingular']['JCRMInvoices']='Rechnung';
$app_list_strings['jcrminvoice_vat_rate_dom']= array (
  '21' => '21',
  'zero' => '0',
);
$app_list_strings['jcrminvoice_status']= array (
  'New' => 'Neu',
  'Cancelled' => 'Verworfen',
  'Sent' => 'Gesendet',
);
$app_list_strings['jcrmreport_whereoperator_dom']= array (
'E'=>'Equals',
'NE'=>'Not Equals',
'LE'=>'Less than or equals',
'LT'=>'Less than',
'GE'=>'Greater than or equals',
'GT'=>'Greater than',
'LIKE'=>'Like',
'NOT LIKE'=>'Not Like',
'IS TRUE'=>'Is True',
'IS FALSE'=>'Is False',
'IS NULL'=>'Is Null',
'IS NOT TRUE'=>'Is Not True',
'IS NOT FALSE'=>'Is Not False',
'IS NOT NULL'=>'Is Not Null',
'BETWEEN'=>'Between',//(value1 and value2)
'NOT BETWEEN'=>'Not Between',//(val1 and val2)
'IN'=>'In List',//(value1, Value2, ...)
'NOT IN'=>'Not In List',//(value1, Value2, ...)
);

?>