<?php
	$layout_defs['Flats_items']['subpanel_setup']['flats_changes'] = array(
		'order' => 9,
		'module' => 'Flats_changes',
		'subpanel_name' => 'forFlats_items',
		'get_subpanel_data' => 'flats_changes',
		'add_subpanel_data' => 'flats_item_id',
		'title_key' => 'LBL_FLATS_CHANGES_SUBPANEL_TITLE',
		'top_buttons' => array()
		);
?>
