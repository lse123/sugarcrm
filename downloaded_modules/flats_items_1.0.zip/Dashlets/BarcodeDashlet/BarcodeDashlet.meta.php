<?php
	//$dashletMeta['BarcodeDashlet'] = array(
	//	'title' => 'Barcode Dashlet',
	//	'description' => 'Displays the barcode for an inventory item.',
	//	'category' => 'Tools'
	//	);

?>

