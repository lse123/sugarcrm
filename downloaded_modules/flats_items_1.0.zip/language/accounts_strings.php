<?PHP

	### NEW WITH MODULE INSTALLATION ###

	$mod_strings['LBL_FLATS_ITEMS_SUBPANEL_TITLE'] = 'Flats Items';

	$mod_strings['LBL_SQUARE_FEET'] = 'Square Feet';

?>
